"""MFA dispatch + batch orchestration for the local runtime.

``run_mfa`` dispatches one (audio, lab) alignment: "kalpy" (in-process
engine, falls back to align_one when the engine failed to init) or
"align_one" (the ``mfa align_one`` subprocess — no database/corpus setup).
``align_ref`` runs the full prepare → align → recover flow for one item;
``run_batch`` fans a batch across one of four strategies (shared-CMVN
serial, persistent process pool, thread pool, serial) and returns wire
``ResultRow``s.

Pool workers import THIS module (spawn-safe, no file-path re-exec) and build
their own engine under an isolated HOME/MFA_ROOT_DIR with BLAS threads
pinned, so MFA's acoustic-model extraction tree is per-worker.
"""

from __future__ import annotations

import logging
import os
import queue
import subprocess
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from qua_sdk.components.timing.lib import nest_phones_in_words, prepare_ref, recover_words
from qua_sdk.components.timing.lib.transforms import keep_q_context, set_keep_q
from qua_sdk.components.timing.runtimes.mfa_local.audio import parse_textgrid, save_as_wav
from qua_sdk.components.timing.runtimes.mfa_local.engine import (
    DEFAULT_BEAM,
    DEFAULT_RETRY_BEAM,
    KalpyEngine,
)
from qua_sdk.components.timing.wire import ResultRow, error_result_row, ok_result_row

logger = logging.getLogger(__name__)

VALID_METHODS = ("kalpy", "align_one")

MFA_ALIGN_ONE_TIMEOUT_S = 120


# ------------------------------------------------------------ single-item MFA


def _prepare_files(audio_path: str, lab_content: str, work_dir: Path):
    """Convert audio + write lab into work_dir. Returns (wav_path, lab_path)."""
    corpus_dir = work_dir / "corpus" / "speaker"
    corpus_dir.mkdir(parents=True, exist_ok=True)

    wav_path = corpus_dir / "custom.wav"
    save_as_wav(audio_path, wav_path)

    lab_path = corpus_dir / "custom.lab"
    lab_path.write_text(lab_content, encoding="utf-8")
    return wav_path, lab_path


def run_mfa_align_one(audio_path: str, lab_content: str, *,
                      dictionary_path, model_path,
                      beam: int = DEFAULT_BEAM, retry_beam: int = DEFAULT_RETRY_BEAM) -> list[dict]:
    """Use ``mfa align_one`` — skips database/corpus setup entirely."""
    work_dir = Path(tempfile.mkdtemp(prefix="mfa_one_"))
    wav_path, lab_path = _prepare_files(audio_path, lab_content, work_dir)
    output_tg = work_dir / "custom.TextGrid"

    cmd = [
        "mfa", "align_one",
        str(wav_path),
        str(lab_path),
        str(dictionary_path),
        str(model_path),
        str(output_tg),
        "--beam", str(beam),
        "--retry_beam", str(retry_beam),
    ]
    logger.debug("Running mfa align_one: %s", " ".join(cmd))
    t0 = time.time()
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=MFA_ALIGN_ONE_TIMEOUT_S)
    logger.debug("mfa align_one finished in %.2fs (code %d)", time.time() - t0, proc.returncode)
    if proc.stderr and logger.isEnabledFor(logging.DEBUG):
        for line in proc.stderr.splitlines():
            line = line.strip()
            if line:
                logger.debug("MFA| %s", line)
    if proc.returncode != 0:
        stderr = proc.stderr[-500:] if proc.stderr else ""
        raise RuntimeError(f"mfa align_one failed (code {proc.returncode}): {stderr}")

    intervals = parse_textgrid(output_tg)
    logger.debug("Parsed TextGrid: %d intervals", len(intervals))
    return intervals


def run_mfa_kalpy(engine: KalpyEngine, audio_path: str, lab_content: str, *,
                  beam: int, retry_beam: int) -> list[dict]:
    """Direct kalpy API — no DB, no corpus, no subprocess."""
    work_dir = Path(tempfile.mkdtemp(prefix="mfa_kalpy_"))
    wav_path = work_dir / "audio.wav"
    save_as_wav(audio_path, wav_path)
    return engine.align(str(wav_path), lab_content, beam=beam, retry_beam=retry_beam)


def run_mfa(audio_path: str, lab_content: str, *,
            engine: KalpyEngine | None, dictionary_path, model_path,
            method: str = "kalpy",
            beam: int = DEFAULT_BEAM, retry_beam: int = DEFAULT_RETRY_BEAM) -> list[dict]:
    """Run MFA alignment using the given method.

    "kalpy" with no engine falls back to align_one; an unknown method raises
    ``ValueError`` (the batch loop converts it to a per-item error row).
    """
    if method not in VALID_METHODS:
        raise ValueError(f"Unknown method {method!r}. Must be one of {VALID_METHODS}")

    if method == "kalpy":
        if engine is not None:
            return run_mfa_kalpy(engine, audio_path, lab_content, beam=beam, retry_beam=retry_beam)
        logger.warning("kalpy requested but unavailable, falling back to align_one")
    return run_mfa_align_one(audio_path, lab_content,
                             dictionary_path=dictionary_path, model_path=model_path,
                             beam=beam, retry_beam=retry_beam)


# --------------------------------------------------------- per-item pipeline


def align_ref(audio_path: str, ref, *,
              engine: KalpyEngine | None, dictionary_path, model_path,
              method: str = "kalpy",
              beam: int = DEFAULT_BEAM, retry_beam: int = DEFAULT_RETRY_BEAM,
              padding: str = "forward",
              word_boundary_allocation: dict | None = None):
    """Full single-item flow: prepare → MFA → recover. Returns
    (words, timing, mapped_intervals) with letters included."""
    timing = {"phonemize": 0.0, "flat_map": 0.0, "mfa": 0.0, "words": 0.0, "letters": 0.0}

    t0 = time.time()
    prep = prepare_ref(ref)
    timing["phonemize"] = time.time() - t0

    t0 = time.time()
    intervals = run_mfa(audio_path, prep.lab_content,
                        engine=engine, dictionary_path=dictionary_path, model_path=model_path,
                        method=method, beam=beam, retry_beam=retry_beam)
    timing["mfa"] = time.time() - t0

    words, recovery_timing, mapped_intervals = recover_words(
        intervals, prep, include_letters=True, padding=padding,
        word_boundary_allocation=word_boundary_allocation)
    timing.update(recovery_timing)

    return words, timing, mapped_intervals


def _align_ref_thread_kalpy(engine: KalpyEngine, aligner, audio_path: str, ref, *,
                            padding: str, word_boundary_allocation: dict | None):
    """Per-thread kalpy alignment using a caller-supplied aligner instance,
    so workers don't race on the engine's cached aligner."""
    timing = {"phonemize": 0.0, "flat_map": 0.0, "mfa": 0.0, "words": 0.0, "letters": 0.0}

    t0 = time.time()
    prep = prepare_ref(ref)
    timing["phonemize"] = time.time() - t0

    t0 = time.time()
    work_dir = Path(tempfile.mkdtemp(prefix="mfa_thr_"))
    wav_path = work_dir / "audio.wav"
    save_as_wav(audio_path, wav_path)
    intervals = engine.align_with(aligner, str(wav_path), prep.lab_content)
    timing["mfa"] = time.time() - t0

    words, recovery_timing, mapped_intervals = recover_words(
        intervals, prep, include_letters=True, padding=padding,
        word_boundary_allocation=word_boundary_allocation)
    timing.update(recovery_timing)

    return words, timing, mapped_intervals


# ------------------------------------------------------------- process pool

# Per-worker engine (populated by the pool initializer in each child).
_WORKER_ENGINE: KalpyEngine | None = None


def _pool_worker_init(model_path: str, dictionary_path: str, fst_cache: bool,
                      keep_q: bool = False):
    """ProcessPoolExecutor initializer: isolate the worker env, build an engine.

    Each worker gets a private HOME + MFA_ROOT_DIR so MFA's acoustic-model
    extraction tree is per-worker (no shared-fs races), with BLAS thread
    pools pinned to 1 (one CPU-bound alignment per worker process). keep_q is
    set in the worker's context (ContextVars don't cross the process boundary).
    """
    global _WORKER_ENGINE
    pid = os.getpid()
    base = os.environ.get("MFA_WORKER_BASE") or tempfile.gettempdir()
    home = os.path.join(base, f"mfa_w{pid}")
    os.makedirs(home + "/Documents/MFA", exist_ok=True)
    mfa_root = f"{home}/mfa_data"
    os.makedirs(mfa_root, exist_ok=True)
    os.environ["HOME"] = home
    os.environ["MFA_ROOT_DIR"] = mfa_root
    for var in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ.setdefault(var, "1")
    _WORKER_ENGINE = KalpyEngine(model_path, dictionary_path, fst_cache=fst_cache)
    set_keep_q(keep_q)


def _pool_worker_align(ref, audio_path, beam, retry_beam, padding,
                       word_boundary_allocation=None) -> dict:
    """ProcessPoolExecutor task: align one (ref, audio) item.

    Returns a plain result-row dict (picklable); the parent validates it
    through ``ResultRow``.
    """
    from qua_sdk.components.timing.lib import serializable_intervals

    engine = _WORKER_ENGINE
    if engine is None:
        return {"ref": ref, "status": "error", "error": "worker not initialized"}
    try:
        aligner = engine.create_thread_aligner(beam, retry_beam)
        words, timing, mapped_intervals = _align_ref_thread_kalpy(
            engine, aligner, audio_path, ref,
            padding=padding, word_boundary_allocation=word_boundary_allocation)
        nest_phones_in_words(words, mapped_intervals)
        return {"ref": ref, "status": "ok", "words": words,
                "phone_intervals": serializable_intervals(mapped_intervals),
                "cross_word_merges": timing.get("cross_word_merges", []),
                "wb_allocation": timing.get("wb_allocation_applied", {})}
    except Exception as e:
        return {"ref": ref, "status": "error", "error": str(e)}


# ---------------------------------------------------------- batch strategies


def run_batch(items: list[tuple], *,
              engine: KalpyEngine | None, dictionary_path, model_path,
              method: str, beam: int, retry_beam: int,
              use_shared_cmvn: bool, padding: str, wb_allocation: dict,
              keep_q: bool = False, num_threads: int = 1, pool=None) -> list[ResultRow]:
    """Align ``items`` = [(ref, audio_path), ...] and return wire rows.

    Strategy selection (kalpy + live engine only, in priority order):
    shared-CMVN serial batch > process pool (``pool`` provided) > thread pool
    (``num_threads`` > 1) > serial per-item. Per-item failures become error
    rows; the batch itself never raises.

    ``keep_q`` (whether to keep the qalqala Q phone, from the model) is scoped
    via the transforms ContextVar: here for the in-process strategies, and in
    each pool worker's init (ContextVars don't cross the process boundary).
    """
    kalpy_live = method == "kalpy" and engine is not None

    if pool is not None and kalpy_live:
        return _run_batch_pool(items, pool=pool, beam=beam, retry_beam=retry_beam,
                               padding=padding, wb_allocation=wb_allocation)

    with keep_q_context(keep_q):
        if use_shared_cmvn and kalpy_live:
            return _run_batch_shared_cmvn(items, engine=engine, beam=beam, retry_beam=retry_beam,
                                          padding=padding, wb_allocation=wb_allocation)
        if num_threads > 1 and kalpy_live:
            return _run_batch_threaded(items, engine=engine, beam=beam, retry_beam=retry_beam,
                                       padding=padding, wb_allocation=wb_allocation,
                                       num_threads=num_threads, keep_q=keep_q)
        return _run_batch_serial(items, engine=engine, dictionary_path=dictionary_path,
                                 model_path=model_path, method=method, beam=beam,
                                 retry_beam=retry_beam, padding=padding, wb_allocation=wb_allocation)


def _run_batch_shared_cmvn(items, *, engine, beam, retry_beam, padding, wb_allocation):
    """Phonemize all → one engine batch with shared CMVN → recover all."""
    preps = []
    failed = {}  # index → error string
    for i, (ref, _) in enumerate(items):
        try:
            preps.append(prepare_ref(ref))
        except Exception as e:
            logger.warning("item %d ref=%s phonemize failed: %s", i, ref, e)
            preps.append(None)
            failed[i] = str(e)

    work_dir = Path(tempfile.mkdtemp(prefix="mfa_batch_"))
    segments = []
    for i, ((_, audio_path), prep) in enumerate(zip(items, preps)):
        if prep is None:
            continue
        wav_path = work_dir / f"seg_{i:04d}.wav"
        save_as_wav(audio_path, wav_path)
        segments.append((str(wav_path), prep.lab_content))

    all_intervals = engine.align_batch(segments, beam=beam, retry_beam=retry_beam, shared_cmvn=True)

    intervals_iter = iter(all_intervals)
    results: list[ResultRow] = []
    for i, (ref, _) in enumerate(items):
        if i in failed:
            results.append(error_result_row(ref, failed[i]))
            continue
        try:
            intervals = next(intervals_iter)
            words, recovery_timing, mapped_intervals = recover_words(
                intervals, preps[i], include_letters=True, padding=padding,
                word_boundary_allocation=wb_allocation)
            nest_phones_in_words(words, mapped_intervals)
            results.append(ok_result_row(ref, words, mapped_intervals, recovery_timing))
        except Exception as e:
            logger.warning("item %d ref=%s recovery failed: %s", i, ref, e)
            results.append(error_result_row(ref, str(e)))
    return results


def _run_batch_pool(items, *, pool, beam, retry_beam, padding, wb_allocation):
    """Fan items across persistent worker processes (isolated engines)."""
    results_arr: list[ResultRow | None] = [None] * len(items)
    futs = {}
    for i, (ref, audio_path) in enumerate(items):
        futs[pool.submit(_pool_worker_align, ref, audio_path, beam, retry_beam,
                         padding, wb_allocation)] = i
    for f in as_completed(futs):
        i = futs[f]
        try:
            results_arr[i] = ResultRow.model_validate(f.result())
        except Exception as e:
            logger.warning("item %d ref=%s pool failed: %s", i, items[i][0], e)
            results_arr[i] = error_result_row(items[i][0], str(e))
    return list(results_arr)


def _run_batch_threaded(items, *, engine, beam, retry_beam, padding, wb_allocation,
                        num_threads, keep_q=False):
    """Thread pool of N pre-warmed aligners, each checked out per item."""
    results_arr: list[ResultRow | None] = [None] * len(items)

    aligner_pool: queue.Queue = queue.Queue()
    t_pool = time.time()
    for _ in range(num_threads):
        aligner_pool.put(engine.create_thread_aligner(beam, retry_beam))
    logger.debug("aligner pool of %d built in %.2fs", num_threads, time.time() - t_pool)

    def _worker(idx, ref, audio_path):
        set_keep_q(keep_q)  # ContextVars don't propagate into pool threads
        try:
            aligner = aligner_pool.get()
            try:
                words, item_timing, mapped_intervals = _align_ref_thread_kalpy(
                    engine, aligner, audio_path, ref,
                    padding=padding, word_boundary_allocation=wb_allocation)
            finally:
                aligner_pool.put(aligner)
            nest_phones_in_words(words, mapped_intervals)
            results_arr[idx] = ok_result_row(ref, words, mapped_intervals, item_timing)
        except Exception as e:
            logger.warning("item %d ref=%s failed: %s", idx, ref, e)
            results_arr[idx] = error_result_row(ref, str(e))

    with ThreadPoolExecutor(max_workers=num_threads, thread_name_prefix="mfa_thr") as ex:
        futures = [ex.submit(_worker, i, ref, ap) for i, (ref, ap) in enumerate(items)]
        for f in as_completed(futures):
            f.result()

    return list(results_arr)


def _run_batch_serial(items, *, engine, dictionary_path, model_path, method,
                      beam, retry_beam, padding, wb_allocation):
    """Per-item loop — threads=1 or non-kalpy method."""
    results: list[ResultRow] = []
    for i, (ref, audio_path) in enumerate(items):
        try:
            words, item_timing, mapped_intervals = align_ref(
                audio_path, ref,
                engine=engine, dictionary_path=dictionary_path, model_path=model_path,
                method=method, beam=beam, retry_beam=retry_beam,
                padding=padding, word_boundary_allocation=wb_allocation)
            nest_phones_in_words(words, mapped_intervals)
            results.append(ok_result_row(ref, words, mapped_intervals, item_timing))
        except Exception as e:
            logger.warning("item %d ref=%s failed: %s", i, ref, e)
            results.append(error_result_row(ref, str(e)))
    return results
