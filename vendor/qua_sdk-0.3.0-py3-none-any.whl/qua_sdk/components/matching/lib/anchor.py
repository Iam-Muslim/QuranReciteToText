"""Chapter anchoring: phoneme n-gram voting locates (surah, ayah) from ASR output.

Port of the aligner's ``phoneme_anchor``. Each ASR n-gram that hits the Quran
index votes for its (surah, ayah) occurrences, weighted by rarity (1/count).
Top surahs by total weight are shortlisted, then re-ranked by their best
contiguous ayah run; the anchor is the first ayah of the winning run AFTER
leading/trailing low-weight ayahs are trimmed (run_trim_ratio * max weight) —
the trim means clean recitations regularly anchor at ayah > 1, which the
sequencer's lookback window absorbs.
"""

from __future__ import annotations

from collections import defaultdict

from qua_sdk.components.matching.spec import AnchorParams
from qua_sdk.domain.anchor_index import PhonemeNgramIndex
from qua_sdk.domain.chapter_refs import ChapterReference


def _find_best_contiguous_run(
    ayah_weights: dict[int, float],
    run_trim_ratio: float,
) -> tuple[int, int, float]:
    """Highest-total-weight run of consecutive ayahs, trimmed at the edges.

    Returns (start_ayah, end_ayah, total_weight).
    """
    if not ayah_weights:
        return (0, 0, 0.0)

    sorted_ayahs = sorted(ayah_weights.keys())

    runs: list[tuple[int, int, float]] = []  # (start, end, total_weight)
    run_start = sorted_ayahs[0]
    run_end = sorted_ayahs[0]
    run_weight = ayah_weights[sorted_ayahs[0]]

    for i in range(1, len(sorted_ayahs)):
        ayah = sorted_ayahs[i]
        if ayah == run_end + 1:
            run_end = ayah
            run_weight += ayah_weights[ayah]
        else:
            runs.append((run_start, run_end, run_weight))
            run_start = ayah
            run_end = ayah
            run_weight = ayah_weights[ayah]
    runs.append((run_start, run_end, run_weight))

    best_start, best_end, best_weight = max(runs, key=lambda r: r[2])

    # Trim leading/trailing ayahs whose weight < run_trim_ratio * max
    max_w = max(ayah_weights[a] for a in range(best_start, best_end + 1))
    threshold = run_trim_ratio * max_w

    while best_start < best_end and ayah_weights[best_start] < threshold:
        best_weight -= ayah_weights[best_start]
        best_start += 1

    while best_end > best_start and ayah_weights[best_end] < threshold:
        best_weight -= ayah_weights[best_end]
        best_end -= 1

    return (best_start, best_end, best_weight)


def find_anchor_by_voting(
    phoneme_texts: list[list[str]],
    ngram_index: PhonemeNgramIndex,
    params: AnchorParams,
) -> tuple[int, int]:
    """Vote on (surah, ayah) over the first ``params.segments`` non-empty segments.

    Returns (surah, ayah) of the best contiguous-run winner, or (0, 0) when no
    n-gram matches the index at all.
    """
    combined: list[str] = []
    for phonemes in phoneme_texts[: params.segments]:
        if phonemes:
            combined.extend(phonemes)

    n = ngram_index.ngram_size

    asr_ngrams = [tuple(combined[i : i + n]) for i in range(len(combined) - n + 1)]

    # Phase 1: raw voting — accumulate (surah, ayah) weights
    votes: dict[tuple[int, int], float] = defaultdict(float)
    for ng in asr_ngrams:
        if ng not in ngram_index.ngram_positions:
            continue
        weight = (1.0 / ngram_index.ngram_counts[ng]) if params.rarity_weighting else 1.0
        for surah, ayah in ngram_index.ngram_positions[ng]:
            votes[(surah, ayah)] += weight

    if not votes:
        return (0, 0)

    # Phase 1b: pre-filter surahs by total weight
    surah_totals: dict[int, float] = defaultdict(float)
    for (s, _a), w in votes.items():
        surah_totals[s] += w

    ranked_surahs = sorted(surah_totals.items(), key=lambda kv: kv[1], reverse=True)
    top_surahs = [s for s, _ in ranked_surahs[: params.top_candidates]]

    # Phase 2: best contiguous run per candidate surah wins
    best_surah = 0
    best_run_start = 0
    best_run_weight = -1.0

    for s in top_surahs:
        ayah_weights: dict[int, float] = {}
        for (sv, av), w in votes.items():
            if sv == s:
                ayah_weights[av] = w

        run_start, _run_end, run_weight = _find_best_contiguous_run(
            ayah_weights, params.run_trim_ratio)

        if run_weight > best_run_weight:
            best_run_weight = run_weight
            best_surah = s
            best_run_start = run_start

    return (best_surah, best_run_start)


def verse_to_word_index(chapter_ref: ChapterReference, ayah: int) -> int:
    """Word index of the first word of ``ayah`` (0 if the ayah is not found)."""
    for idx, word in enumerate(chapter_ref.words):
        if word.ayah == ayah:
            return idx
    return 0
