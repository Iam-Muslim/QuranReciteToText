"""TaskDecl: the registry shape every task module declares.

A Task is a thin registry declaration over schemas: named inputs, the profile
type, the output, and which pipeline fulfills it by default. ``run()``
isinstance-checks the profile and each declared input against the dotted
types here before any pipeline runs.
"""

from __future__ import annotations

from qua_sdk.schemas.base import SdkModel


class TaskDecl(SdkModel):
    name: str
    inputs: dict[str, str]   # kwarg name → dotted schema type, validated by run()
    profile_schema: str      # dotted profile type, validated by run()
    output_schema: str
    default_pipeline: str    # registry key
