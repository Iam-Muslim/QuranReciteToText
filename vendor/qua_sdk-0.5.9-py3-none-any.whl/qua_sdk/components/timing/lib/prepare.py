"""Ref preparation: phonemize a ref (or reading sequence) into a PreparedRef.

Accepts verse refs ("7:2", "1:1-1:4", "7:2:3-7:2:5"), special refs ("Basmala",
"Isti'adha", case-insensitive), compound refs ("Basmala+2:1:1-2:1:4",
"Isti'adha+Basmala+2:1:1-2:1:4" — special words get continuous "0:0:N"
locations), and reading sequences (``list[str]`` of consecutive refs against
one audio, expressing repeats). The full ref including word ranges goes to the
phonemizer so the last word is correctly marked as stopping (affects tanween
phonemization). Output carries everything recovery needs: word mappings, lab
content, the verse mapping for letters, and detected cross-word merges.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from qua_sdk.components.timing.lib.specials import SPECIAL_KEYS, SPECIAL_WORDS, SpecialWord
from qua_sdk.components.timing.lib.transforms import normalize_phonemes, transform_phonemes
from qua_sdk.components.timing.lib.word_boundary import detect_cross_word_idgham
from qua_sdk.domain import get_phonemizer

logger = logging.getLogger(__name__)

# The model's dedicated boundary-silence phone (the SILENCE recipe). Seeded as a
# lexicon "word" at verse-start / inter-segment / verse-end so MFA models the
# real pause there; it is in ``words.SILENCE_PHONES`` so recovery filters it.
PSIL_TOKEN = "psil"


@dataclass
class PreparedRef:
    """One ref's preparation output, consumed by ``recover.recover_words``.

    A dataclass, not a pydantic model: ``all_words``/``verse_words`` hold
    phonemizer WordMapping objects and ``verse_mapping`` a
    PhonemizationMapping — internal handles, never serialized.
    """

    ref: str | list[str]
    all_words: list                       # WordMapping | SpecialWord, in lab order
    lab_content: str
    verse_mapping: object | None = None   # PhonemizationMapping (letters); None degrades
    verse_words: list = field(default_factory=list)   # verse-only words when prefixed
    special_prefixes: list[str] = field(default_factory=list)
    is_special_only: bool = False
    cross_word_merges: list[dict] = field(default_factory=list)


def phonemize_ref(ref: str):
    """Phonemize a verse ref → (words, mapping, tajweed).

    ``tajweed`` is the cross-word-assimilation source; its failure is soft
    (warn + None) so alignment still succeeds without wb_alloc events.
    """
    pm = get_phonemizer()
    phon_result = pm.phonemize(ref=ref)
    mapping = phon_result.get_mapping()
    try:
        tajweed = phon_result.tajweed_mappings()
    except Exception as e:
        # Warning (not debug) so cross-word allocation regressions are visible
        # in logs — silent fallback hides the loss of all wb_alloc events.
        logger.warning("tajweed_mappings() failed for %s: %s", ref, e)
        tajweed = None
    return mapping.words, mapping, tajweed


def prepare_ref_sequence(seq: list) -> PreparedRef:
    """Phonemize a reading sequence (list of consecutive refs) for one audio.

    Each element is phonemized independently and the ``all_words`` lists
    concatenate in input order, so the recovery cursor emits duplicate
    locations as separate [start, end] pairs. Letter recovery isn't supported
    for sequences (per-verse mappings don't compose across passes) —
    ``verse_mapping=None`` makes recovery degrade to word-level cleanly.
    Cross-word merges offset per line; no inter-line boundaries are detected.
    """
    if not seq:
        raise ValueError("ref sequence must be non-empty")
    parts = [prepare_ref(r) for r in seq]
    all_words = []
    lab_parts = []
    cross_word_merges = []
    offset = 0
    for p in parts:
        for ev in p.cross_word_merges:
            cross_word_merges.append({
                "rule": ev["rule"],
                "first_word_idx": ev["first_word_idx"] + offset,
                "second_word_idx": ev["second_word_idx"] + offset,
            })
        all_words.extend(p.all_words)
        offset += len(p.all_words)
        if p.lab_content:
            lab_parts.append(p.lab_content)
    return PreparedRef(
        ref=list(seq), all_words=all_words,
        lab_content=" ".join(lab_parts),
        cross_word_merges=cross_word_merges,
    )


def prepare_ref(ref: str | list) -> PreparedRef:
    """Phonemize a ref and build lab content for MFA."""
    if isinstance(ref, list):
        return prepare_ref_sequence(ref)

    special_prefixes: list[str] = []
    remaining_ref = ref.strip()
    while True:
        found = False
        for name in SPECIAL_WORDS:
            if remaining_ref.lower().startswith(name.lower() + "+"):
                special_prefixes.append(name)
                remaining_ref = remaining_ref[len(name) + 1:]
                found = True
                break
        if not found:
            break

    is_special_only = False
    verse_mapping = None
    verse_words: list = []
    verse_tajweed = None
    verse_word_offset = 0  # index of first verse word in all_words

    if special_prefixes:
        remaining_special = SPECIAL_KEYS.get(remaining_ref.strip().lower())
        if remaining_special:
            special_prefixes.append(remaining_special)
            remaining_ref = ""

        all_words: list = []
        word_counter = 1
        for sp_name in special_prefixes:
            for w in SPECIAL_WORDS[sp_name]:
                all_words.append(SpecialWord(
                    location=f"0:0:{word_counter}",
                    text=w.text,
                    phonemes=list(w.phonemes),
                ))
                word_counter += 1
        if remaining_ref:
            verse_word_offset = len(all_words)
            verse_words, verse_mapping, verse_tajweed = phonemize_ref(remaining_ref)
            all_words.extend(verse_words)
        else:
            is_special_only = True
    else:
        special_key = SPECIAL_KEYS.get(ref.strip().lower())
        if special_key:
            all_words = SPECIAL_WORDS[special_key]
            is_special_only = True
        else:
            all_words, verse_mapping, verse_tajweed = phonemize_ref(ref)

    if not all_words:
        raise ValueError(f"No words found for reference {ref}")

    lab_phonemes = []
    for w in all_words:
        raw = " ".join(w.phonemes)
        transformed = transform_phonemes(normalize_phonemes(raw))
        if transformed:
            lab_phonemes.append(transformed)
    lab_content = " ".join(lab_phonemes)

    # Cross-word idgham detection runs against the verse portion only — the
    # phonemizer doesn't emit cross-word rules across the special→verse
    # boundary, and special segments have no internal cross-word merges.
    # `verse_words` is only set when a Basmala/Isti'adha prefix is present
    # (so the verse portion is offset inside `all_words`); in the plain-verse
    # case the verse words ARE all_words and the offset is zero.
    cross_word_merges = []
    if verse_tajweed is not None:
        detection_words = verse_words if verse_words else all_words
        verse_events = detect_cross_word_idgham(verse_tajweed, detection_words)
        for ev in verse_events:
            cross_word_merges.append({
                "rule": ev["rule"],
                "first_word_idx": ev["first_word_idx"] + verse_word_offset,
                "second_word_idx": ev["second_word_idx"] + verse_word_offset,
            })

    return PreparedRef(
        ref=ref, all_words=all_words, lab_content=lab_content,
        verse_mapping=verse_mapping, verse_words=verse_words,
        special_prefixes=special_prefixes, is_special_only=is_special_only,
        cross_word_merges=cross_word_merges,
    )


def merge_refs(refs: list[str]) -> str:
    """Merge contiguous single-verse refs into ONE continuous range ref for a
    waṣl span — e.g. ``['74:39:1-74:39:4', '74:40:1-74:40:2']`` →
    ``'74:39:1-74:40:2'``. The phonemizer then phonemizes the span *continuously*:
    the internal verse boundary is non-stopping (waṣl, so the verse-final word
    keeps its tanwīn / drops its qalqala-kubra), and only the span's last word is
    a stop (waqf). Takes the first ref's start endpoint and the last ref's end
    endpoint; the recover-side word-count assertion guards a non-contiguous merge.
    """
    if len(refs) == 1:
        return refs[0]
    first = refs[0].split("-", 1)[0]
    last = refs[-1].rsplit("-", 1)[-1]
    return f"{first}-{last}"


@dataclass
class PreparedChunk:
    """One continuous phonemization within a recitation item.

    A chunk is either a single segment (silence-bounded) or a run of waṣl-
    connected segments phonemized as ONE merged range ref. ``prepared`` is that
    (possibly merged) PreparedRef; ``seg_refs`` / ``seg_word_counts`` let
    ``recover_verse`` split the chunk's recovered words back to the per-segment
    rows (waṣl changes phonemes *within* the junction word, never the word count).
    """

    prepared: object               # PreparedRef
    seg_refs: list[str]
    seg_word_counts: list[int]
    is_wasl: bool = False


@dataclass
class PreparedVerse:
    """A recitation item's ordered segments prepared for ONE MFA pass.

    ``lab_content`` joins the per-chunk labs with the boundary-silence token
    ``psil`` — at item-start, between every adjacent CHUNK, and item-end — when
    ``seed_psil``, so MFA models the real pause at each *silence* boundary and the
    boundary phones stop absorbing it. A waṣl boundary is NOT a chunk boundary
    (no psil, continuous phonemes). ``chunks`` keeps each chunk's PreparedRef so
    ``recover_verse`` runs the existing recovery on each psil-delimited slice then
    splits it back per-segment.
    """

    segment_refs: list[str]
    chunks: list  # list[PreparedChunk], in recitation order
    lab_content: str
    seed_psil: bool = True


def prepare_verse(
    segment_refs: list, *, seed_psil: bool = True, wasl_after: list | None = None
) -> PreparedVerse:
    """Prepare a recitation item's ordered segment refs for a single MFA pass.

    ``wasl_after[i]`` (len ``n-1``) marks the boundary between segment ``i`` and
    ``i+1`` as **waṣl** (continuous, no stop): such segments are merged into ONE
    phonemizer range ref and phonemized continuously, so the verse-final word at
    the junction takes its waṣl form. Every other boundary is **silence**: the
    segments are phonemized independently and joined with ``psil``. With
    ``wasl_after=None`` every boundary is silence — identical to the prior
    whole-verse behaviour (``psil L1 psil L2 … psil``).
    """
    if not segment_refs:
        raise ValueError("prepare_verse needs at least one segment ref")
    n = len(segment_refs)
    if wasl_after is None:
        wasl_after = [False] * (n - 1)

    # Group segments into continuous chunks: a chunk grows while wasl_after is True.
    chunk_idx: list[list[int]] = []
    cur = [0]
    for i in range(n - 1):
        if wasl_after[i]:
            cur.append(i + 1)
        else:
            chunk_idx.append(cur)
            cur = [i + 1]
    chunk_idx.append(cur)

    chunks: list[PreparedChunk] = []
    for idxs in chunk_idx:
        crefs = [segment_refs[i] for i in idxs]
        per_seg = [prepare_ref(r) for r in crefs]   # per-segment counts (robust split-back)
        counts = [len(p.all_words) for p in per_seg]
        if len(idxs) == 1:
            chunks.append(PreparedChunk(per_seg[0], crefs, counts, is_wasl=False))
            continue
        merged = prepare_ref(merge_refs(crefs))
        if len(merged.all_words) != sum(counts):
            # Non-contiguous merge / phonemizer disagreement — degrade this chunk
            # to per-segment psil boundaries (safe: loses only the waṣl junction).
            logger.warning(
                "prepare_verse: waṣl merge word-count mismatch for %s (%d != %d) — "
                "psil fallback", crefs, len(merged.all_words), sum(counts),
            )
            for p, r in zip(per_seg, crefs):
                chunks.append(PreparedChunk(p, [r], [len(p.all_words)], is_wasl=False))
            continue
        chunks.append(PreparedChunk(merged, crefs, counts, is_wasl=True))

    labs = [c.prepared.lab_content for c in chunks]
    if seed_psil:
        lab_content = f"{PSIL_TOKEN} " + f" {PSIL_TOKEN} ".join(labs) + f" {PSIL_TOKEN}"
    else:
        lab_content = " ".join(lb for lb in labs if lb)
    return PreparedVerse(
        segment_refs=list(segment_refs), chunks=chunks,
        lab_content=lab_content, seed_psil=seed_psil,
    )
