"""Regions: speech intervals found in audio (segmentation output)."""

from __future__ import annotations

from pydantic import model_validator

from qua_sdk.schemas.base import SdkModel


class Region(SdkModel):
    start_s: float
    end_s: float

    @model_validator(mode="after")
    def _ordered(self):
        if self.end_s <= self.start_s:
            raise ValueError(f"empty region [{self.start_s}, {self.end_s}]")
        return self

    @property
    def duration_s(self) -> float:
        return self.end_s - self.start_s


class Regions(SdkModel):
    """Ordered, non-overlapping speech intervals. Empty is valid (silence-only audio).

    ``raw`` keeps the detector's pre-cleaning intervals — re-cleaning them with
    new params (the Space's "resegment" loop) needs no second model pass.
    ``detector_state`` is an opaque JSON-able blob a non-interval detector
    (e.g. frame-probability based) stores so its ``clean()`` can re-derive
    regions without a model pass; interval detectors leave it None.
    """

    regions: list[Region]
    is_complete: bool | None = None  # detector's "last region runs to EOF" flag
    raw: list[Region] | None = None  # pre-cleaning model output, for re-cleaning
    audio_duration_s: float | None = None  # padded_floor clamps the last right pad; clean() has no Audio
    detector_state: dict | None = None  # method-owned blob for clean(); see docstring

    def __len__(self) -> int:
        return len(self.regions)

    def __iter__(self):
        return iter(self.regions)
