"""Deterministic fake timing backend for the conformance harness."""

from __future__ import annotations

from typing import ClassVar

from qua_sdk.components.timing.spec import TimingBackend, TimingParams
from qua_sdk.schemas import Alignment, Audio, Timings, WordTiming
from qua_sdk.schemas.timing import SegmentTiming


class FakeTiming(TimingBackend):
    """One word timing spanning each matched segment; words=None for unmatched."""

    Params: ClassVar[type[TimingParams]] = TimingParams

    def timestamps(
        self, audio: Audio, alignment: Alignment, params: TimingParams, *,
        emissions=None, deploy=None,
    ) -> Timings:
        segments = []
        for seg in alignment.segments:
            words = None
            if seg.matched_ref:
                words = [WordTiming(location=seg.matched_ref, start_s=seg.region.start_s, end_s=seg.region.end_s)]
            segments.append(SegmentTiming(segment_id=seg.id, words=words))
        return Timings(granularity=params.granularity, segments=segments, riwayah=alignment.riwayah)
