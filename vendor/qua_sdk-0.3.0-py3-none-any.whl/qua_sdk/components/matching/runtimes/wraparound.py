"""Word-boundary-constrained substring Levenshtein DP with optional wraparound.

Port of the aligner's ``align_wraparound``: ``max_wraps=0`` runs a
rolling-row substring DP; ``max_wraps>0`` runs the full 3D matrix (phoneme x
wrap-count x reference) with parent traceback so repetitions (the reciter
looping back at a word boundary) surface as wrap points. Scoring normalizes
edit cost by max(len(P), matched ref span) and adds a position prior on the
earliest word the path touches. Tie-breaking is sub <= del <= ins, in that
order — parity-critical, do not reorder.

When the compiled ``_dp_core`` Cython extension is importable it handles the
DP (same outcome, much faster); set ``QUA_SDK_PURE_DP=1`` to force the pure
path. The extension's substitution matrix is a process global, so it is
re-initialized whenever a different cost table (or default) comes through.
"""

from __future__ import annotations

import os
from typing import Mapping, NamedTuple

from qua_sdk.domain.sub_costs import SubCostTable

try:
    from qua_sdk.components.matching.runtimes import _dp_core
except ImportError:
    _dp_core = None

# (pairs mapping, matrix default) currently loaded into the _dp_core global matrix
_dp_core_table: tuple[Mapping[tuple[str, str], float], float] | None = None


def _sync_dp_core_table(sub_table: SubCostTable, default: float) -> None:
    """Rebuild the extension's dense matrix when the active cost table changes."""
    global _dp_core_table
    if (
        _dp_core_table is None
        or _dp_core_table[0] is not sub_table.pairs
        or _dp_core_table[1] != default
    ):
        _dp_core.init_substitution_matrix(dict(sub_table.pairs), default)
        _dp_core_table = (sub_table.pairs, default)


class DpOutcome(NamedTuple):
    """Raw DP result; ``best_j is None`` means no candidate ended on a word boundary."""

    best_j: int | None        # end phoneme index in R (exclusive)
    j_start: int | None       # start phoneme index in R
    best_cost: float          # raw edit cost (inf on no match)
    norm_dist: float          # normalized distance used against thresholds
    n_wraps: int
    max_j_reached: int        # furthest R position on the best path
    wrap_points: list         # [(i, j_end, j_start), ...] in path order


_NO_MATCH = DpOutcome(None, None, float("inf"), float("inf"), 0, 0, [])


def align_wraparound(
    P: list[str],
    R: list[str],
    R_phone_to_word: list[int],
    sub_table: SubCostTable,
    *,
    expected_word: int = 0,
    prior_weight: float,
    cost_sub: float,
    cost_del: float,
    cost_ins: float,
    wrap_penalty: float,
    max_wraps: int = 0,
    scoring_mode: str = "additive",
    wrap_score_cost: float,
    wrap_span_weight: float,
) -> DpOutcome:
    """Align ASR phonemes P to a reference window R at word-boundary granularity.

    ``sub_table`` supplies pair-specific substitution costs; pairs not in the
    table cost ``cost_sub`` (exact matches are free).
    """
    if _dp_core is not None and os.environ.get("QUA_SDK_PURE_DP") != "1":
        _sync_dp_core_table(sub_table, cost_sub)
        return DpOutcome(*_dp_core.cy_align_wraparound(
            P, R, R_phone_to_word,
            expected_word, prior_weight,
            cost_sub, cost_del, cost_ins,
            wrap_penalty, max_wraps,
            scoring_mode, wrap_score_cost,
            wrap_span_weight,
        ))

    m, n = len(P), len(R)
    INF = float("inf")

    if m == 0 or n == 0:
        return _NO_MATCH

    pairs = sub_table.pairs

    def get_sub_cost(p: str, r: str) -> float:
        if p == r:
            return 0.0
        return pairs.get((p, r), cost_sub)

    # Precompute word boundary sets
    word_starts = set()
    word_ends = set()
    for j in range(n + 1):
        if j == 0 or (j < n and R_phone_to_word[j] != R_phone_to_word[j - 1]):
            word_starts.add(j)
        if j == n or (j > 0 and j < n and R_phone_to_word[j] != R_phone_to_word[j - 1]):
            word_ends.add(j)

    K = max_wraps

    if K == 0:
        # ---- Rolling-row fast path (no wraparound) ----
        prev_cost = [0.0 if j in word_starts else INF for j in range(n + 1)]
        prev_start = [j if j in word_starts else -1 for j in range(n + 1)]
        curr_cost = [0.0] * (n + 1)
        curr_start = [0] * (n + 1)

        for i in range(1, m + 1):
            curr_cost[0] = i * cost_del if 0 in word_starts else INF
            curr_start[0] = 0 if 0 in word_starts else -1

            for j in range(1, n + 1):
                del_option = prev_cost[j] + cost_del
                ins_option = curr_cost[j - 1] + cost_ins
                sub_option = prev_cost[j - 1] + get_sub_cost(P[i - 1], R[j - 1])

                if sub_option <= del_option and sub_option <= ins_option:
                    curr_cost[j] = sub_option
                    curr_start[j] = prev_start[j - 1]
                elif del_option <= ins_option:
                    curr_cost[j] = del_option
                    curr_start[j] = prev_start[j]
                else:
                    curr_cost[j] = ins_option
                    curr_start[j] = curr_start[j - 1]

            prev_cost, curr_cost = curr_cost, prev_cost
            prev_start, curr_start = curr_start, prev_start

        best_score = INF
        best_j = None
        best_j_start = None
        best_cost_val = INF
        best_norm = INF

        for j in range(1, n + 1):
            if j not in word_ends:
                continue
            if prev_cost[j] >= INF:
                continue
            dist = prev_cost[j]
            j_s = prev_start[j]
            ref_len = j - j_s
            denom = max(m, ref_len, 1)
            nd = dist / denom
            sw = R_phone_to_word[j_s] if j_s < n else R_phone_to_word[j - 1]
            prior = prior_weight * abs(sw - expected_word)
            score = nd + prior
            if score < best_score:
                best_score = score
                best_j = j
                best_j_start = j_s
                best_cost_val = dist
                best_norm = nd

        if best_j is None:
            return _NO_MATCH
        return DpOutcome(best_j, best_j_start, best_cost_val, best_norm, 0, best_j, [])

    # ---- Full 3D matrix with traceback (max_wraps > 0) ----
    dp = [[[INF] * (n + 1) for _ in range(K + 1)] for _ in range(m + 1)]
    parent = [[[None] * (n + 1) for _ in range(K + 1)] for _ in range(m + 1)]
    start_arr = [[[-1] * (n + 1) for _ in range(K + 1)] for _ in range(m + 1)]
    max_j_arr = [[[-1] * (n + 1) for _ in range(K + 1)] for _ in range(m + 1)]
    # Track minimum word index reached along each path so wrap paths can't game
    # the position prior by starting near the expected word then jumping back.
    BIG_W = 999999
    min_w_arr = [[[BIG_W] * (n + 1) for _ in range(K + 1)] for _ in range(m + 1)]

    # Initialize: k=0, free starts at word boundaries
    for j in word_starts:
        dp[0][0][j] = 0.0
        start_arr[0][0][j] = j
        max_j_arr[0][0][j] = j
        min_w_arr[0][0][j] = R_phone_to_word[j] if j < n else BIG_W

    # Fill DP
    for i in range(1, m + 1):
        for k in range(K + 1):
            if k == 0 and 0 in word_starts:
                dp[i][k][0] = i * cost_del
                parent[i][k][0] = (i - 1, k, 0, "D")
                start_arr[i][k][0] = 0
                max_j_arr[i][k][0] = 0
                min_w_arr[i][k][0] = min_w_arr[i - 1][k][0]

            for j in range(1, n + 1):
                del_opt = dp[i - 1][k][j] + cost_del if dp[i - 1][k][j] < INF else INF
                ins_opt = dp[i][k][j - 1] + cost_ins if dp[i][k][j - 1] < INF else INF
                sub_opt = dp[i - 1][k][j - 1] + get_sub_cost(P[i - 1], R[j - 1]) \
                    if dp[i - 1][k][j - 1] < INF else INF

                best = min(del_opt, ins_opt, sub_opt)
                if best < INF:
                    dp[i][k][j] = best
                    w_j = R_phone_to_word[j - 1] if j > 0 else BIG_W
                    if best == sub_opt:
                        parent[i][k][j] = (i - 1, k, j - 1, "S")
                        start_arr[i][k][j] = start_arr[i - 1][k][j - 1]
                        max_j_arr[i][k][j] = max(max_j_arr[i - 1][k][j - 1], j)
                        min_w_arr[i][k][j] = min(min_w_arr[i - 1][k][j - 1], w_j)
                    elif best == del_opt:
                        parent[i][k][j] = (i - 1, k, j, "D")
                        start_arr[i][k][j] = start_arr[i - 1][k][j]
                        max_j_arr[i][k][j] = max_j_arr[i - 1][k][j]
                        min_w_arr[i][k][j] = min_w_arr[i - 1][k][j]
                    else:
                        parent[i][k][j] = (i, k, j - 1, "I")
                        start_arr[i][k][j] = start_arr[i][k][j - 1]
                        max_j_arr[i][k][j] = max(max_j_arr[i][k][j - 1], j)
                        min_w_arr[i][k][j] = min(min_w_arr[i][k][j - 1], w_j)

        # Wrap transitions
        for k in range(K):
            for j_end in word_ends:
                if dp[i][k][j_end] >= INF:
                    continue
                cost_at_end = dp[i][k][j_end]
                for j_s in word_starts:
                    if j_s >= j_end:
                        continue
                    word_span = abs(R_phone_to_word[j_end - 1] - R_phone_to_word[j_s])
                    new_cost = cost_at_end + wrap_penalty + wrap_span_weight * word_span
                    if new_cost < dp[i][k + 1][j_s]:
                        dp[i][k + 1][j_s] = new_cost
                        parent[i][k + 1][j_s] = (i, k, j_end, "W")
                        start_arr[i][k + 1][j_s] = start_arr[i][k][j_end]
                        max_j_arr[i][k + 1][j_s] = max(max_j_arr[i][k][j_end], j_end)
                        min_w_arr[i][k + 1][j_s] = min(min_w_arr[i][k][j_end], R_phone_to_word[j_s])

            # Re-propagate insertions from wrap positions
            for j in range(1, n + 1):
                ins_opt = dp[i][k + 1][j - 1] + cost_ins if dp[i][k + 1][j - 1] < INF else INF
                if ins_opt < dp[i][k + 1][j]:
                    dp[i][k + 1][j] = ins_opt
                    parent[i][k + 1][j] = (i, k + 1, j - 1, "I")
                    start_arr[i][k + 1][j] = start_arr[i][k + 1][j - 1]
                    max_j_arr[i][k + 1][j] = max(max_j_arr[i][k + 1][j - 1], j)
                    w_j = R_phone_to_word[j - 1] if j > 0 else BIG_W
                    min_w_arr[i][k + 1][j] = min(min_w_arr[i][k + 1][j - 1], w_j)

    # Best-match selection
    best_score = INF
    best_j = None
    best_j_start = None
    best_cost_val = INF
    best_norm = INF
    best_k = 0
    best_max_j = 0

    for k in range(K + 1):
        for j in range(1, n + 1):
            if j not in word_ends:
                continue
            if dp[m][k][j] >= INF:
                continue
            dist = dp[m][k][j]
            j_s = start_arr[m][k][j]
            if j_s < 0:
                continue
            mj = max_j_arr[m][k][j]
            ref_len = max(mj, j) - j_s
            if ref_len <= 0:
                continue
            denom = max(m, ref_len, 1)

            if scoring_mode == "no_subtract":
                pc = dist
            else:
                pc = dist - k * wrap_penalty
            nd = pc / denom

            sw = R_phone_to_word[j_s] if j_s < n else R_phone_to_word[j - 1]
            # Use the earliest word the path actually touches for a fair prior
            mw = min_w_arr[m][k][j]
            eff_sw = min(sw, mw) if mw < BIG_W else sw
            prior = prior_weight * abs(eff_sw - expected_word)
            score = nd + prior
            if scoring_mode == "additive":
                score += k * wrap_score_cost

            if score < best_score:
                best_score = score
                best_j = j
                best_j_start = j_s
                best_cost_val = dist
                best_norm = nd
                best_k = k
                best_max_j = mj

    if best_j is None:
        return _NO_MATCH

    # Traceback: walk parent pointers, collect wrap points
    wrap_points = []
    ci, ck, cj = m, best_k, best_j
    while parent[ci][ck][cj] is not None:
        pi, pk, pj, trans = parent[ci][ck][cj]
        if trans == "W":
            wrap_points.append((ci, pj, cj))
        ci, ck, cj = pi, pk, pj
    wrap_points.reverse()

    return DpOutcome(best_j, best_j_start, best_cost_val, best_norm, best_k, best_max_j, wrap_points)
