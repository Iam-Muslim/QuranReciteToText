"""Letter-level timestamps from flat many-to-many (chars → phonemes) mappings.

``split_into_letters`` segments Arabic text on base letters (diacritics stay
attached, tatweel entries drop). ``build_letter_timestamps`` walks the flat
entries against the mapped (geminate-merged, padded) intervals and aggregates
each entry's phones into one [start, end]; ``group_letters_by_word`` then
distributes the letter groups across words, carrying cross-word merge entries
(space inside ``chars``) into the next word as pending letters.
"""

from __future__ import annotations

from qua_sdk.components.timing.lib.words import is_active_phone

# Characters that start a new letter entry. Based on the phonemizer's
# base_phonemes.yaml letters + madd extensions (which get separate entries
# for madd timestamps). Diacritics and other marks attach to the preceding
# letter.
SPLITTABLE_CHARS = {
    "ء",  # HAMZA (U+0621)
    "أ",  # HAMZA_ABOVE_ALEF (U+0623)
    "ؤ",  # HAMZA_WAW (U+0624)
    "إ",  # HAMZA_BELOW_ALEF (U+0625)
    "ئ",  # HAMZA_YA (U+0626)
    "ا",  # ALEF (U+0627)
    "ب",  # BA (U+0628)
    "ة",  # TAA_MARBUTA (U+0629)
    "ت",  # TA (U+062A)
    "ث",  # THA (U+062B)
    "ج",  # JEEM (U+062C)
    "ح",  # HHA (U+062D)
    "خ",  # KHA (U+062E)
    "د",  # DAL (U+062F)
    "ذ",  # THAL (U+0630)
    "ر",  # RA (U+0631)
    "ز",  # ZAIN (U+0632)
    "س",  # SEEN (U+0633)
    "ش",  # SHEEN (U+0634)
    "ص",  # SAD (U+0635)
    "ض",  # DAD (U+0636)
    "ط",  # TTA (U+0637)
    "ظ",  # DTHA (U+0638)
    "ع",  # AIN (U+0639)
    "غ",  # GHAIN (U+063A)
    "ف",  # FA (U+0641)
    "ق",  # QAF (U+0642)
    "ك",  # KAF (U+0643)
    "ل",  # LAM (U+0644)
    "م",  # MEEM (U+0645)
    "ن",  # NOON (U+0646)
    "ه",  # HA (U+0647)
    "و",  # WAW (U+0648)
    "ى",  # ALEF_MAKSURA (U+0649)
    "ي",  # YA (U+064A)
    "ٱ",  # HAMZA_WASL (U+0671)
    "ٰ",  # DAGGER_ALEF (U+0670)
    "ۥ",  # MINI_WAW (U+06E5)
    "ۦ",  # MINI_YA_END (U+06E6)
    "ۧ",  # MINI_YA_MIDDLE (U+06E7)
}

TATWEEL = "ـ"  # U+0640 — filtered from letter output


def split_into_letters(text: str) -> list[str]:
    """Split text into letters; diacritics stay with the preceding letter,
    tatweel-only entries are filtered out."""
    if not text:
        return []

    letters = []
    current = ""

    for ch in text:
        if ch in SPLITTABLE_CHARS:
            if current:
                letters.append(current)
            current = ch
        else:
            current += ch

    if current:
        letters.append(current)

    return [letter for letter in letters if letter[0] != TATWEEL]


def build_letter_timestamps(
    intervals: list[dict],
    flat_entries: list[tuple[str, list[str]]],
    phoneme_sequence: list[str],
) -> list[dict]:
    """Aggregate each flat entry's phones into one letter-group timestamp.

    ``intervals`` are mapped intervals (geminates merged, original names,
    padded) — 1-to-1 with ``phoneme_sequence`` after filtering to active
    phones. ``Q`` normally consumes no interval (production strips it before
    alignment); under a Q-AWARE align (qalqala model, ``QUA_KEEP_Q``) the model
    DOES emit a ``Q`` interval, so we consume it only when the next active
    interval is actually a ``Q`` — attaching the qalqala bounce to its stop
    letter and keeping the cursor in lock-step. Without that guard a real Q
    interval is left unconsumed and every following phone maps one interval too
    early (the qalqala off-by-one). Entries whose phones all skipped (e.g. a
    plain-flow Q) inherit the next group's start as a zero-width timestamp.
    Returns ``[{chars, start, end, is_word_end}, ...]`` where a space
    suffix/interior on ``chars`` marks a word boundary.
    """
    active_phones = []  # interval indices of active phones, in order
    for idx, iv in enumerate(intervals):
        if is_active_phone(iv.get("phone", "")):
            active_phones.append(idx)

    def _is_q(idx: int) -> bool:
        return intervals[idx].get("phone", "").split("_")[0] == "Q"

    orig_to_mfa: list[list[int]] = []
    cursor = 0
    for orig_ph in phoneme_sequence:
        if orig_ph == "Q":
            # Consume the Q interval IFF the align actually produced one here
            # (Q-aware). Plain flow: next active phone is not Q → skip, identical
            # to legacy behaviour (production path byte-for-byte unchanged).
            if cursor < len(active_phones) and _is_q(active_phones[cursor]):
                orig_to_mfa.append([active_phones[cursor]])
                cursor += 1
            else:
                orig_to_mfa.append([])
        elif cursor < len(active_phones):
            orig_to_mfa.append([active_phones[cursor]])
            cursor += 1
        else:
            orig_to_mfa.append([])

    letter_groups = []
    orig_cursor = 0
    for chars, phonemes in flat_entries:
        is_word_end = chars.endswith(" ") or (" " in chars and not chars.endswith(" "))
        chars_clean = chars.rstrip(" ")

        if not phonemes:
            letter_groups.append({
                "chars": chars_clean,
                "start": None,
                "end": None,
                "is_word_end": is_word_end,
            })
            continue

        mfa_indices = []
        for _ in phonemes:
            if orig_cursor < len(orig_to_mfa):
                mfa_indices.extend(orig_to_mfa[orig_cursor])
            orig_cursor += 1

        if mfa_indices:
            start = intervals[min(mfa_indices)]["start"]
            end = intervals[max(mfa_indices)]["end"]
        else:
            start, end = None, None

        letter_groups.append({
            "chars": chars_clean,
            "start": start,
            "end": end,
            "is_word_end": is_word_end,
        })

    # Groups with no intervals (e.g. Q phoneme) inherit the next group's start.
    for i in range(len(letter_groups) - 1):
        curr = letter_groups[i]
        next_g = letter_groups[i + 1]
        if curr["end"] is None and next_g["start"] is not None:
            curr["start"] = next_g["start"]
            curr["end"] = next_g["start"]

    return letter_groups


def group_letters_by_word(letter_groups: list[dict], words: list[dict]) -> list[dict]:
    """Distribute letter groups across words (2dp rounding happens here).

    A group with a space INSIDE ``chars`` spans two words: the first part's
    letters close the current word, the remainder becomes pending letters for
    the next word at the same timestamps. Returns word rows with ``letters``.
    """
    result = []
    group_idx = 0
    pending_chars = None  # leftover from a cross-word merge
    pending_timestamps = (None, None)

    for word in words:
        word_letters = []

        if pending_chars:
            for letter in split_into_letters(pending_chars):
                start, end = pending_timestamps
                if start is not None and end is not None:
                    word_letters.append({
                        "char": letter,
                        "start": round(start, 2),
                        "end": round(end, 2),
                    })
                else:
                    word_letters.append({"char": letter, "start": None, "end": None})
            pending_chars = None
            pending_timestamps = (None, None)

        while group_idx < len(letter_groups):
            group = letter_groups[group_idx]
            chars = group["chars"]
            start = group["start"]
            end = group["end"]
            is_word_end = group["is_word_end"]

            if " " in chars:
                # Cross-word merge: chars like "ن ر" span two words.
                parts = chars.split(" ", 1)
                for letter in split_into_letters(parts[0]):
                    if start is not None and end is not None:
                        word_letters.append({
                            "char": letter,
                            "start": round(start, 2),
                            "end": round(end, 2),
                        })
                    else:
                        word_letters.append({"char": letter, "start": None, "end": None})

                if len(parts) > 1 and parts[1]:
                    pending_chars = parts[1]
                    pending_timestamps = (start, end)

                group_idx += 1
                break
            else:
                for letter in split_into_letters(chars):
                    if start is not None and end is not None:
                        word_letters.append({
                            "char": letter,
                            "start": round(start, 2),
                            "end": round(end, 2),
                        })
                    else:
                        word_letters.append({"char": letter, "start": None, "end": None})

                group_idx += 1

                if is_word_end:
                    break

        result.append({
            "location": word["location"],
            "text": word["text"],
            "start": round(word["start"], 2),
            "end": round(word["end"], 2),
            "phone_indices": word.get("phone_indices", []),
            "letters": word_letters,
        })

    return result
