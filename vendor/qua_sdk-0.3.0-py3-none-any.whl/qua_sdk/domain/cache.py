"""Pickle disk cache for built domain artifacts (chapter refs, n-gram index).

Location: ``$QUA_SDK_CACHE_DIR``, else ``%LOCALAPPDATA%/qua_sdk`` on Windows,
else ``~/.cache/qua_sdk``. Filenames embed the version key, so a schema bump,
phonemizer upgrade, or mode change builds a fresh file instead of mutating in
place. ``qua-sdk-build-caches`` prebuilds everything.
"""

from __future__ import annotations

import os
import pickle
import re
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Callable, TypeVar

T = TypeVar("T")

SCHEMA_VERSION = 1  # bump when a cached artifact shape changes


def cache_dir() -> Path:
    override = os.environ.get("QUA_SDK_CACHE_DIR")
    if override:
        return Path(override)
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "qua_sdk"
    return Path.home() / ".cache" / "qua_sdk"


def version_key(*parts: object) -> str:
    """Schema version + quranic-phonemizer version + caller parts (mode/riwayah/…)."""
    try:
        pm = version("quranic-phonemizer")
    except PackageNotFoundError:
        pm = "none"
    return "-".join([f"s{SCHEMA_VERSION}", f"pm{pm}", *map(str, parts)])


def load_or_build(name: str, version_key: str, builder: Callable[[], T]) -> T:
    key = re.sub(r"[^A-Za-z0-9._-]", "_", version_key)
    path = cache_dir() / f"{name}.{key}.pkl"
    if path.exists():
        try:
            with open(path, "rb") as f:
                return pickle.load(f)
        except Exception:
            path.unlink(missing_ok=True)  # corrupt/stale-format cache: rebuild
    artifact = builder()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    with open(tmp, "wb") as f:
        pickle.dump(artifact, f, protocol=pickle.HIGHEST_PROTOCOL)
    tmp.replace(path)
    return artifact
