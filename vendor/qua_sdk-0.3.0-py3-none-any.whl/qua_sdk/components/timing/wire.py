"""Producer-side wire models for the MFA Space's /align_batch response.

STRICT (SdkModel, extra=forbid) because this is the shape WE emit — the Space
builds its response through these models, and the golden-fixture round-trip
test pins every key set. Consumers stay tolerant (``remote_space.MfaWordRow``
is the ``extra="allow"`` reader); producer strictness + consumer tolerance is
the compatibility contract.

Dump rules mirror the legacy dict-literal payloads exactly: optional row
fields (a degraded word's ``letters``, an ok row's ``error``) are ABSENT, not
null — while a failed letter's ``start``/``end`` ARE null. The wrap
serializers below encode that distinction.
"""

from __future__ import annotations

from typing import Literal

from pydantic import model_serializer

from qua_sdk.schemas.base import SdkModel

WbChoice = Literal["asis", "first", "second"]
WbRule = Literal[
    "idgham_ghunnah_noon",
    "idgham_bila_ghunnah_noon",
    "idgham_ghunnah_tanween",
    "idgham_bila_ghunnah_tanween",
    "idgham_shafawi",
    "idgham_mutamathilayn",
    "idgham_mutaqaribayn",
    "idgham_mutajanisayn",
]


class PhoneIntervalRow(SdkModel):
    """One mapped phone interval (original phoneme names, silences included).
    Geminate flags are always serialized — a merged geminate's head row sets
    ``geminate_start``, its empty-phone tail ``geminate_end``."""

    start: float
    end: float
    phone: str
    geminate_start: bool = False
    geminate_end: bool = False


class WordPhone(SdkModel):
    """One active phone nested under a word (4dp)."""

    phone: str
    start: float
    end: float


class LetterRow(SdkModel):
    """One letter of a word (2dp). ``start``/``end`` are null (NOT absent)
    when the letter has no recovered timestamp."""

    char: str
    start: float | None
    end: float | None


class WordRow(SdkModel):
    """One word row (2dp start/end). ``letters`` is absent — not null — when
    letter recovery degraded for the item; ``phones`` is always nested in
    batch responses."""

    location: str
    text: str
    start: float
    end: float
    phone_indices: list[int]
    letters: list[LetterRow] | None = None
    phones: list[WordPhone]

    @model_serializer(mode="wrap")
    def _serialize(self, handler):
        data = handler(self)
        if self.letters is None:
            data.pop("letters")
        return data


class CrossWordMerge(SdkModel):
    """One detected cross-word idgham event (0-based word indices)."""

    rule: WbRule
    first_word_idx: int
    second_word_idx: int


class ResultRow(SdkModel):
    """One per-item result. ok rows carry words + debug surfaces; error rows
    carry only the echoed ref + error message."""

    ref: str | list[str]
    status: Literal["ok", "error"]
    words: list[WordRow] | None = None
    phone_intervals: list[PhoneIntervalRow] | None = None
    cross_word_merges: list[CrossWordMerge] | None = None
    wb_allocation: dict[WbRule, WbChoice] | None = None
    error: str | None = None

    @model_serializer(mode="wrap")
    def _serialize(self, handler):
        data = handler(self)
        return {k: v for k, v in data.items() if v is not None}


class BatchEnvelope(SdkModel):
    """The /align_batch final payload. Error envelopes carry ``error`` and may
    omit count/elapsed/shared_cmvn (and even ``results``, for input-validation
    failures)."""

    status: Literal["ok", "error"]
    count: int | None = None
    elapsed_seconds: float | None = None
    shared_cmvn: bool | None = None
    results: list[ResultRow] | None = None
    error: str | None = None

    @model_serializer(mode="wrap")
    def _serialize(self, handler):
        data = handler(self)
        return {k: v for k, v in data.items() if v is not None}


def ok_result_row(ref, words: list[dict], mapped_intervals: list[dict], timing: dict) -> ResultRow:
    """Assemble an ok row from ``recover_words`` (+ nested phones) output."""
    from qua_sdk.components.timing.lib.words import serializable_intervals

    return ResultRow(
        ref=ref,
        status="ok",
        words=[WordRow.model_validate(w) for w in words],
        phone_intervals=[
            PhoneIntervalRow.model_validate(iv) for iv in serializable_intervals(mapped_intervals)
        ],
        cross_word_merges=[
            CrossWordMerge.model_validate(ev) for ev in timing.get("cross_word_merges", [])
        ],
        wb_allocation=timing.get("wb_allocation_applied", {}),
    )


def error_result_row(ref, error: str) -> ResultRow:
    return ResultRow(ref=ref, status="error", error=error)
