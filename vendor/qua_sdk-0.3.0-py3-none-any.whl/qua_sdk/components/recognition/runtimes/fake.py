"""Deterministic fake recognizer for the conformance harness."""

from __future__ import annotations

from typing import ClassVar

from qua_sdk.components.recognition.spec import RecognitionParams, Recognizer
from qua_sdk.schemas import Audio, Emissions, Regions


class FakeRecognizer(Recognizer):
    """Emits ``region-index``-derived tokens; longer regions emit more tokens."""

    Params: ClassVar[type[RecognitionParams]] = RecognitionParams

    def transcribe(self, audio: Audio, regions: Regions, params: RecognitionParams, *, deploy=None) -> Emissions:
        tokens = [
            [f"p{i}_{k}" for k in range(max(1, int(r.duration_s * 4)))]
            for i, r in enumerate(regions)
        ]
        return Emissions(tokens=tokens, inventory_mode=params.inventory_mode or "full")
