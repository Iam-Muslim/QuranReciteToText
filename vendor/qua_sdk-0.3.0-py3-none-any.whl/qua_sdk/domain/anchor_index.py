"""Quran-wide phoneme n-gram index: anchor voting locates the chapter from ASR output.

N-grams are extracted per verse (no cross-verse grams) with the same per-word
simple-mode collapse rule as chapter refs. ``load_ngram_index`` goes through
the domain disk cache.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from functools import lru_cache

from qua_sdk.domain.cache import load_or_build, version_key
from qua_sdk.domain.chapter_refs import get_phonemizer, maybe_collapse


@dataclass
class PhonemeNgramIndex:
    """Pre-computed n-gram index for the entire Quran."""

    ngram_positions: dict[tuple[str, ...], list[tuple[int, int]]]  # ngram → (surah, ayah) occurrences
    ngram_counts: dict[tuple[str, ...], int]                       # ngram → total count (rarity weighting)
    ngram_size: int
    total_ngrams: int


def build_ngram_index(ngram_size: int, mode: str = "full") -> PhonemeNgramIndex:
    """Phonemize the whole Quran and index every per-verse phoneme n-gram."""
    result = get_phonemizer().phonemize(ref="1-114", stop_signs=["verse"])

    verse_phonemes: dict[tuple[int, int], list[str]] = defaultdict(list)
    for word, phonemes in zip(result._words, result._nested):
        if not phonemes:
            continue
        loc = word.location
        verse_phonemes[(loc.surah_num, loc.ayah_num)].extend(maybe_collapse(phonemes, mode))

    ngram_positions: dict[tuple[str, ...], list[tuple[int, int]]] = defaultdict(list)
    total_ngrams = 0
    for (surah, ayah), phonemes in verse_phonemes.items():
        if len(phonemes) < ngram_size:
            continue
        for i in range(len(phonemes) - ngram_size + 1):
            ng = tuple(phonemes[i : i + ngram_size])
            ngram_positions[ng].append((surah, ayah))
            total_ngrams += 1

    return PhonemeNgramIndex(
        ngram_positions=dict(ngram_positions),
        ngram_counts={ng: len(pos) for ng, pos in ngram_positions.items()},
        ngram_size=ngram_size,
        total_ngrams=total_ngrams,
    )


@lru_cache(maxsize=4)
def load_ngram_index(mode: str = "full", ngram_size: int = 5, riwayah: str = "hafs") -> PhonemeNgramIndex:
    return load_or_build("ngram_index", version_key(mode, riwayah, f"n{ngram_size}"),
                         lambda: build_ngram_index(ngram_size, mode))
