"""Alignment: matched text spans per segment (matching output).

Field shapes mirror today's SegmentInfo / DetailedSegment: ``matched_ref`` is a
word-location span ("2:255:1-2:255:5") or a special name ("Basmala", ...).
Segments carry a stable ``id`` — merges (Tahmeed) and splits (fused Basmala)
mean ``len(alignment) != len(input regions)`` in general; never join stage
outputs by list position, join by ``id``.
"""

from __future__ import annotations

from qua_sdk.schemas.base import SdkModel
from qua_sdk.schemas.regions import Region


class AlignedSegment(SdkModel):
    id: int                              # stable within one result; join key for Timings
    region: Region                       # may differ from input regions (merge/split)
    matched_ref: str | None = None       # None = no match (low confidence)
    matched_text: str = ""
    confidence: float = 0.0              # 1 - normalized edit distance
    error: str | None = None             # human-readable failure ("Low confidence")
    wrap_word_ranges: list[list[str]] | None = None  # [["2:255:1","2:255:5"], ...]
    has_missing_words: bool = False
    merged_into: int | None = None       # id of segment this was consumed by
    merge_reason: str | None = None      # why it was consumed: "tahmeed" | "waqf_sakt"
    split_from: int | None = None        # id of segment this was split out of
    filtered: bool = False               # special excluded by SpecialsParams.filter; row kept for provenance


class Alignment(SdkModel):
    segments: list[AlignedSegment]
    chapter: int | None = None           # primary anchored surah (None if undetected)
    inventory_mode: str = "full"         # open set, see domain.inventory
    riwayah: str = "hafs"                # open set; text identity refs are relative to

    def __len__(self) -> int:
        return len(self.segments)

    def __iter__(self):
        return iter(self.segments)

    @property
    def matched(self) -> list[AlignedSegment]:
        """Renderable matches: excludes consumed-by-merge and filtered rows."""
        return [
            s for s in self.segments
            if s.matched_ref and s.merged_into is None and not s.filtered
        ]
