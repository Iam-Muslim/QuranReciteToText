"""Per-chapter phoneme references: the matcher's view of the Quran text.

The reference is ALWAYS phonemized in the full inventory, then collapsed PER
WORD for simple mode: ``Phonemizer.phonemize(mode="simple")`` does not collapse
emitted phonemes in the pinned phonemizer — ``simple_mode.collapse_phonemes``
(the same helper that built the simple model's training targets) is the only
correct path. Builders are pure; ``load_chapter_refs`` goes through the domain
disk cache (one full-Quran phonemize pass per mode).
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from functools import lru_cache

from qua_sdk.domain.cache import load_or_build, version_key
from qua_sdk.domain.refs import parse_location


@lru_cache(maxsize=1)
def get_phonemizer():
    from quranic_phonemizer import Phonemizer  # lazy: heavy data load

    return Phonemizer()


def collapse_to_simple(phonemes) -> list[str]:
    from quranic_phonemizer.simple_mode import collapse_phonemes

    return list(collapse_phonemes(phonemes))


def maybe_collapse(phonemes, mode: str) -> list[str]:
    """Collapse to the simple inventory iff mode == 'simple'; else pass through."""
    return collapse_to_simple(phonemes) if mode == "simple" else list(phonemes)


@dataclass
class RefWord:
    """Reference word with phoneme metadata."""

    text: str              # Arabic text
    phonemes: list[str]
    surah: int
    ayah: int
    word_num: int          # 1-indexed within verse

    @property
    def location(self) -> str:
        return f"{self.surah}:{self.ayah}:{self.word_num}"


@dataclass
class ChapterReference:
    """Pre-built reference data for a chapter, pre-flattened for windowed DP."""

    surah: int
    words: list[RefWord]
    avg_phones_per_word: float
    flat_phonemes: list[str]        # all phonemes concatenated
    flat_phone_to_word: list[int]   # word index for each phoneme (chapter-global)
    word_phone_offsets: list[int]   # prefix sum + sentinel: word i starts at offset[i]

    @property
    def num_words(self) -> int:
        return len(self.words)


def _assemble(surah: int, words: list[RefWord]) -> ChapterReference:
    total_phones = sum(len(w.phonemes) for w in words)
    avg_phones_per_word = total_phones / len(words) if words else 4.0
    flat_phonemes: list[str] = []
    flat_phone_to_word: list[int] = []
    word_phone_offsets: list[int] = []
    for word_idx, word in enumerate(words):
        word_phone_offsets.append(len(flat_phonemes))
        for ph in word.phonemes:
            flat_phonemes.append(ph)
            flat_phone_to_word.append(word_idx)
    word_phone_offsets.append(len(flat_phonemes))  # sentinel for slicing
    return ChapterReference(
        surah=surah,
        words=words,
        avg_phones_per_word=avg_phones_per_word,
        flat_phonemes=flat_phonemes,
        flat_phone_to_word=flat_phone_to_word,
        word_phone_offsets=word_phone_offsets,
    )


def build_chapter_reference(surah: int, mode: str = "full") -> ChapterReference:
    """Phonemize one chapter (verse-boundary stopping rules) and build its reference."""
    result = get_phonemizer().phonemize(ref=str(surah), stop_signs=["verse"])
    words = []
    for word in result.get_mapping().words:
        loc = parse_location(word.location)
        words.append(RefWord(
            text=word.text,
            phonemes=maybe_collapse(word.phonemes, mode),
            surah=loc.surah,
            ayah=loc.ayah,
            word_num=loc.word,
        ))
    return _assemble(surah, words)


def build_all_chapter_references(mode: str = "full") -> dict[int, ChapterReference]:
    """One full-Quran phonemize pass → all 114 chapter references.

    Reads ``_words``/``_nested`` directly — get_mapping() is too slow corpus-wide.
    """
    result = get_phonemizer().phonemize(ref="1-114", stop_signs=["verse"])
    surah_words: dict[int, list[RefWord]] = defaultdict(list)
    for word, phonemes in zip(result._words, result._nested):
        loc = word.location
        surah_words[loc.surah_num].append(RefWord(
            text=word.text,
            phonemes=maybe_collapse(phonemes, mode),
            surah=loc.surah_num,
            ayah=loc.ayah_num,
            word_num=loc.word_num,
        ))
    return {s: _assemble(s, surah_words[s]) for s in sorted(surah_words)}


@lru_cache(maxsize=4)
def load_chapter_refs(mode: str = "full", riwayah: str = "hafs") -> dict[int, ChapterReference]:
    """All chapter references via the disk cache. riwayah keys the artifact for
    the Qira'at expansion; the phonemizer is hafs-only today."""
    return load_or_build("chapter_refs", version_key(mode, riwayah),
                         lambda: build_all_chapter_references(mode))
