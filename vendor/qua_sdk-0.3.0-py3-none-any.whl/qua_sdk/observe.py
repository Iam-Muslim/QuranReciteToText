"""Per-stage metrics sink: runtimes record, pipelines collect.

``record_metrics(**kv)`` is a no-op unless a ``collect_stage_metrics()`` block
is active in the current context — runtimes call it unconditionally, no sink
plumbing through signatures. ContextVar-backed, so concurrent threads/tasks
each see their own sink. Values are coerced to JSON-safe scalars on record
(numpy scalars → python, unknown objects → ``str``) so a finished result
always serializes. ``run_stage`` is the pipeline-side wrapper: time a stage,
collect its metrics, record a StageMeta.
"""

from __future__ import annotations

import time
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any, Callable, Iterator

import numpy as np

from qua_sdk.schemas.results import StageMeta

_SINK: ContextVar[dict | None] = ContextVar("qua_sdk_metrics_sink", default=None)


def _json_safe(value: Any) -> Any:
    """Coerce one metric value to something json.dumps accepts."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.ndarray):
        return [_json_safe(v) for v in value.tolist()]
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    return str(value)


@contextmanager
def collect_stage_metrics() -> Iterator[dict]:
    """Collect every ``record_metrics`` call inside the block into the yielded dict."""
    metrics: dict = {}
    token = _SINK.set(metrics)
    try:
        yield metrics
    finally:
        _SINK.reset(token)


def record_metrics(**kv) -> None:
    """Merge JSON-safe key/values into the active sink; silent no-op without one."""
    sink = _SINK.get()
    if sink is not None:
        sink.update({k: _json_safe(v) for k, v in kv.items()})


def run_stage(stages: dict[str, StageMeta], name: str, key: str, fn: Callable[[], Any]) -> Any:
    """Run one pipeline stage: time ``fn``, collect its ``record_metrics``
    calls, store a StageMeta under ``stages[name]``; return ``fn``'s output."""
    t0 = time.perf_counter()
    with collect_stage_metrics() as metrics:
        out = fn()
    stages[name] = StageMeta(component_key=key, wall_s=time.perf_counter() - t0, metrics=metrics)
    return out
