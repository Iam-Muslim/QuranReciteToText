"""Console entry points.

``qua-sdk-build-caches`` prebuilds the pickled domain artifacts (chapter refs
and n-gram index, both inventory modes, plus the quran index) so a fresh
environment's first alignment skips the build pass. Requires quranic-phonemizer.
"""

from __future__ import annotations

import time


def build_caches() -> None:
    from qua_sdk.domain.anchor_index import load_ngram_index
    from qua_sdk.domain.cache import cache_dir
    from qua_sdk.domain.chapter_refs import load_chapter_refs
    from qua_sdk.domain.quran_index import load_quran_index

    print(f"cache dir: {cache_dir()}")
    for mode in ("full", "simple"):
        t0 = time.perf_counter()
        refs = load_chapter_refs(mode)
        print(f"chapter refs [{mode}]: {len(refs)} chapters ({time.perf_counter() - t0:.1f}s)")
        t0 = time.perf_counter()
        idx = load_ngram_index(mode)
        print(f"ngram index [{mode}]: {len(idx.ngram_positions)} unique {idx.ngram_size}-grams "
              f"({time.perf_counter() - t0:.1f}s)")
    t0 = time.perf_counter()
    qi = load_quran_index()
    print(f"quran index: {len(qi.words)} words ({time.perf_counter() - t0:.1f}s)")
