"""Inter-component I/O types (the "Schema" layer). Imports domain only.

One schema per seam: Audio → Regions (segmentation) → Emissions (recognition)
→ Alignment (matching) → Timings (timing). Components agree only through these.
"""

from qua_sdk.schemas.audio import Audio
from qua_sdk.schemas.regions import Region, Regions
from qua_sdk.schemas.emissions import Emissions
from qua_sdk.schemas.alignment import AlignedSegment, Alignment
from qua_sdk.schemas.timing import Granularity, Timings, WordTiming

__all__ = [
    "Audio", "Region", "Regions", "Emissions",
    "AlignedSegment", "Alignment", "Granularity", "Timings", "WordTiming",
]
