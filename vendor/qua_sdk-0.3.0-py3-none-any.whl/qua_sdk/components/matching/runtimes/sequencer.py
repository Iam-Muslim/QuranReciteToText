"""The stateful matching sequence: specials, retries, reanchors, gaps — in order.

Structural 1:1 port of the aligner's ``run_phoneme_matching`` (config constants
replaced by ``WraparoundDpParams``, module caches by ``MatchingResources``). The
output ``results`` keep the exact legacy tuple shapes: specials are 3-tuples
``(text, score, ref)``, Quran matches 4-tuples ``(text, score, ref, wrap_ranges)``,
failures ``("", 0.0, "", None)``. Per-iteration order is fixture-locked:
skip handling -> transition mode -> primary align -> chapter boundary ->
basmala-fused retry -> success/failure (transition check -> single retry ->
consecutive-failure reanchor). See ``chapter_flow.py`` for the boundary steps.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

from qua_sdk.components.matching.lib.anchor import verse_to_word_index
from qua_sdk.components.matching.runtimes.chapter_flow import (
    SeqState,
    chapter_boundary_step,
    maybe_tahmeed_merge,
    transition_mode_step,
)
from qua_sdk.components.matching.lib.specials import (
    SPECIAL_TEXT,
    TRANSITION_TEXT,
    SpecialHit,
    SpecialTemplates,
    templates_for,
)
from qua_sdk.components.matching.runtimes.windows import get_matched_text
from qua_sdk.components.matching.runtimes.wraparound_params import WraparoundDpParams
from qua_sdk.domain.anchor_index import PhonemeNgramIndex, load_ngram_index
from qua_sdk.domain.chapter_refs import ChapterReference, load_chapter_refs
from qua_sdk.domain.sub_costs import SubCostTable, load_sub_costs

_BASMALA_REFS = ("Basmala", "Isti'adha+Basmala")


@dataclass(frozen=True)
class MatchingResources:
    """Everything mode-dependent the sequencer reads: refs, index, costs, templates."""

    mode: str
    chapter_refs: dict[int, ChapterReference]
    ngram_index: PhonemeNgramIndex
    sub_table: SubCostTable
    templates: SpecialTemplates

    @classmethod
    def for_mode(cls, mode: str, params: WraparoundDpParams) -> "MatchingResources":
        return cls(
            mode=mode,
            chapter_refs=load_chapter_refs(mode),
            ngram_index=load_ngram_index(mode, params.anchor.ngram_size),
            sub_table=load_sub_costs(mode),
            templates=templates_for(mode),
        )


@dataclass
class SequenceOutcome:
    """run_matching_sequence output: legacy result tuples + bookkeeping."""

    results: list                       # specials 3-tuples, matches 4-tuples
    word_indices: list                  # (start_word_idx, end_word_idx) or None per result
    gap_segments: set                   # result indices flanking missing words
    merged_into: dict                   # {consumed result idx: target result idx}
    repetition_segments: set            # result indices where wraps were detected
    metrics: dict                       # legacy profiling counters (always on)
    events: list = field(default_factory=list)


def run_matching_sequence(
    phoneme_texts: list[list[str]],
    *,
    start_surah: int,
    first_quran_idx: int = 0,
    special_results: Optional[list[SpecialHit]] = None,
    start_pointer: int = 0,
    params: WraparoundDpParams,
    resources: MatchingResources,
    on_event: Optional[Callable[[dict], None]] = None,
) -> SequenceOutcome:
    """Match each segment's phonemes to the Quran, tracking chapter flow.

    ``special_results`` (SpecialHits from the opening-specials scan) seed the
    results list as legacy rows; ``start_pointer`` is the anchor-voted word
    pointer into ``start_surah``. Events mirror the legacy debug-collector
    stream.
    """
    st = SeqState(
        phoneme_texts=phoneme_texts,
        first_quran_idx=first_quran_idx,
        params=params,
        resources=resources,
        on_event=on_event,
        detected_surah=start_surah,
        chapter_ref=resources.chapter_refs[start_surah],
        pointer=start_pointer,
    )
    st.results = [h.as_tuple() for h in special_results] if special_results else []
    st.word_indices = [None] * len(st.results)

    basmala_already_detected = any(
        h.ref in _BASMALA_REFS for h in (special_results or [])
    )
    st.is_first_after_transition = not basmala_already_detected

    for i, asr_phonemes in enumerate(phoneme_texts[first_quran_idx:]):
        # Segments consumed by inter-chapter special detection
        if st.skip_count > 0:
            st.results.append(st.pending_specials.pop(0))
            st.word_indices.append(None)
            st.skip_count -= 1
            continue

        # Segments consumed by Tahmeed merge (sami'a + rabbana split across segments)
        if st.tahmeed_merge_skip > 0:
            st.results.append(("", 0.0, "", None))
            st.word_indices.append(None)
            st.tahmeed_merge_skip -= 1
            st.transition_skips += 1
            continue

        segment_idx = first_quran_idx + i + 1  # 1-indexed for display
        st.segments_attempted += 1

        # Transition mode: keep checking for transitions before trying alignment
        if st.transition_mode:
            if transition_mode_step(st, i, asr_phonemes, segment_idx):
                continue
            # else: exited transition mode + reanchored; fall through to alignment

        alignment, _trace = st.align(asr_phonemes)

        # Chapter transition: pointer past end of chapter
        if alignment is None and st.pointer >= st.chapter_ref.num_words:
            consumed, alignment, _trace = chapter_boundary_step(st, i, asr_phonemes, segment_idx)
            if consumed:
                continue

        # Basmala-fused retry: first segment after a transition with no Basmala
        # detected — the reciter may have fused Basmala into the first verse.
        # Runs even if the plain alignment succeeded; fused wins only when it
        # consumed the Basmala prefix AND beats the plain confidence.
        if st.is_first_after_transition:
            st.is_first_after_transition = False

            if params.enable_basmala_fused_retry:
                basmala_alignment, _bt = st.align(
                    asr_phonemes, basmala_prefix=resources.templates.special["Basmala"])

                if basmala_alignment and basmala_alignment.basmala_consumed:
                    existing_conf = alignment.confidence if alignment else 0.0
                    if basmala_alignment.confidence > existing_conf:
                        matched_text = (
                            SPECIAL_TEXT["Basmala"] + " "
                            + get_matched_text(st.chapter_ref, basmala_alignment))
                        result = (
                            matched_text,
                            basmala_alignment.confidence,
                            basmala_alignment.matched_ref,
                            basmala_alignment.wrap_word_ranges)
                        st.pointer = basmala_alignment.end_word_idx + 1
                        st.consecutive_failures = 0
                        st.word_indices.append(
                            (basmala_alignment.start_word_idx, basmala_alignment.end_word_idx))
                        _check_transition_gap(st, basmala_alignment.start_word_idx)
                        if basmala_alignment.n_wraps > 0:
                            st.repetition_segments.add(len(st.results))
                        st.results.append(result)
                        st.special_merges += 1
                        st.segments_passed += 1
                        st.emit("basmala_fused", segment_idx=segment_idx,
                                fused_conf=round(basmala_alignment.confidence, 4),
                                plain_conf=round(existing_conf, 4), chose="fused")
                        continue
                # Fused didn't win — fall through with the original alignment

        if alignment:
            st.is_first_after_transition = False
            matched_text = get_matched_text(st.chapter_ref, alignment)
            result = (matched_text, alignment.confidence, alignment.matched_ref,
                      alignment.wrap_word_ranges)
            st.pointer = alignment.end_word_idx + 1
            st.consecutive_failures = 0
            st.word_indices.append((alignment.start_word_idx, alignment.end_word_idx))
            _check_transition_gap(st, alignment.start_word_idx)
            if alignment.n_wraps > 0:
                st.repetition_segments.add(len(st.results))
            st.segments_passed += 1
        else:
            result = _handle_failure(st, i, asr_phonemes, segment_idx)
            if result is None:
                continue  # transition segment: already appended

        st.results.append(result)

    _detect_gaps(st, start_pointer)

    metrics = {
        "num_segments": st.num_segments,
        "retry_attempts": st.retry_attempts,
        "retry_passed": st.retry_passed,
        "retry_segments": st.retry_segments,
        "consec_reanchors": st.consec_reanchors,
        "segments_attempted": st.segments_attempted,
        "segments_passed": st.segments_passed,
        "special_merges": st.special_merges,
        "transition_skips": st.transition_skips,
        "phoneme_wraps_detected": len(st.repetition_segments),
    }

    return SequenceOutcome(
        results=st.results,
        word_indices=st.word_indices,
        gap_segments=st.gap_segments,
        merged_into=st.merged_into,
        repetition_segments=st.repetition_segments,
        metrics=metrics,
        events=st.events,
    )


def _check_transition_gap(st: SeqState, start_word_idx: int) -> None:
    """Flag missing words at the start of a new chapter after a transition."""
    if st.transition_expected_pointer < 0:
        return
    if start_word_idx > st.transition_expected_pointer:
        seg_idx = len(st.word_indices) - 1
        st.gap_segments.add(seg_idx)
        st.emit("gap", position="after_transition", segment_idx=seg_idx + 1,
                missing_words=start_word_idx - st.transition_expected_pointer)
    st.transition_expected_pointer = -1


def _handle_failure(st: SeqState, i: int, asr_phonemes: list[str], segment_idx: int):
    """No primary match: transition check, then the single expanded/relaxed
    retry, then consecutive-failure global reanchor (texts from i+1).

    Returns the result tuple to append, or None when a transition consumed the
    segment (already appended)."""
    # Transition segment before retry tiers
    trans_name, trans_conf = st.detect_transition(asr_phonemes)
    if trans_name:
        st.emit("transition_detected", segment_idx=segment_idx,
                transition_type=trans_name, confidence=round(trans_conf, 4),
                context="pre_retry")
        result = (TRANSITION_TEXT[trans_name], trans_conf, trans_name, None)
        st.word_indices.append(None)
        st.transition_skips += 1
        st.transition_mode = True
        if trans_name == "Tahmeed":
            maybe_tahmeed_merge(st, i, segment_idx)
        st.results.append(result)
        return None

    # Single retry: expanded window + relaxed threshold
    st.retry_attempts += 1
    st.retry_segments.append(segment_idx)
    alignment, retry_trace = st.align(
        asr_phonemes,
        lookback_override=st.params.retry_lookback_words,
        lookahead_override=st.params.retry_lookahead_words,
        max_edit_distance_override=st.params.max_edit_distance_relaxed,
    )

    if alignment:
        st.is_first_after_transition = False
        matched_text = get_matched_text(st.chapter_ref, alignment)
        result = (matched_text, alignment.confidence, alignment.matched_ref,
                  alignment.wrap_word_ranges)
        st.pointer = alignment.end_word_idx + 1
        st.consecutive_failures = 0
        st.word_indices.append((alignment.start_word_idx, alignment.end_word_idx))
        _check_transition_gap(st, alignment.start_word_idx)
        if alignment.n_wraps > 0:
            st.repetition_segments.add(len(st.results))
        st.segments_passed += 1
        st.retry_passed += 1
        st.emit("retry", segment_idx=segment_idx, passed=True,
                confidence=round(alignment.confidence, 4))
        return result

    # Real failure after all retries
    result = ("", 0.0, "", None)
    st.consecutive_failures += 1
    st.word_indices.append(None)

    nd = retry_trace.get("norm_dist")
    st.emit("retry_failed", segment_idx=segment_idx, retry_stats={
        "norm_dist": round(nd, 4) if nd is not None else None,
        "best_conf": round(1.0 - nd, 4) if nd is not None else None,
        "best_cost": retry_trace.get("best_cost"),
        "n_wraps": retry_trace.get("n_wraps", 0),
        "max_j_reached": retry_trace.get("max_j_reached", 0),
        "threshold": retry_trace.get("threshold"),
        "threshold_failed": bool(retry_trace.get("threshold_failed", False)),
    })

    if st.consecutive_failures >= st.params.max_consecutive_failures:
        st.consec_reanchors += 1
        consec_at_trigger = st.consecutive_failures
        remaining_texts = st.phoneme_texts[st.first_quran_idx + i + 1:]
        if remaining_texts:
            reanchor_surah, reanchor_ayah = st.vote(remaining_texts)
            if reanchor_surah > 0:
                if reanchor_surah != st.detected_surah:
                    st.set_chapter(reanchor_surah)
                st.pointer = verse_to_word_index(st.chapter_ref, reanchor_ayah)
                st.transition_expected_pointer = st.pointer
                st.emit("reanchor", at_segment=segment_idx, reason="consecutive_failures",
                        consec_failures_at_trigger=consec_at_trigger,
                        new_surah=st.detected_surah, new_ayah=reanchor_ayah,
                        new_pointer=st.pointer)
            else:
                st.emit("reanchor_failed", at_segment=segment_idx,
                        reason="consecutive_failures",
                        consec_failures_at_trigger=consec_at_trigger)
        st.consecutive_failures = 0

    return result


def _detect_gaps(st: SeqState, start_pointer: int) -> None:
    """Post-processing: flag reference gaps between, before, and after matches."""
    results, word_indices = st.results, st.word_indices

    # Between consecutive matched segments (same chapter only)
    prev_matched_idx = None
    for idx in range(len(results)):
        if word_indices[idx] is None:
            continue

        if prev_matched_idx is not None:
            prev_ref = results[prev_matched_idx][2]
            curr_ref = results[idx][2]
            prev_surah = prev_ref.split(":")[0] if prev_ref and ":" in prev_ref else None
            curr_surah = curr_ref.split(":")[0] if curr_ref and ":" in curr_ref else None

            if prev_surah is not None and prev_surah == curr_surah:
                prev_end = word_indices[prev_matched_idx][1]
                curr_start = word_indices[idx][0]
                gap = curr_start - prev_end - 1

                if gap > 0:
                    st.gap_segments.add(prev_matched_idx)
                    st.gap_segments.add(idx)
                    gap_ref = st.resources.chapter_refs[int(prev_surah)]
                    missing_refs = [gap_ref.words[w].location
                                    for w in range(prev_end + 1, curr_start)
                                    if 0 <= w < gap_ref.num_words]
                    st.emit("gap", position="between",
                            segment_before=prev_matched_idx + 1,
                            segment_after=idx + 1, missing_words=gap,
                            missing_word_refs=missing_refs)

        prev_matched_idx = idx

    # Missing words before the first matched segment
    first_matched = next((i for i, w in enumerate(word_indices) if w is not None), None)
    if first_matched is not None:
        first_ref = results[first_matched][2]
        first_surah = first_ref.split(":")[0] if first_ref and ":" in first_ref else None
        if first_surah is not None:
            first_chapter_ref = st.resources.chapter_refs[int(first_surah)]
            first_start = word_indices[first_matched][0]
            if first_start > start_pointer:
                st.gap_segments.add(first_matched)
                missing_refs = [first_chapter_ref.words[w].location
                                for w in range(start_pointer, first_start)
                                if 0 <= w < first_chapter_ref.num_words]
                st.emit("gap", position="before_first", segment_idx=first_matched + 1,
                        missing_words=first_start - start_pointer,
                        missing_word_refs=missing_refs)

    # Missing words at the end of the final verse — only when the last matched
    # segment is also the final segment overall (trailing no-matches account
    # for the remaining audio themselves). Verse boundary, not chapter end.
    last_matched = next((i for i in range(len(word_indices) - 1, -1, -1)
                         if word_indices[i] is not None), None)
    if last_matched is not None and last_matched == len(word_indices) - 1:
        last_ref = results[last_matched][2]
        last_surah = last_ref.split(":")[0] if last_ref and ":" in last_ref else None
        if last_surah is not None:
            last_chapter_ref = st.resources.chapter_refs[int(last_surah)]
            last_end = word_indices[last_matched][1]
            if 0 <= last_end < last_chapter_ref.num_words:
                last_ayah = last_chapter_ref.words[last_end].ayah
                verse_end = last_end
                while (verse_end + 1 < last_chapter_ref.num_words
                       and last_chapter_ref.words[verse_end + 1].ayah == last_ayah):
                    verse_end += 1
                if last_end < verse_end:
                    st.gap_segments.add(last_matched)
                    missing_refs = [last_chapter_ref.words[w].location
                                    for w in range(last_end + 1, verse_end + 1)
                                    if 0 <= w < last_chapter_ref.num_words]
                    st.emit("gap", position="after_last", segment_idx=last_matched + 1,
                            missing_words=verse_end - last_end,
                            missing_word_refs=missing_refs)
