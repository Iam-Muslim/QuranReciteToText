"""QuranIndex: flat word array + (surah, ayah, word) lookup for ref → text/indices.

``from_phonemizer()`` derives the index from the phonemizer's word stream — no
external script JSON. The one thing the phonemizer cannot provide is a second
display script: the legacy dual-script loader paired QPC Hafs (computation)
with Digital Khatt (display, stop signs as combining marks); here
``display_text`` falls back to the phonemizer's Hafs text. Consumers that ship
the script JSONs keep the dual-script path via ``load()``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from qua_sdk.domain.cache import load_or_build, version_key

VERSE_MARKER_PREFIX = "۝"  # end-of-ayah marker — not a real word


@dataclass
class WordInfo:
    """A single Quran word."""

    global_idx: int       # position in the flat word array
    surah: int
    ayah: int
    word: int
    text: str             # computation script
    display_text: str     # display script (falls back to text)


@dataclass
class QuranIndex:
    """Converts matched refs ("2:255:1-2:255:5") back to word indices and text."""

    words: list[WordInfo]                          # all words in mushaf order
    word_lookup: dict[tuple[int, int, int], int]   # (surah, ayah, word) → global_idx

    @classmethod
    def from_phonemizer(cls) -> "QuranIndex":
        """Build from the phonemizer's full-Quran word stream (hafs script)."""
        from qua_sdk.domain.chapter_refs import get_phonemizer

        result = get_phonemizer().phonemize(ref="1-114", stop_signs=["verse"])
        words: list[WordInfo] = []
        word_lookup: dict[tuple[int, int, int], int] = {}
        for word in result._words:
            loc = word.location
            info = WordInfo(
                global_idx=len(words),
                surah=loc.surah_num,
                ayah=loc.ayah_num,
                word=loc.word_num,
                text=word.text,
                display_text=word.text,
            )
            words.append(info)
            word_lookup[(info.surah, info.ayah, info.word)] = info.global_idx
        return cls(words=words, word_lookup=word_lookup)

    @classmethod
    def load(cls, compute_path: Path, display_path: Path | None = None) -> "QuranIndex":
        """Dual-script load: compute script keyed "s:a:w" → {text, surah, ayah, word},
        optional display script overlaid by key. Verse markers are filtered."""
        with open(compute_path, encoding="utf-8") as f:
            compute_data = json.load(f)
        display_data = {}
        if display_path is not None:
            with open(display_path, encoding="utf-8") as f:
                display_data = json.load(f)

        words: list[WordInfo] = []
        word_lookup: dict[tuple[int, int, int], int] = {}
        for key in sorted(compute_data, key=_parse_location_key):
            entry = compute_data[key]
            text = entry["text"]
            if text.startswith(VERSE_MARKER_PREFIX):
                continue
            dk_entry = display_data.get(key)
            info = WordInfo(
                global_idx=len(words),
                surah=int(entry["surah"]),
                ayah=int(entry["ayah"]),
                word=int(entry["word"]),
                text=text,
                display_text=dk_entry["text"] if dk_entry else text,
            )
            words.append(info)
            word_lookup[(info.surah, info.ayah, info.word)] = info.global_idx
        return cls(words=words, word_lookup=word_lookup)

    def ref_to_indices(self, ref: str) -> tuple[int, int] | None:
        """'2:255:1-2:255:5' or '2:255:5' → global (start, end) indices, None on miss."""
        if not ref or ":" not in ref:
            return None
        try:
            if "-" in ref:
                start_ref, end_ref = ref.split("-")
            else:
                start_ref = end_ref = ref

            def _lookup(r: str) -> int | None:
                parts = r.split(":")
                if len(parts) < 3:
                    return None
                return self.word_lookup.get((int(parts[0]), int(parts[1]), int(parts[2])))

            start_idx = _lookup(start_ref)
            end_idx = _lookup(end_ref)
            if start_idx is None or end_idx is None:
                return None
            return start_idx, end_idx
        except Exception:
            return None


def _parse_location_key(key: str) -> tuple[int, int, int]:
    parts = key.split(":")
    return (int(parts[0]), int(parts[1]), int(parts[2]))


@lru_cache(maxsize=2)
def load_quran_index(riwayah: str = "hafs") -> QuranIndex:
    return load_or_build("quran_index", version_key(riwayah), QuranIndex.from_phonemizer)
