"""Method params for the wraparound-DP matcher runtime.

Import-light by design: profiles import this module directly, so it must not
pull heavy deps (the runtimes keep heavy imports call-local).
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from qua_sdk.components.matching.spec import MatchingParams


class WraparoundDpParams(MatchingParams):
    """Knob names/defaults mirror aligner config.py (the Space profile)."""

    # window
    lookback_words: int = 30
    lookahead_words: int = 10
    retry_lookback_words: int = 70
    retry_lookahead_words: int = 40
    # thresholds
    max_edit_distance: float = Field(0.25, ge=0, le=1)
    max_edit_distance_relaxed: float = Field(0.45, ge=0, le=1)
    start_prior_weight: float = 0.005
    max_consecutive_failures: int = 2
    # edit costs
    cost_substitution: float = 1.0
    cost_deletion: float = 1.0
    cost_insertion: float = 1.0
    # repetition (wraparound)
    max_wraps: int = 5
    wrap_penalty: float = 3.5
    wrap_span_weight: float = 0.1
    wrap_scoring_mode: Literal["subtract", "no_subtract", "additive"] = "no_subtract"
    wrap_score_cost: float = 0.005
    # special-segment handling
    enable_basmala_fused_retry: bool = True
