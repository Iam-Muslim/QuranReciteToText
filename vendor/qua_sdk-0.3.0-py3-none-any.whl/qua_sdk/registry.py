"""Versioned string registry: resolve components/pipelines/tasks by key.

Keys are ``"<kind>.<name>@v<N>"`` (e.g. ``"matching.wraparound_dp@v1"``);
the kind segment is a closed set (task, pipeline, plus the four capability
components) — anything else is rejected at register time.
Registered value convention: a READY-TO-CALL object (component instance,
pipeline function, task decl). Lazy targets may name a class or zero-arg
factory — resolve() instantiates it once. Duplicate keys raise.
"""

from __future__ import annotations

import re
from typing import Any, Callable

from qua_sdk.errors import CompositionError, ErrorCode

_REGISTRY: dict[str, Any] = {}
_KINDS = ("task", "pipeline", "segmentation", "recognition", "matching", "timing")
_KEY_RE = re.compile(rf"^(?:{'|'.join(_KINDS)})\.[a-z0-9_.]+@v\d+$")


def _check_key(key: str) -> None:
    if not _KEY_RE.match(key):
        raise CompositionError(
            ErrorCode.UNKNOWN_REGISTRY_KEY,
            f"malformed registry key {key!r} — expected '<kind>.<name>@vN' "
            f"with kind one of: {', '.join(_KINDS)}",
        )
    if key in _REGISTRY:
        raise CompositionError(ErrorCode.UNKNOWN_REGISTRY_KEY, f"duplicate registry key {key!r}")


def register(key: str, obj: Any = None) -> Callable | None:
    """``register("matching.wraparound_dp@v1", impl)`` or as a decorator."""
    if obj is not None:
        _check_key(key)
        _REGISTRY[key] = obj
        return None

    def deco(fn):
        _check_key(key)
        _REGISTRY[key] = fn
        return fn

    return deco


def register_lazy(key: str, target: str, *, extra: str | None = None) -> None:
    """Register without importing: ``target`` is ``"module.path:attr"``.

    Heavy runtimes (torch/transformers) register lazily so the core import
    stays dependency-free; the module loads on first resolve. ``extra`` names
    the pip extra that provides the runtime's heavy deps — it is the hint
    surfaced when the lazy import fails.
    """
    _check_key(key)
    _REGISTRY[key] = _Lazy(target, extra)


class _Lazy:
    def __init__(self, target: str, extra: str | None = None):
        self.target = target
        self.extra = extra

    def load(self, key: str) -> Any:
        import importlib
        import inspect

        mod_name, attr = self.target.split(":")
        try:
            obj = getattr(importlib.import_module(mod_name), attr)
        except ModuleNotFoundError as e:
            extra = self.extra or "dev"
            raise CompositionError(
                ErrorCode.MISSING_DEPENDENCY,
                f"runtime for {key!r} unavailable ({e.name} not importable) — "
                f"try: pip install qua-sdk[{extra}]",
                internal_detail=f"lazy target {self.target!r}",
            ) from e
        if inspect.isclass(obj):
            obj = obj()
        return obj


def resolve(key: str, *, expect: type | None = None) -> Any:
    """Resolve ``key``; with ``expect`` (a runtime_checkable spec Protocol),
    isinstance-check the resolved object and fail loud on a contract miss."""
    try:
        obj = _REGISTRY[key]
    except KeyError:
        known = ", ".join(sorted(_REGISTRY)) or "(empty)"
        raise CompositionError(
            ErrorCode.UNKNOWN_REGISTRY_KEY,
            f"unknown registry key {key!r}",
            internal_detail=f"known: {known}",
        ) from None
    if isinstance(obj, _Lazy):
        obj = _REGISTRY[key] = obj.load(key)
    if expect is not None and not isinstance(obj, expect):
        raise CompositionError(
            ErrorCode.COMPONENT_MISMATCH,
            f"registry key {key!r} resolved to {type(obj).__name__}, "
            f"which does not satisfy {expect.__name__}",
        )
    return obj


def keys(prefix: str = "") -> list[str]:
    return sorted(k for k in _REGISTRY if k.startswith(prefix))
