"""WraparoundDpMatcher: the Matcher-protocol runtime over the ported sequence.

Wires the pieces (opening-specials scan -> chapter anchor -> matching sequence)
and maps the legacy result tuples onto the Alignment schema. Anchor policy:
``autodetect_chapter=True`` votes from emissions, falling back to the
``chapter_hint`` when voting finds nothing (InputError only with no hint);
``False`` + a chapter_hint starts at the hint with pointer 0 — voting remains
the sequencer's mid-stream reanchor fallback either way. Segment ids are region
indices; merges keep the consumed row (``merged_into`` + ``merge_reason``) and
extend the target's region. Post-passes: waqf-sakt verse splits auto-merge
(always on, domain.sakt) and specials named in ``SpecialsParams.filter`` come
back flagged ``filtered``. Metrics + events go to the observe sink.
"""

from __future__ import annotations

from typing import ClassVar

from qua_sdk.components.matching.lib.anchor import find_anchor_by_voting, verse_to_word_index
from qua_sdk.components.matching.runtimes.sequencer import (
    MatchingResources,
    SequenceOutcome,
    run_matching_sequence,
)
from qua_sdk.components.matching.lib.specials import detect_opening_specials
from qua_sdk.components.matching.runtimes.wraparound_params import WraparoundDpParams
from qua_sdk.components.matching.spec import Matcher
from qua_sdk.domain.chapter_refs import ChapterReference
from qua_sdk.domain.sakt import is_waqf_sakt_split
from qua_sdk.errors import ErrorCode, InputError
from qua_sdk.observe import record_metrics
from qua_sdk.schemas import AlignedSegment, Alignment, Emissions, Region, Regions

MAX_RECORDED_EVENTS = 500
NON_VERSE_FINAL_PENALTY = 0.25


class WraparoundDpMatcher(Matcher):
    """Windowed wraparound edit-distance matcher (the aligner's DP stack)."""

    Params: ClassVar[type[WraparoundDpParams]] = WraparoundDpParams

    def match(
        self,
        emissions: Emissions,
        regions: Regions,
        params: WraparoundDpParams,
        *,
        chapter_hint: int | None = None,
        deploy=None,
    ) -> Alignment:
        mode = emissions.inventory_mode
        resources = MatchingResources.for_mode(mode, params)
        phoneme_texts = emissions.tokens

        special_results, first_quran_idx = detect_opening_specials(
            phoneme_texts, resources.templates,
            max_special_edit_distance=params.specials.max_special_edit_distance,
            max_transition_edit_distance=params.specials.max_transition_edit_distance,
        )

        if not params.autodetect_chapter and chapter_hint is not None:
            surah, pointer = chapter_hint, 0
        else:
            surah, ayah = find_anchor_by_voting(
                phoneme_texts[first_quran_idx:], resources.ngram_index, params.anchor)
            if surah == 0 and chapter_hint is not None:
                record_metrics(anchor_fallback_to_hint=chapter_hint)
                surah, pointer = chapter_hint, 0
            elif surah == 0:
                raise InputError(
                    ErrorCode.ANCHOR_NOT_FOUND,
                    "Could not anchor to any chapter — no n-gram matches found",
                    stage="matching", component="matching.wraparound_dp",
                )
            else:
                pointer = verse_to_word_index(resources.chapter_refs[surah], ayah)

        outcome = run_matching_sequence(
            phoneme_texts,
            start_surah=surah,
            first_quran_idx=first_quran_idx,
            special_results=special_results,
            start_pointer=pointer,
            params=params,
            resources=resources,
        )

        record_metrics(**outcome.metrics, events=outcome.events[:MAX_RECORDED_EVENTS])

        segments = _build_segments(outcome, list(regions), params, resources.chapter_refs)
        _apply_waqf_sakt_merges(segments)
        _apply_specials_filter(segments, params.specials.filter)
        return Alignment(segments=segments, chapter=surah, inventory_mode=mode)


def _build_segments(
    outcome: SequenceOutcome,
    region_list: list[Region],
    params: WraparoundDpParams,
    chapter_refs: dict[int, ChapterReference],
) -> list[AlignedSegment]:
    """Map legacy result tuples onto AlignedSegments, one per input region."""
    # Tahmeed merges extend the target segment's region over the consumed one
    merged_end_s: dict[int, float] = {}
    for consumed_idx, target_idx in outcome.merged_into.items():
        if consumed_idx < len(region_list):
            merged_end_s[target_idx] = region_list[consumed_idx].end_s

    segments: list[AlignedSegment] = []
    last_idx = len(region_list) - 1

    for idx, (region, result_tuple) in enumerate(zip(region_list, outcome.results)):
        matched_text, score, matched_ref = result_tuple[0], result_tuple[1], result_tuple[2]
        wrap_ranges = result_tuple[3] if len(result_tuple) > 3 else None

        if idx in outcome.merged_into:
            segments.append(AlignedSegment(
                id=idx, region=region, merged_into=outcome.merged_into[idx],
                merge_reason="tahmeed"))
            continue

        # Space UI semantics: a final segment that stops mid-verse is suspect
        if (params.penalize_non_verse_final and idx == last_idx and matched_ref
                and not _is_end_of_verse(matched_ref, chapter_refs)):
            score = max(0.0, score - NON_VERSE_FINAL_PENALTY)

        error = None
        if score <= 0.0:
            matched_text = ""
            matched_ref = ""
            error = f"Low confidence ({score:.0%})"

        end_s = merged_end_s.get(idx, region.end_s)
        if end_s != region.end_s:
            region = Region(start_s=region.start_s, end_s=end_s)

        segments.append(AlignedSegment(
            id=idx,
            region=region,
            matched_ref=matched_ref or None,
            matched_text=matched_text,
            confidence=score,
            error=error,
            wrap_word_ranges=[list(w) for w in wrap_ranges] if wrap_ranges else None,
            has_missing_words=idx in outcome.gap_segments,
        ))

    return segments


def _apply_waqf_sakt_merges(segments: list[AlignedSegment]) -> None:
    """Heal verse splits at waqf-sakt points: always-on auto-merge.

    Two adjacent matched segments straddling a sakt point (domain.sakt) are one
    verse the segmenter split at the obligatory pause. The earlier segment
    becomes the merge target — combined ref span, region extended over the
    consumed one, certainty confidence — and the later row stays in the list
    with ``merged_into`` + ``merge_reason="waqf_sakt"`` so consumers can render
    an auto-merge event (Space) or synthesize audit ops (offline)."""
    merges = 0
    live = [s for s in segments if s.merged_into is None]
    for a, b in zip(live, live[1:]):
        if a.merged_into is not None or not a.matched_ref or not b.matched_ref:
            continue
        if not is_waqf_sakt_split(a.matched_ref, b.matched_ref):
            continue
        ref_start = a.matched_ref.split("-")[0]
        ref_end = b.matched_ref.split("-")[-1]
        a.region = Region(start_s=a.region.start_s, end_s=b.region.end_s)
        a.matched_ref = f"{ref_start}-{ref_end}"
        a.matched_text = f"{a.matched_text} {b.matched_text}".strip()
        a.confidence = 1.0
        a.error = None
        a.wrap_word_ranges = None
        a.has_missing_words = False
        b.merged_into = a.id
        b.merge_reason = "waqf_sakt"
        merges += 1
    if merges:
        record_metrics(waqf_sakt_merges=merges)


def _apply_specials_filter(segments: list[AlignedSegment], filter_refs: tuple[str, ...]) -> None:
    """Flag detected specials named in the filter; rows stay for provenance."""
    if not filter_refs:
        return
    names = set(filter_refs)
    for seg in segments:
        if seg.merged_into is None and seg.matched_ref in names:
            seg.filtered = True


def _is_end_of_verse(matched_ref: str, chapter_refs: dict[int, ChapterReference]) -> bool:
    """True when the ref's end word is the last word of its ayah.

    Specials (no ':') are False — the legacy last-segment penalty applies to
    them too. An unknown ayah yields word-count 0, i.e. True (no penalty).
    """
    if not matched_ref or ":" not in matched_ref:
        return False
    try:
        end_ref = matched_ref.split("-")[-1]
        parts = end_ref.split(":")
        if len(parts) < 3:
            return False
        surah, ayah, word = int(parts[0]), int(parts[1]), int(parts[2])
        ref = chapter_refs.get(surah)
        if ref is None:
            return False
        num_words = sum(1 for w in ref.words if w.ayah == ayah)
        return word >= num_words
    except (ValueError, AttributeError):
        return False
