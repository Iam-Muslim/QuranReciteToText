"""Audio conversion + TextGrid parsing for the local MFA runtime.

``save_as_wav`` normalizes any input to 16k mono PCM_16 via soundfile +
``np.interp`` resampling (deliberately NOT a polyphase resampler — the
acoustic model was tuned against this path), with an ffmpeg subprocess
fallback for formats soundfile can't read. soundfile/tgt import call-local
(the ``mfa`` extra provides them).
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import numpy as np

FFMPEG_TIMEOUT_S = 30


def save_as_wav(src_path: str, wav_path: Path) -> None:
    """Convert ``src_path`` to a 16k mono PCM_16 WAV at ``wav_path``."""
    import soundfile as sf

    try:
        data, sr = sf.read(src_path)
        if data.ndim > 1:
            data = data.mean(axis=1)
        if sr != 16000:
            ratio = 16000 / sr
            n_samples = int(len(data) * ratio)
            indices = np.linspace(0, len(data) - 1, n_samples)
            data = np.interp(indices, np.arange(len(data)), data)
            sr = 16000
        sf.write(str(wav_path), data, sr, subtype="PCM_16")
    except Exception:
        subprocess.run(
            ["ffmpeg", "-y", "-i", src_path, "-ar", "16000", "-ac", "1", str(wav_path)],
            capture_output=True,
            timeout=FFMPEG_TIMEOUT_S,
        )
        if not wav_path.exists():
            raise RuntimeError("Failed to convert audio to WAV")


def parse_textgrid(tg_path: Path) -> list[dict]:
    """Parse a TextGrid's phones tier to interval dicts (4dp), matching the
    kalpy CTM shape."""
    import tgt

    tg = tgt.read_textgrid(str(tg_path))
    phones_tier = None
    for tier_name in ["phones", "phone", "phonemes", "phoneme"]:
        try:
            phones_tier = tg.get_tier_by_name(tier_name)
            break
        except ValueError:
            continue
    if phones_tier is None:
        for tier in tg.tiers:
            if hasattr(tier, "intervals"):
                phones_tier = tier
                break
    if phones_tier is None:
        return []
    intervals = []
    for interval in phones_tier.intervals:
        intervals.append({
            "start": round(float(interval.start_time), 4),
            "end": round(float(interval.end_time), 4),
            "phone": interval.text,
        })
    return intervals
