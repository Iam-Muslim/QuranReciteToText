"""Sequencer loop state + the chapter-boundary / transition-mode steps.

Split out of ``sequencer.py`` for size only — together they are a structural
1:1 port of the aligner's ``run_phoneme_matching`` loop. ``SeqState`` holds
every mutable loop variable; the step functions here mutate it exactly where
the legacy inline blocks did. Control-flow invariants (reanchor slice offsets,
``is_first_after_transition`` arming, counter increments) are fixture-locked —
do not "clean up" without re-running the parity suite.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from qua_sdk.components.matching.lib.anchor import find_anchor_by_voting, verse_to_word_index
from qua_sdk.components.matching.lib.specials import (
    TRANSITION_TEXT,
    detect_inter_chapter_specials,
    detect_transition_segment,
)
from qua_sdk.components.matching.runtimes.windows import AlignmentResult, align_segment
from qua_sdk.components.matching.runtimes.wraparound_params import WraparoundDpParams
from qua_sdk.domain.chapter_refs import ChapterReference

_BASMALA_REFS = ("Basmala", "Isti'adha+Basmala")


@dataclass
class SeqState:
    """All mutable state of one run_matching_sequence call."""

    phoneme_texts: list[list[str]]
    first_quran_idx: int
    params: WraparoundDpParams
    resources: Any  # MatchingResources (sequencer-owned; avoids a circular import)
    on_event: Optional[Callable[[dict], None]]

    detected_surah: int
    chapter_ref: ChapterReference
    pointer: int

    results: list = field(default_factory=list)
    word_indices: list = field(default_factory=list)
    gap_segments: set = field(default_factory=set)
    merged_into: dict = field(default_factory=dict)
    repetition_segments: set = field(default_factory=set)
    events: list = field(default_factory=list)

    transition_mode: bool = False
    transition_expected_pointer: int = -1  # -1 = no pending check
    is_first_after_transition: bool = False
    consecutive_failures: int = 0
    skip_count: int = 0
    pending_specials: list = field(default_factory=list)
    tahmeed_merge_skip: int = 0

    # counters (metrics dict keys, always on)
    num_segments: int = 0
    retry_attempts: int = 0
    retry_passed: int = 0
    retry_segments: list = field(default_factory=list)
    consec_reanchors: int = 0
    segments_attempted: int = 0
    segments_passed: int = 0
    special_merges: int = 0
    transition_skips: int = 0

    def emit(self, name: str, **fields) -> None:
        event = {"event": name, **fields}
        self.events.append(event)
        if self.on_event is not None:
            self.on_event(event)

    def align(self, asr_phonemes: list[str], **overrides) -> tuple[Optional[AlignmentResult], dict]:
        """align_segment against the current chapter/pointer; counts the DP call."""
        result = align_segment(
            asr_phonemes, self.chapter_ref, self.pointer,
            self.params, self.resources.sub_table, **overrides)
        self.num_segments += 1
        return result

    def detect_transition(self, asr_phonemes: list[str], allowed: Optional[set] = None):
        return detect_transition_segment(
            asr_phonemes, self.resources.templates,
            max_transition_edit_distance=self.params.specials.max_transition_edit_distance,
            allowed=allowed)

    def vote(self, texts: list[list[str]]) -> tuple[int, int]:
        return find_anchor_by_voting(texts, self.resources.ngram_index, self.params.anchor)

    def set_chapter(self, surah: int) -> None:
        self.detected_surah = surah
        self.chapter_ref = self.resources.chapter_refs[surah]


def maybe_tahmeed_merge(st: SeqState, i: int, segment_idx: int) -> None:
    """Tahmeed peek-ahead: a Tahmeed-response next segment merges into this one."""
    next_abs = st.first_quran_idx + i + 1
    if next_abs < len(st.phoneme_texts) and st.phoneme_texts[next_abs]:
        resp_name, _resp_conf = st.detect_transition(st.phoneme_texts[next_abs], allowed={"Tahmeed"})
        if resp_name:
            st.merged_into[next_abs] = st.first_quran_idx + i
            st.tahmeed_merge_skip = 1
            st.emit("tahmeed_merge", segment_idx=segment_idx, merged_segment=next_abs)


def transition_mode_step(st: SeqState, i: int, asr_phonemes: list[str], segment_idx: int) -> bool:
    """In transition mode keep consuming transition segments; on the first
    non-transition segment exit + globally reanchor (texts from i, the current
    segment included). True = segment consumed, continue the loop."""
    trans_name, trans_conf = st.detect_transition(asr_phonemes)
    if trans_name:
        st.emit("transition_detected", segment_idx=segment_idx,
                transition_type=trans_name, confidence=round(trans_conf, 4),
                context="transition_mode")
        st.results.append((TRANSITION_TEXT[trans_name], trans_conf, trans_name, None))
        st.word_indices.append(None)
        st.transition_skips += 1
        if trans_name == "Tahmeed":
            maybe_tahmeed_merge(st, i, segment_idx)
        return True

    st.transition_mode = False
    remaining_idx = st.first_quran_idx + i
    remaining_texts = st.phoneme_texts[remaining_idx:]
    if remaining_texts:
        reanchor_surah, reanchor_ayah = st.vote(remaining_texts)
        if reanchor_surah > 0:
            if reanchor_surah != st.detected_surah:
                st.set_chapter(reanchor_surah)
            st.pointer = verse_to_word_index(st.chapter_ref, reanchor_ayah)
            st.transition_expected_pointer = st.pointer
            st.emit("reanchor", at_segment=segment_idx, reason="transition_mode_exit",
                    new_surah=st.detected_surah, new_ayah=reanchor_ayah,
                    new_pointer=st.pointer)
        else:
            st.emit("reanchor_failed", at_segment=segment_idx, reason="transition_mode_exit")
        st.consecutive_failures = 0
    return False  # fall through to normal alignment


def chapter_boundary_step(
    st: SeqState, i: int, asr_phonemes: list[str], segment_idx: int,
) -> tuple[bool, Optional[AlignmentResult], dict]:
    """Pointer ran past the chapter end with no match: detect Amin (after surah 1)
    and inter-chapter specials, then pick the next chapter — global reanchor after
    Al-Fatiha, sequential surah+1 otherwise (with a transition check first).

    Returns (consumed, alignment, trace): consumed=True means the segment was
    handled here (continue the loop); otherwise alignment/trace are the realign
    attempt against the new chapter (or None past surah 114).
    """
    detect_inter = lambda texts: detect_inter_chapter_specials(  # noqa: E731
        texts, st.resources.templates,
        max_special_edit_distance=st.params.specials.max_special_edit_distance)

    remaining_phonemes = st.phoneme_texts[st.first_quran_idx + i:]
    amin_consumed = 0

    if st.chapter_ref.surah == 1:
        # Amin after Al-Fatiha comes before inter-chapter specials
        amin_name, amin_conf = st.detect_transition(asr_phonemes, allowed={"Amin"})
        if amin_name:
            st.emit("transition_detected", segment_idx=segment_idx,
                    transition_type="Amin", confidence=round(amin_conf, 4),
                    context="post_fatiha")
            st.results.append((TRANSITION_TEXT["Amin"], amin_conf, "Amin", None))
            st.word_indices.append(None)
            st.transition_skips += 1
            amin_consumed = 1
            remaining_phonemes = st.phoneme_texts[st.first_quran_idx + i + 1:]

    inter_specials, num_consumed = detect_inter(remaining_phonemes)

    if st.chapter_ref.surah == 1:
        # After Al-Fatiha the next chapter is arbitrary — global reanchor
        st.emit("chapter_end", at_segment=segment_idx, from_surah=1,
                next_action="global_reanchor")
        anchor_offset = st.first_quran_idx + i + amin_consumed + num_consumed
        reanchor_surah, reanchor_ayah = st.vote(st.phoneme_texts[anchor_offset:])

        if reanchor_surah > 0:
            next_surah = reanchor_surah
            st.chapter_ref = st.resources.chapter_refs[next_surah]
            st.pointer = verse_to_word_index(st.chapter_ref, reanchor_ayah)
            # transition_expected_pointer stays unset: gaps are expected here
            st.emit("reanchor", at_segment=segment_idx, reason="post_fatiha",
                    new_surah=next_surah, new_ayah=reanchor_ayah, new_pointer=st.pointer)
        else:
            next_surah = 2
            st.chapter_ref = st.resources.chapter_refs[next_surah]
            st.pointer = 0
            st.emit("reanchor_failed", at_segment=segment_idx, reason="post_fatiha",
                    fallback_surah=2)
    else:
        next_surah = st.chapter_ref.surah + 1
        if next_surah > 114:
            pass  # no more chapters — fall through to failure handling
        else:
            # Check for a transition before committing to the next sequential surah
            if num_consumed == 0:
                trans_name, trans_conf = st.detect_transition(asr_phonemes)
                if trans_name:
                    st.emit("transition_detected", segment_idx=segment_idx,
                            transition_type=trans_name, confidence=round(trans_conf, 4),
                            context="chapter_end")
                    st.results.append((TRANSITION_TEXT[trans_name], trans_conf, trans_name, None))
                    st.word_indices.append(None)
                    st.transition_skips += 1
                    st.transition_mode = True
                    st.set_chapter(next_surah)
                    st.pointer = 0
                    st.transition_expected_pointer = 0
                    st.consecutive_failures = 0
                    return True, None, {}

            st.emit("chapter_transition", at_segment=segment_idx,
                    from_surah=st.chapter_ref.surah, to_surah=next_surah)
            st.chapter_ref = st.resources.chapter_refs[next_surah]
            st.pointer = 0
            st.transition_expected_pointer = 0

    if next_surah <= 114:
        st.detected_surah = next_surah
        st.consecutive_failures = 0

        if amin_consumed > 0:
            # Current segment was Amin (already appended); queue specials for
            # the following segments.
            has_basmala = any(s.ref in _BASMALA_REFS for s in inter_specials)
            st.is_first_after_transition = not has_basmala
            if num_consumed > 0:
                st.pending_specials = [h.as_tuple() for h in inter_specials]
                st.skip_count = num_consumed
            else:
                st.is_first_after_transition = True
            return True, None, {}

        if num_consumed > 0:
            has_basmala = any(s.ref in _BASMALA_REFS for s in inter_specials)
            st.is_first_after_transition = not has_basmala
            # Current segment is a special — append its result now
            st.results.append(inter_specials[0].as_tuple())
            st.word_indices.append(None)
            if num_consumed > 1:
                st.pending_specials = [h.as_tuple() for h in inter_specials[1:]]
                st.skip_count = num_consumed - 1
            return True, None, {}

        st.is_first_after_transition = True
        # No specials — re-try alignment on this segment against the new chapter
        alignment, trace = st.align(asr_phonemes)
        return False, alignment, trace

    return False, None, {}
