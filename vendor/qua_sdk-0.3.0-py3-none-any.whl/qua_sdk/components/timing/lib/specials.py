"""Special (non-verse) segment data for ref preparation and letter recovery.

The phonemizer can't produce Basmala/Isti'adha outside a verse context, so
their word breakdowns (``SPECIAL_WORDS``, duck-typed with the phonemizer's
WordMapping) and flat letter↔phoneme mappings (``SPECIAL_FLAT_MAPPINGS``) are
authored here. The phoneme sequences themselves live in
``domain.special_texts.SPECIAL_PHONEMES``. Flat-mapping rules: no empty
phonemes; silent letters merge into adjacent entries; a space suffix on chars
marks a word boundary.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from qua_sdk.domain.special_texts import SPECIAL_PHONEMES

__all__ = ["SPECIAL_PHONEMES", "SPECIAL_WORDS", "SPECIAL_FLAT_MAPPINGS", "SPECIAL_KEYS", "SpecialWord"]


@dataclass(frozen=True)
class SpecialWord:
    """One word of a special segment — same attribute surface the recovery
    pipeline reads off phonemizer WordMapping objects."""

    location: str
    text: str
    phonemes: list[str] = field(default_factory=list)


SPECIAL_WORDS: dict[str, list[SpecialWord]] = {
    "Isti'adha": [
        SpecialWord(location="0:0:1", text="أَعُوذُ",
                    phonemes=["ʔ", "a", "ʕ", "u:", "ð", "u"]),
        SpecialWord(location="0:0:2", text="بِٱللَّهِ",
                    phonemes=["b", "i", "ll", "a:", "h", "i"]),
        SpecialWord(location="0:0:3", text="مِنَ",
                    phonemes=["m", "i", "n", "a"]),
        SpecialWord(location="0:0:4", text="ٱلشَّيْطَـٰنِ",
                    phonemes=["ʃʃ", "a", "j", "tˤ", "aˤ:", "n", "i"]),
        SpecialWord(location="0:0:5", text="ٱلرَّجِيمِ",
                    phonemes=["rˤrˤ", "aˤ", "ʒ", "i:", "m"]),
    ],
    "Basmala": [
        SpecialWord(location="0:0:1", text="بِسْمِ",
                    phonemes=["b", "i", "s", "m", "i"]),
        SpecialWord(location="0:0:2", text="ٱللَّهِ",
                    phonemes=["ll", "a:", "h", "i"]),
        SpecialWord(location="0:0:3", text="ٱلرَّحْمَـٰنِ",
                    phonemes=["rˤrˤ", "aˤ", "ħ", "m", "a:", "n", "i"]),
        SpecialWord(location="0:0:4", text="ٱلرَّحِيمِ",
                    phonemes=["rˤrˤ", "aˤ", "ħ", "i:", "m"]),
    ],
}

# Case-insensitive lookup: lowercase name → canonical key.
SPECIAL_KEYS = {k.lower(): k for k in SPECIAL_PHONEMES}

# Flat (chars, phonemes) letter mappings per special.
SPECIAL_FLAT_MAPPINGS: dict[str, list[tuple[str, list[str]]]] = {
    # Basmala: بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ — derived from 1:1
    "Basmala": [
        # Word 1: بِسْمِ → ["b", "i", "s", "m", "i"]
        ("ب", ["b", "i"]),
        ("س", ["s"]),
        ("م ", ["m", "i"]),
        # Word 2: ٱللَّهِ → ["ll", "a:", "h", "i"]
        # hamza wasl (silent) + first lam (idgham) → merge RIGHT into second lam
        ("ٱلل", ["ll", "a:"]),
        ("ه ", ["h", "i"]),
        # Word 3: ٱلرَّحْمَـٰنِ → ["rˤrˤ", "aˤ", "ħ", "m", "a:", "n", "i"]
        # hamza wasl (silent) + lam shamsiyah → merge RIGHT into raa
        ("ٱلر", ["rˤrˤ", "aˤ"]),
        ("ح", ["ħ"]),
        ("م", ["m"]),
        ("ـٰ", ["a:"]),  # tatweel + dagger alef carries the madd
        ("ن ", ["n", "i"]),
        # Word 4: ٱلرَّحِيمِ → ["rˤrˤ", "aˤ", "ħ", "i:", "m"]
        ("ٱلر", ["rˤrˤ", "aˤ"]),
        ("ح", ["ħ"]),
        ("ي", ["i:"]),
        ("م", ["m"]),
    ],
    # Isti'adha: أَعُوذُ بِٱللَّهِ مِنَ ٱلشَّيْطَـٰنِ ٱلرَّجِيمِ
    "Isti'adha": [
        # Word 1: أَعُوذُ → ["ʔ", "a", "ʕ", "u:", "ð", "u"]
        ("أ", ["ʔ", "a"]),
        ("ع", ["ʕ"]),      # damma popped for waw lengthening
        ("و", ["u:"]),     # waw carries the long vowel
        ("ذ ", ["ð", "u"]),
        # Word 2: بِٱللَّهِ → ["b", "i", "ll", "a:", "h", "i"]
        ("ب", ["b", "i"]),
        ("ٱلل", ["ll", "a:"]),  # hamza wasl (silent) + first lam (idgham) + second lam
        ("ه ", ["h", "i"]),
        # Word 3: مِنَ → ["m", "i", "n", "a"] — the fatha on nun produces "a"
        ("م", ["m", "i"]),
        ("ن ", ["n", "a"]),
        # Word 4: ٱلشَّيْطَـٰنِ → ["ʃʃ", "a", "j", "tˤ", "aˤ:", "n", "i"]
        # hamza wasl (silent) + lam shamsiyah → merge RIGHT into sheen
        ("ٱلش", ["ʃʃ", "a"]),
        ("ي", ["j"]),
        ("ط", ["tˤ"]),        # fatha popped for alef lengthening
        ("ـٰ", ["aˤ:"]),      # tatweel + dagger alef carries the madd
        ("ن ", ["n", "i"]),
        # Word 5: ٱلرَّجِيمِ → ["rˤrˤ", "aˤ", "ʒ", "i:", "m"]
        ("ٱلر", ["rˤrˤ", "aˤ"]),  # hamza wasl (silent) + lam shamsiyah
        ("ج", ["ʒ"]),         # kasra popped for yaa lengthening
        ("ي", ["i:"]),        # yaa carries the long vowel
        ("م", ["m"]),
    ],
}
