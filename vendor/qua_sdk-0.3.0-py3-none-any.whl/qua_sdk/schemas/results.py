"""Task result envelopes. A result records WHAT ran (keys, profile) with the data.

``ResultBase`` is the per-task envelope every task result inherits: profile
name, sdk version (auto-populated), schema version, per-stage StageMeta.
"""

from __future__ import annotations

from pydantic import Field

from qua_sdk.schemas.base import SdkModel

from qua_sdk.schemas.alignment import Alignment
from qua_sdk.schemas.regions import Regions
from qua_sdk.schemas.timing import Timings


def _sdk_version() -> str:
    from qua_sdk import __version__

    return __version__


class StageMeta(SdkModel):
    component_key: str            # registry key that produced this stage
    wall_s: float = 0.0
    metrics: dict = Field(default_factory=dict)  # per-component depth (retries, batches, VRAM, …)


class ResultBase(SdkModel):
    profile_name: str
    sdk_version: str = Field(default_factory=_sdk_version)
    schema_version: int = 1
    stages: dict[str, StageMeta] = Field(default_factory=dict)


class BatchAlignResult(ResultBase):
    regions: Regions
    alignment: Alignment
    timings: Timings | None = None
