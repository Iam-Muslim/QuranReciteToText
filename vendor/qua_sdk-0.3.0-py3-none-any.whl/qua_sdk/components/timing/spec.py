"""Timing: granular timestamps — a face of matching (was: "MFA").

Contract: ``TimingBackend.timestamps(Audio, Alignment, TimingParams,
emissions=..., deploy=...) -> Timings``. The backend slices audio per segment
region internally (incl. sample-format conversion) — callers never pre-slice.
Repetition segments use ``wrap_word_ranges`` to build the reading sequence
(occurrences appear once each, in reading order). ``emissions`` carries the
recognition stage's frame data (frame_rate_hz / frame_posteriors) for
frame-synchronous backends (CTC-seg); acoustic re-aligners (MFA) accept and
ignore it. Backends are swappable (MFA remote Space, MFA local pool, CTC-seg,
torchaudio FA); the profile-selected key fixes the algorithm family, the
deploy config fixes where it runs.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from qua_sdk.schemas import Alignment, Audio, Emissions, Granularity, Timings
from qua_sdk.schemas.base import SdkModel


class TimingParams(SdkModel):
    """Capability-generic surface: every timing backend picks a granularity
    and bounds its run. Method knobs (MFA beam/padding) live in method
    subclasses (e.g. ``MfaParams``)."""

    granularity: Granularity = Granularity.WORD
    timeout_s: int = 240


@runtime_checkable
class TimingBackend(Protocol):
    def timestamps(
        self,
        audio: Audio,
        alignment: Alignment,
        params: TimingParams,
        *,
        emissions: Emissions | None = None,
        deploy=None,
    ) -> Timings: ...
