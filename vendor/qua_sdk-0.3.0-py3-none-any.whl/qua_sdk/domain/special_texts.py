"""Arabic display texts + phoneme sequences for special segments (Basmala,
Isti'adha, transitions).

Domain facts, not component internals: the matcher attaches the texts as
``matched_text`` and edit-distances against the phoneme sequences; timing's
ref builder and prepare/recover pipeline consume both. Names align with
``refs.SPECIAL_NAMES``.
"""

from __future__ import annotations

SPECIAL_TEXT: dict[str, str] = {
    "Isti'adha": "أَعُوذُ بِٱللَّهِ مِنَ الشَّيْطَانِ الرَّجِيم",
    "Basmala": "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيم",
}

TRANSITION_TEXT: dict[str, str] = {
    "Amin": "آمِين",
    "Takbir": "اللَّهُ أَكْبَر",
    "Tahmeed": "سَمِعَ اللَّهُ لِمَنْ حَمِدَه",
    "Tasleem": "ٱلسَّلَامُ عَلَيْكُمْ وَرَحْمَةُ ٱللَّه",
    "Sadaqa": "صَدَقَ ٱللَّهُ ٱلْعَظِيم",
}

SPECIAL_PHONEMES: dict[str, tuple[str, ...]] = {
    "Isti'adha": (
        "ʔ", "a", "ʕ", "u:", "ð", "u", "b", "i", "ll", "a:", "h", "i", "m", "i", "n", "a", "ʃʃ", "a",
        "j", "tˤ", "aˤ:", "n", "i", "rˤrˤ", "aˤ", "ʒ", "i:", "m",
    ),
    "Basmala": (
        "b", "i", "s", "m", "i", "ll", "a:", "h", "i", "rˤrˤ", "aˤ", "ħ", "m", "a:", "n", "i", "rˤrˤ",
        "aˤ", "ħ", "i:", "m",
    ),
}
