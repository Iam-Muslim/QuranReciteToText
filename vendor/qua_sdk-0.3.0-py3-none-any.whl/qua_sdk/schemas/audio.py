"""Audio: the universal input. Always float32 mono at 16 kHz once loaded."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import numpy as np
from pydantic import ConfigDict, Field, WithJsonSchema, model_validator

from qua_sdk.schemas.base import SdkModel

TARGET_SAMPLE_RATE = 16_000


class Audio(SdkModel):
    """Either decoded samples or a source reference (path/URL) resolved by a loader.

    Runtimes that need decoded samples must raise InputError(AUDIO_UNREADABLE)
    on source-only Audio they cannot decode — never silently return empty.
    Frozen-ness is reference-level; samples are excluded from serialization.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True, frozen=True)

    # WithJsonSchema documents the ndarray for schema generation only — runtime
    # validation/serialization behavior (excluded binary array) is unchanged
    samples: Annotated[
        np.ndarray | None,
        WithJsonSchema({
            "type": "null",
            "description": "in-memory float32 sample array; excluded from serialization",
        }),
    ] = Field(default=None, exclude=True, repr=False)
    sample_rate: int = TARGET_SAMPLE_RATE
    source: str | None = None  # file path or URL, when not yet decoded

    def __eq__(self, other) -> bool:
        return (
            isinstance(other, Audio)
            and self.sample_rate == other.sample_rate
            and self.source == other.source
            and np.array_equal(
                self.samples if self.samples is not None else np.empty(0),
                other.samples if other.samples is not None else np.empty(0),
            )
        )

    __hash__ = object.__hash__

    @model_validator(mode="after")
    def _one_of(self):
        if self.samples is None and self.source is None:
            raise ValueError("Audio needs samples or source")
        return self

    @classmethod
    def from_array(cls, samples: np.ndarray, sample_rate: int = TARGET_SAMPLE_RATE) -> "Audio":
        return cls(samples=np.asarray(samples, dtype=np.float32), sample_rate=sample_rate)

    @classmethod
    def from_source(cls, source: str | Path) -> "Audio":
        return cls(source=str(source))

    @property
    def duration_s(self) -> float | None:
        if self.samples is None:
            return None
        return float(len(self.samples)) / self.sample_rate
