"""Method params for the recitation_v2 segmenter (eager + AOTI runtimes).

Import-light by design: profiles import this module directly, so it must not
pull torch/transformers (the runtimes keep heavy imports call-local).
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field, model_validator

from qua_sdk.components.segmentation.spec import SegmentationParams


class RecitationSegmenterParams(SegmentationParams):
    """Result-affecting knobs. The two consumers run DIFFERENT cleaning
    algorithms today — that choice is itself a result-affecting param."""

    cleaning: Literal["segmenter_native", "padded_floor"] = "segmenter_native"
    min_silence_ms: int = Field(200, ge=25, le=1000)
    # 0 disables the post-merge: short regions surface as failed alignments
    # instead of silently vanishing (the offline-extraction contract)
    min_speech_ms: int = Field(750, ge=0, le=2000)
    # padded_floor caps each pad by the neighbour gap, so large pads never
    # overlap the next region — extraction uses 500 right for qalqala tails
    pad_left_ms: int = Field(100, ge=0, le=1000)
    pad_right_ms: int = Field(100, ge=0, le=1000)
    min_silence_floor_ms: int = 30  # padded_floor only: min daylight between regions

    @model_validator(mode="after")
    def _native_takes_one_pad(self):
        if self.cleaning == "segmenter_native" and self.pad_left_ms != self.pad_right_ms:
            raise ValueError("segmenter_native cleaning takes a single pad: pad_left_ms must equal pad_right_ms")
        return self
