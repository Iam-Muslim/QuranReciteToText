"""RecitationSegmenter: w2v2-bert recitation segmenter (eager torch runtime).

Model lifecycle mirrors the legacy aligner: one CPU load cached per instance,
an explicit per-call device move from the deploy config (ZeroGPU leases move
models in and out), AOTI compile state alongside (``runtimes/aoti.py``).
Device/dtype come from ``deploy`` only — there is no ambient forced-CPU flag;
callers that want CPU pass a CPU deploy. Heavy imports (torch/transformers/
recitations_segmenter) stay inside methods so importing this module is cheap.
"""

from __future__ import annotations

import threading
import time
from typing import ClassVar

from qua_sdk.components.device import resolve_device_dtype
from qua_sdk.components.segmentation.cleaning import clean_native, clean_padded_floor
from qua_sdk.components.segmentation.runtimes.aoti import AotiState
from qua_sdk.components.segmentation.runtimes.recitation_params import RecitationSegmenterParams
from qua_sdk.components.segmentation.spec import Segmenter
from qua_sdk.errors import ComponentError, CompositionError, ErrorCode, InputError
from qua_sdk.observe import record_metrics
from qua_sdk.schemas import Audio, Region, Regions

MODEL_ID = "obadx/recitation-segmenter-v2"
DEFAULT_BATCH_SIZE = 8


class RecitationSegmenter(Segmenter):
    """Speech-region detection via obadx/recitation-segmenter-v2."""

    Params: ClassVar[type[RecitationSegmenterParams]] = RecitationSegmenterParams

    def __init__(self):
        self._lock = threading.Lock()
        self._model = None
        self._processor = None
        self._device = None   # tracked here, not probed from parameters
        self._dtype = None    # (AOTI drains parameters; probing would break)
        self.aoti = AotiState()

    def preload(self) -> float:
        """Load model + processor on CPU once. Thread-safe double-checked.

        Returns load seconds (0.0 when already cached).
        """
        if self._model is not None:
            return 0.0
        with self._lock:
            if self._model is not None:
                return 0.0
            t0 = time.perf_counter()
            try:
                import torch
                from transformers import AutoFeatureExtractor, AutoModelForAudioFrameClassification

                model = AutoModelForAudioFrameClassification.from_pretrained(MODEL_ID)
                model.to(torch.device("cpu"), dtype=torch.float32)
                model.eval()
                processor = AutoFeatureExtractor.from_pretrained(MODEL_ID)
            except Exception as e:
                raise ComponentError(
                    ErrorCode.MODEL_LOAD_FAILED,
                    f"failed to load segmenter model {MODEL_ID}",
                    stage="segmentation", component="segmentation.recitation_v2",
                    internal_detail=f"{type(e).__name__}: {e}",
                ) from e
            self._model = model
            self._processor = processor
            self._device, self._dtype = torch.device("cpu"), torch.float32
            return time.perf_counter() - t0

    def invalidate(self) -> None:
        """Drop the cached model (and AOTI state) so the next call reloads fresh."""
        with self._lock:
            self._model = None
            self._processor = None
            self._device = None
            self._dtype = None
            self.aoti = AotiState()

    def _ensure_on_device(self, deploy) -> float:
        """Move the cached model to the deploy's device/dtype. Returns move seconds.

        Skipped once AOTI is applied (the compiled graph owns the weights).
        A failed cuda move falls back to staying on CPU rather than poisoning
        the process — recorded in metrics, results are identical either way.
        """
        device, dtype = resolve_device_dtype(deploy)
        if self.aoti.applied or (device == self._device and dtype == self._dtype):
            return 0.0
        t0 = time.perf_counter()
        with self._lock:
            if device == self._device and dtype == self._dtype:
                return 0.0
            try:
                self._model.to(device, dtype=dtype)
                self._device, self._dtype = device, dtype
            except RuntimeError as e:
                record_metrics(device_move_failed=f"{type(e).__name__}: {e}")
                return 0.0
        return time.perf_counter() - t0

    def segment(self, audio: Audio, params: RecitationSegmenterParams, *, deploy=None) -> Regions:
        if audio.samples is None:
            raise InputError(
                ErrorCode.AUDIO_UNREADABLE,
                "RecitationSegmenter needs decoded samples",
                stage="segmentation", component="segmentation.recitation_v2",
            )
        model_load_s = self.preload()
        model_move_s = self._ensure_on_device(deploy)

        import torch
        from recitations_segmenter import segment_recitations

        audio_tensor = torch.from_numpy(audio.samples).float()
        # CPU sees no gain from batching (BLAS saturates cores; bs>1 adds cache pressure)
        batch_size = 1 if self._device.type == "cpu" else (
            deploy.segmentation_batch_size if deploy is not None else DEFAULT_BATCH_SIZE
        )

        t0 = time.perf_counter()
        try:
            outputs = segment_recitations(
                [audio_tensor], self._model, self._processor,
                device=self._device, dtype=self._dtype, batch_size=batch_size,
            )
        except Exception as e:
            raise ComponentError(
                ErrorCode.INFERENCE_FAILED,
                "segmenter inference failed",
                stage="segmentation", component="segmentation.recitation_v2",
                internal_detail=f"{type(e).__name__}: {e}",
            ) from e
        inference_s = time.perf_counter() - t0
        if not outputs:
            raise ComponentError(
                ErrorCode.INFERENCE_FAILED,
                "segmenter returned no output for the audio",
                stage="segmentation", component="segmentation.recitation_v2",
            )

        raw = outputs[0].speech_intervals
        is_complete = outputs[0].is_complete
        # numpy detach: no CUDA tensor refs escape the lease; picklable for subprocess use
        if hasattr(raw, "detach"):
            raw = raw.detach().cpu().numpy()
        if hasattr(is_complete, "detach"):
            is_complete = is_complete.detach().cpu().numpy()
        is_complete = bool(is_complete)

        raw_seconds = [(float(s) / 16000.0, float(e) / 16000.0) for s, e in raw.tolist()]
        cleaned = _dispatch_cleaning(raw_seconds, is_complete, params, audio.duration_s)

        record_metrics(
            model_id=MODEL_ID,
            model_load_s=round(model_load_s, 3),
            model_move_s=round(model_move_s, 3),
            inference_s=round(inference_s, 3),
            raw_count=len(raw_seconds),
            aoti_applied=self.aoti.applied,
        )
        return Regions(
            regions=[Region(start_s=s, end_s=e) for s, e in cleaned],
            is_complete=is_complete,
            raw=[Region(start_s=s, end_s=e) for s, e in raw_seconds],
            audio_duration_s=audio.duration_s,
        )

    def clean(self, raw: Regions, params: RecitationSegmenterParams) -> Regions:
        """Re-clean cached raw intervals with new params — no model pass."""
        if raw.raw is None:
            raise CompositionError(
                ErrorCode.SCHEMA_MISMATCH,
                "clean() needs Regions.raw (pre-cleaning intervals); run segment() first",
                stage="segmentation", component="segmentation.recitation_v2",
            )
        intervals = [(r.start_s, r.end_s) for r in raw.raw]
        is_complete = raw.is_complete if raw.is_complete is not None else True
        cleaned = _dispatch_cleaning(intervals, is_complete, params, raw.audio_duration_s)
        return Regions(
            regions=[Region(start_s=s, end_s=e) for s, e in cleaned],
            is_complete=raw.is_complete,
            raw=raw.raw,
            audio_duration_s=raw.audio_duration_s,
        )


def _dispatch_cleaning(intervals, is_complete, params, audio_duration_s):
    if params.cleaning == "segmenter_native":
        return clean_native(intervals, is_complete, params)
    if params.cleaning == "padded_floor":
        if audio_duration_s is None:
            raise CompositionError(
                ErrorCode.SCHEMA_MISMATCH,
                "padded_floor cleaning needs audio_duration_s (last region clamps against it)",
                stage="segmentation", component="segmentation.recitation_v2",
            )
        return clean_padded_floor(intervals, is_complete, params, audio_duration_s)
    raise CompositionError(
        ErrorCode.PROFILE_INVALID,
        f"unknown cleaning strategy {params.cleaning!r}",
        stage="segmentation", component="segmentation.recitation_v2",
    )
