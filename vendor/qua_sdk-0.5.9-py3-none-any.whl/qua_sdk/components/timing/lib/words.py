"""Word-level recovery over MFA phone intervals.

Intervals are plain dicts ``{start, end, phone, geminate_start?, geminate_end?}``
throughout the recovery pipeline (mutated in place by design — padding and
reverse-mapping operate on the same list the words index into). The ONE
silence set lives here; every consumer filters through ``is_active_phone``.

Pipeline order is load-bearing: ``build_words_from_mapping`` (raw intervals)
→ ``build_reverse_mapped_intervals`` (merge geminates, restore original
phoneme names) → ``pad_intervals`` → word-boundary allocation → boundary
refit → letters. Do not reorder.
"""

from __future__ import annotations

# MFA's non-speech labels + the empty phone a merged geminate's second half
# carries after reverse-mapping. ``psil`` is the model's dedicated
# boundary-silence phone (the SILENCE recipe seeds it at verse-start /
# inter-segment / verse-end): it is filtered out of word recovery exactly like
# sil/sp, so the whole-verse path can split on it and the inter-segment pause
# falls out as the gap between adjacent words.
# The model's dedicated boundary-silence phone (mirrors ``prepare.PSIL_TOKEN``):
# seeded at verse-start / inter-segment / verse-end. Unlike incidental sp/sil slop,
# a psil is a REAL pause, so ``pad_intervals`` never closes a gap that spans it —
# the pause then falls out as the inter-word gap once psil is filtered.
PSIL_PHONE = "psil"
SILENCE_PHONES = frozenset({"", "sil", "sp", "spn", PSIL_PHONE})


def is_active_phone(phone: str | None) -> bool:
    """True for a real speech phone (non-empty, not a silence label)."""
    return bool(phone) and phone not in SILENCE_PHONES


def build_words_from_mapping(intervals: list[dict], word_maps: list) -> list[dict]:
    """Walk non-silence intervals with a cursor, consuming each word's
    transformed phoneme count. Lenient truncation: when MFA returned fewer
    phones than expected, the last word takes what remains and the walk stops.

    ``word_maps`` entries need ``.location``, ``.text``, ``.phonemes``
    (phonemizer WordMapping or ``specials.SpecialWord``).
    """
    from qua_sdk.components.timing.lib.transforms import normalize_phonemes, transform_phonemes

    tg_phones = []
    for idx, iv in enumerate(intervals):
        if is_active_phone(iv["phone"]):
            tg_phones.append((idx, iv["phone"]))

    words_out = []
    cursor = 0
    for wm in word_maps:
        original_phonemes = list(wm.phonemes)
        raw = " ".join(original_phonemes)
        transformed = transform_phonemes(normalize_phonemes(raw))
        expected = transformed.split()
        if not expected:
            continue
        n = len(expected)
        if cursor + n > len(tg_phones):
            n = len(tg_phones) - cursor
            if n <= 0:
                break
        first_idx = tg_phones[cursor][0]
        last_idx = tg_phones[cursor + n - 1][0]
        phone_indices = [tg_phones[cursor + i][0] for i in range(n)]
        words_out.append({
            "location": wm.location,
            "text": wm.text,
            "start": intervals[first_idx]["start"],
            "end": intervals[last_idx]["end"],
            "phone_indices": phone_indices,
            "phonemes": original_phonemes,
        })
        cursor += n
    return words_out


def build_reverse_mapped_intervals(intervals: list[dict], words: list[dict]) -> list[dict]:
    """Restore original phoneme names on a COPY of the intervals.

    Single-token phonemes get renamed in place; geminates (transformed length
    exactly 2 — the only multi-token case the transform produces) merge: the
    first half takes the original name + ``geminate_start``, the second half
    becomes the empty phone + ``geminate_end``.
    """
    from qua_sdk.components.timing.lib.transforms import normalize_phonemes, transform_phonemes

    result = [dict(iv) for iv in intervals]
    for word in words:
        original_phonemes = word["phonemes"]
        phone_indices = word["phone_indices"]
        cursor = 0
        for orig_ph in original_phonemes:
            transformed = transform_phonemes(normalize_phonemes(orig_ph))
            mfa_phones = transformed.split()
            if not mfa_phones:
                continue
            n = len(mfa_phones)
            if cursor + n > len(phone_indices):
                break
            if n == 1:
                idx = phone_indices[cursor]
                result[idx]["phone"] = orig_ph
                cursor += 1
            elif n == 2:
                idx1 = phone_indices[cursor]
                idx2 = phone_indices[cursor + 1]
                result[idx1]["phone"] = orig_ph
                result[idx1]["geminate_start"] = True
                result[idx2]["phone"] = ""
                result[idx2]["geminate_end"] = True
                cursor += 2
    return result


def pad_intervals(mapped_intervals: list[dict], strategy: str = "forward") -> list[dict]:
    """Pad gaps between consecutive non-silence phones IN PLACE.

    strategy: "forward" (extend each phone's end to the next phone's start)
    | "symmetric" (split the gap at its midpoint) | "none". Only gaps BETWEEN
    active phones are touched — leading/trailing silence stays, and gap <= 0
    is skipped. A gap that spans a seeded ``psil`` (a real pause) is left intact
    so the whole-verse path recovers the inter-segment pause as a word gap.
    """
    if strategy == "none":
        return mapped_intervals

    active_indices = [
        i for i, iv in enumerate(mapped_intervals) if is_active_phone(iv.get("phone"))
    ]

    for j in range(len(active_indices) - 1):
        idx_a = active_indices[j]
        idx_b = active_indices[j + 1]
        # A seeded ``psil`` between two active phones marks a real pause boundary;
        # never close the gap across it, so the inter-segment / verse pause survives
        # as the gap between the adjacent words (sp/sil slop is still closed).
        if any(
            mapped_intervals[k].get("phone") == PSIL_PHONE for k in range(idx_a + 1, idx_b)
        ):
            continue
        gap = mapped_intervals[idx_b]["start"] - mapped_intervals[idx_a]["end"]
        if gap <= 0:
            continue
        if strategy == "forward":
            mapped_intervals[idx_a]["end"] = mapped_intervals[idx_b]["start"]
        elif strategy == "symmetric":
            mid = mapped_intervals[idx_a]["end"] + gap / 2
            mapped_intervals[idx_a]["end"] = mid
            mapped_intervals[idx_b]["start"] = mid

    return mapped_intervals


def nest_phones_in_words(words: list[dict], mapped_intervals: list[dict]) -> list[dict]:
    """Add a per-word ``phones`` list (active phones via ``phone_indices``,
    original names, 4dp) IN PLACE."""
    for w in words:
        word_phones = []
        for pi in w.get("phone_indices", []):
            if pi < len(mapped_intervals):
                iv = mapped_intervals[pi]
                ph = iv.get("phone", "")
                if is_active_phone(ph):
                    word_phones.append({
                        "phone": ph,
                        "start": round(iv["start"], 4),
                        "end": round(iv["end"], 4),
                    })
        w["phones"] = word_phones
    return words


def serializable_intervals(intervals: list[dict] | None) -> list[dict]:
    """Plain JSON-safe phone intervals incl. silences, geminate flags always
    present (the raw-alignment debug surface of the batch response)."""
    out = []
    for iv in intervals or []:
        out.append({
            "start": float(iv.get("start", 0.0)),
            "end": float(iv.get("end", 0.0)),
            "phone": iv.get("phone", ""),
            "geminate_start": bool(iv.get("geminate_start", False)),
            "geminate_end": bool(iv.get("geminate_end", False)),
        })
    return out
