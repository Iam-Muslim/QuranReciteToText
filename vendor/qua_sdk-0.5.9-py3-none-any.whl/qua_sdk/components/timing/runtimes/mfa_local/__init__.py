"""MfaLocalAligner: in-process MFA forced alignment (the Space's brain).

The runtime the qua-timing-space app drives: ``align_items`` takes
[(ref, audio_path), ...] plus resolved knobs and returns the wire
``BatchEnvelope``; ``timestamps`` is the TimingBackend face for in-process
SDK consumers (Inspector TS-job), mirroring ``MfaRemoteSpace``'s slice → align
→ ref-join flow without HTTP.

Registry key ``timing.mfa_local@v1`` (extra="mfa"). The ``mfa`` extra ships
only soundfile + tgt — montreal-forced-aligner/kalpy are conda-only and must
be provided by the environment (the Space image installs them via mamba).
Constructing the aligner eagerly builds the kalpy engine (the boot warm-up);
on machines without kalpy the engine degrades to None and "kalpy" requests
fall back to the ``mfa align_one`` subprocess.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Callable, ClassVar

import numpy as np

from qua_sdk.components.timing.lib import resolve_word_boundary_allocation
from qua_sdk.components.timing.refs import build_ref, word_line_indices
from qua_sdk.components.timing.runtimes.mfa_local.engine import (
    DEFAULT_BEAM,
    DEFAULT_RETRY_BEAM,
    KalpyEngine,
)
from qua_sdk.components.timing.runtimes.mfa_local.runner import run_batch
from qua_sdk.components.timing.runtimes.mfa_params import MfaParams
from qua_sdk.components.timing.spec import TimingBackend
from qua_sdk.components.timing.wire import BatchEnvelope, ResultRow
from qua_sdk.errors import ComponentError, ErrorCode, InputError
from qua_sdk.schemas import Alignment, Audio, Timings, WordTiming
from qua_sdk.schemas.timing import SegmentTiming

__all__ = ["MfaLocalAligner", "KalpyEngine"]

logger = logging.getLogger(__name__)

_MAX_WORKERS = 16


def _clamp_workers(n: int) -> int:
    return max(1, min(_MAX_WORKERS, n))


class MfaLocalAligner(TimingBackend):
    """Forced alignment with a local MFA model.

    Deploy knobs (where/how it runs, never the results): ``num_threads``
    fans batch items across thread-local aligners; ``use_pool`` dispatches
    across persistent worker processes instead (``num_workers``, 0 = follow
    num_threads); ``fst_cache`` toggles the shared FST graph cache.
    """

    Params: ClassVar[type[MfaParams]] = MfaParams

    def __init__(self, model_path: str | None = None, dictionary_path: str | None = None, *,
                 keep_q: bool | None = None, seed_psil: bool | None = None,
                 num_threads: int = 1, use_pool: bool = False, num_workers: int = 0,
                 fst_cache: bool = True):
        self.model_path = model_path or os.environ.get("MFA_MODEL_PATH")
        self.dictionary_path = dictionary_path or os.environ.get("MFA_DICTIONARY_PATH")
        if not self.model_path or not self.dictionary_path:
            raise ComponentError(
                ErrorCode.MODEL_LOAD_FAILED,
                "MfaLocalAligner needs an acoustic model + dictionary "
                "(ctor args or MFA_MODEL_PATH / MFA_DICTIONARY_PATH)",
                stage="timing", component="timing.mfa_local",
            )
        self.num_threads = _clamp_workers(num_threads)
        self.use_pool = use_pool
        self.num_workers = _clamp_workers(num_workers) if num_workers else self.num_threads
        self.fst_cache = fst_cache

        self._pool = None
        self._pool_lock = threading.Lock()
        self._index = None  # lazy QuranIndex, only for list-ref line attribution

        # Eager engine warm-up at boot; degrade to the align_one fallback
        # when the kalpy stack is unavailable.
        self.engine: KalpyEngine | None = None
        try:
            logger.info("Initializing KalpyEngine...")
            t0 = time.time()
            self.engine = KalpyEngine(self.model_path, self.dictionary_path,
                                      fst_cache=self.fst_cache)
            logger.info("KalpyEngine ready (%.2fs)", time.time() - t0)
        except Exception as e:
            logger.warning("KalpyEngine init failed (falling back to align_one): %s", e)

        # Whether to keep the qalqala Q phone through lab + recovery. The model
        # is the ground truth (engine.keep_q); the catalog/arg value is a
        # fallback for the engine-less align_one path, then a dictionary scan.
        if self.engine is not None:
            self.keep_q = self.engine.keep_q
        elif keep_q is not None:
            self.keep_q = keep_q
        else:
            self.keep_q = _dictionary_has_q(self.dictionary_path)
        logger.info("aligner keep_q=%s", self.keep_q)

        # Whether the model carries the boundary-silence phone ``psil`` (the
        # SILENCE recipe). A capability, not a mode: the per-segment ``align``
        # paths never seed psil; only the whole-verse ``align_verse`` does, and
        # only for a psil-capable model. Same 3-source precedence as keep_q —
        # engine (ground truth) → catalog/ctor value → dictionary scan.
        if self.engine is not None:
            self.supports_psil = self.engine.supports_psil
        elif seed_psil is not None:
            self.supports_psil = seed_psil
        else:
            self.supports_psil = _dictionary_has_psil(self.dictionary_path)
        logger.info("aligner supports_psil=%s", self.supports_psil)

    # -------------------------------------------------------------- batch API

    def align_items(self, refs_and_paths: list[tuple], *,
                    method: str = "kalpy",
                    beam: int | None = None, retry_beam: int | None = None,
                    shared_cmvn: bool = False, padding: str = "forward",
                    wb_allocation_resolved: dict | None = None) -> BatchEnvelope:
        """Align a batch of (ref, audio_path) items → the wire envelope.

        ``wb_allocation_resolved`` is a FULL {rule: choice} dict (run the
        request payload + env defaults through
        ``resolve_word_boundary_allocation`` first); None resolves to the
        system rule defaults. Unknown methods become per-item error rows
        (the dispatcher raises, the loop catches).
        """
        if not refs_and_paths:
            return BatchEnvelope(status="error",
                                 error="Both references and audio files are required")

        beam = beam if beam is not None else DEFAULT_BEAM
        retry_beam = retry_beam if retry_beam is not None else DEFAULT_RETRY_BEAM
        wb_allocation = (wb_allocation_resolved if wb_allocation_resolved is not None
                         else resolve_word_boundary_allocation(None))

        pool = None
        if self.use_pool and method == "kalpy" and self.engine is not None and not shared_cmvn:
            pool = self._ensure_pool()

        t_total = time.time()
        results = run_batch(
            refs_and_paths,
            engine=self.engine, dictionary_path=self.dictionary_path,
            model_path=self.model_path, keep_q=self.keep_q,
            method=method, beam=beam, retry_beam=retry_beam,
            use_shared_cmvn=shared_cmvn, padding=padding, wb_allocation=wb_allocation,
            num_threads=self.num_threads, pool=pool,
        )
        return BatchEnvelope(
            status="ok",
            count=len(results),
            elapsed_seconds=round(time.time() - t_total, 2),
            shared_cmvn=shared_cmvn,
            results=results,
        )

    def _ensure_pool(self):
        """Get-or-create the persistent worker pool (eager worker init so the
        spawn + model-load cost is paid before the first batch)."""
        from qua_sdk.components.timing.runtimes.mfa_local.runner import _pool_worker_init

        with self._pool_lock:
            if self._pool is None:
                import multiprocessing as mp
                from concurrent.futures import ProcessPoolExecutor

                ctx = mp.get_context("spawn")
                logger.info("Initializing MFA process pool: workers=%d", self.num_workers)
                t0 = time.time()
                self._pool = ProcessPoolExecutor(
                    max_workers=self.num_workers,
                    mp_context=ctx,
                    initializer=_pool_worker_init,
                    initargs=(str(self.model_path), str(self.dictionary_path),
                              self.fst_cache, self.keep_q),
                )
                futs = [self._pool.submit(os.getpid) for _ in range(self.num_workers)]
                for f in futs:
                    f.result()
                logger.info("MFA process pool ready (%.2fs)", time.time() - t0)
            return self._pool

    def get_retry_stats(self) -> tuple[int, int]:
        return self.engine.get_retry_stats() if self.engine is not None else (0, 0)

    def reset_retry_counter(self) -> None:
        if self.engine is not None:
            self.engine.reset_retry_counter()

    # ---------------------------------------------------------- whole-verse API

    def align_verse(self, segment_refs: list, audio, sample_rate: int, *,
                    beam: int | None = None, retry_beam: int | None = None,
                    seed_psil: bool | None = None, include_letters: bool = True,
                    padding: str = "forward", wasl_after: list | None = None,
                    wb_allocation_resolved: dict | None = None) -> list[dict]:
        """Whole-verse / recitation-item alignment: ONE MFA pass over a contiguous
        audio span with the boundary-silence ``psil`` seeded at item-start, every
        *silence* inter-segment boundary and item-end, then split back to
        per-segment rows. Frees the boundary phones from absorbing the pause — it
        now sits on psil and reappears as the gap between adjacent words.

        ``audio`` is the item's contiguous samples (float in [-1, 1] or int16);
        ``segment_refs`` the ordered segment refs. ``wasl_after[i]`` marks the
        boundary between segment ``i`` and ``i+1`` as waṣl (continuous): those
        segments are phonemized as one span (no psil, correct junction phonemes).
        psil is seeded when the model supports it (``seed_psil`` overrides the
        model capability). Returns ``[{"ref", "words"}, ...]`` in segment order,
        times in item-local seconds. Requires the in-process kalpy engine.
        """
        from qua_sdk.components.timing.lib import keep_q_context, prepare_verse, recover_verse
        from qua_sdk.components.timing.runtimes.remote_space import _write_temp_wav

        if not segment_refs:
            return []
        if self.engine is None:
            raise ComponentError(
                ErrorCode.INFERENCE_FAILED,
                "align_verse requires the in-process kalpy engine",
                stage="timing", component="timing.mfa_local",
            )
        seed = self.supports_psil if seed_psil is None else seed_psil
        beam = beam if beam is not None else DEFAULT_BEAM
        retry_beam = retry_beam if retry_beam is not None else DEFAULT_RETRY_BEAM
        wb = (wb_allocation_resolved if wb_allocation_resolved is not None
              else resolve_word_boundary_allocation(None))

        arr = np.asarray(audio)
        if arr.dtype != np.int16:
            arr = np.clip(arr * 32767, -32768, 32767).astype(np.int16)

        with keep_q_context(self.keep_q):
            prepared = prepare_verse(segment_refs, seed_psil=seed, wasl_after=wasl_after)
            wav_path = _write_temp_wav(arr, sample_rate)
            try:
                intervals = self.engine.align(
                    wav_path, prepared.lab_content, beam=beam, retry_beam=retry_beam)
            finally:
                try:
                    os.unlink(wav_path)
                except OSError:
                    pass
            return recover_verse(
                intervals, prepared, include_letters=include_letters,
                padding=padding, word_boundary_allocation=wb)

    # ------------------------------------------------------ TimingBackend face

    def timestamps(
        self,
        audio: Audio,
        alignment: Alignment,
        params: MfaParams,
        *,
        emissions=None,  # accepted per the seam contract; MFA re-aligns acoustically
        deploy=None,
        on_started: Callable[[], None] | None = None,
    ) -> Timings:
        from qua_sdk.components.timing.runtimes.remote_space import _write_temp_wav

        plan = [
            (seg, build_ref(seg.matched_ref, seg.matched_text, seg.wrap_word_ranges)
                  if seg.matched_ref and seg.confidence > 0 else None)
            for seg in alignment.segments
        ]
        to_align = [(seg, ref) for seg, ref in plan if ref is not None]
        if not to_align:
            return Timings(
                granularity=params.granularity,
                segments=[SegmentTiming(segment_id=seg.id, words=None) for seg, _ in plan],
                riwayah=alignment.riwayah,
            )

        if audio.samples is None:
            raise InputError(
                ErrorCode.AUDIO_UNREADABLE,
                "MfaLocalAligner needs decoded samples to slice segment audio",
                stage="timing", component="timing.mfa_local",
            )

        if on_started is not None:
            on_started()

        sr = audio.sample_rate
        wav_paths = []
        try:
            for seg, _ in to_align:
                chunk = audio.samples[int(seg.region.start_s * sr):int(seg.region.end_s * sr)]
                chunk_i16 = np.clip(chunk * 32767, -32768, 32767).astype(np.int16)
                wav_paths.append(_write_temp_wav(chunk_i16, sr))

            envelope = self.align_items(
                [(ref, path) for (_, ref), path in zip(to_align, wav_paths)],
                method="kalpy",
                beam=params.beam, retry_beam=params.retry_beam,
                shared_cmvn=bool(params.shared_cmvn), padding=params.padding,
                wb_allocation_resolved=resolve_word_boundary_allocation(
                    params.word_boundary_allocation),
            )
        finally:
            for p in wav_paths:
                try:
                    os.unlink(p)
                except OSError:
                    pass

        if envelope.status != "ok":
            raise ComponentError(
                ErrorCode.INFERENCE_FAILED,
                "MFA local align batch failed",
                stage="timing", component="timing.mfa_local",
                internal_detail=envelope.error,
            )

        results = envelope.results or []
        by_segment: dict[int, list[WordTiming] | None] = {}
        used: set[int] = set()
        for seg, ref in to_align:
            row = _find_row(results, ref, used)
            by_segment[seg.id] = self._build_words(row, ref) if row else None

        return Timings(
            granularity=params.granularity,
            segments=[SegmentTiming(segment_id=seg.id, words=by_segment.get(seg.id))
                      for seg, _ in plan],
            riwayah=alignment.riwayah,
        )

    def _build_words(self, row: ResultRow, ref) -> list[WordTiming] | None:
        """One ok row's words → WordTimings; line_idx attributed for list refs."""
        rows = row.words or []

        lines = None
        if isinstance(ref, list):
            lines = word_line_indices(ref, len(rows), self._quran_index())

        out: list[WordTiming] = []
        for i, word in enumerate(rows):
            out.append(WordTiming(
                location=word.location,
                start_s=word.start,
                end_s=word.end,
                letters=[(lt.char, lt.start, lt.end)
                         for lt in word.letters] if word.letters else None,
                line_idx=lines[i] if lines is not None else None,
            ))
        return out or None

    def _quran_index(self):
        if self._index is None:
            from qua_sdk.domain import load_quran_index

            self._index = load_quran_index()
        return self._index


def _dictionary_has_q(dictionary_path: str) -> bool:
    """True if the pronunciation lexicon contains the qalqala phone ``Q`` — the
    keep_q fallback when no kalpy engine is loaded (align_one path)."""
    try:
        with open(dictionary_path, encoding="utf-8") as fh:
            for line in fh:
                if "Q" in line.split():
                    return True
    except OSError:
        pass
    return False


def _dictionary_has_psil(dictionary_path: str) -> bool:
    """True if the lexicon carries the boundary-silence phone ``psil`` — the
    supports_psil fallback when no kalpy engine is loaded (align_one path)."""
    try:
        with open(dictionary_path, encoding="utf-8") as fh:
            for line in fh:
                if "psil" in line.split():
                    return True
    except OSError:
        pass
    return False


def _find_row(results: list[ResultRow], ref, used: set[int]) -> ResultRow | None:
    """First UNCONSUMED ok row whose echoed ref matches the one we sent —
    duplicate refs (two takes of one Basmala) each consume their own row."""
    for k, row in enumerate(results):
        if k not in used and row.ref == ref and row.status == "ok":
            used.add(k)
            return row
    return None
