"""Aligner model catalog — the single source of truth for selectable MFA models.

A model **store** (a directory, mounted/synced from a private repo or bucket) holds
one subdir per acoustic model plus a ``catalog.json`` manifest::

    catalog.json
    models/<id>/quran_aligner_model.zip
    models/<id>/dictionary.txt

``catalog.json``::

    {"default": "qalqala-v2",
     "models": [{"id": "qalqala-v2", "label": "Qalqala v2", "subdir": "models/qalqala-v2",
                 "keep_q": true},
                {"id": "legacy", "label": "Legacy (everyayah)", "subdir": "models/legacy",
                 "keep_q": false}]}

``keep_q`` records the model's intent; the aligner ultimately derives it from the
loaded model's phone inventory (a Q model can't be run Q-off — see
``lib/transforms``), so the manifest value is informational + the fallback for the
``align_one`` path. Adding a model = upload a subdir + one manifest line; no code
change. When no manifest exists the loader falls back to a single ``default`` model
from the bare store dir / the ``MFA_MODEL_PATH`` + ``MFA_DICTIONARY_PATH`` env vars
(back-compat with the pre-catalog single-model deployments).
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

MODEL_FILENAME = "quran_aligner_model.zip"
DICTIONARY_FILENAME = "dictionary.txt"
CATALOG_FILENAME = "catalog.json"

# Where a store is mounted when nothing is passed (the inspector job bind, the
# Space working tree, the offline Katana sync). Override with MFA_RUNTIME_DIR.
_DEFAULT_ROOTS = ("/aux/mfa-runtime",)


@dataclass(frozen=True)
class TimingModel:
    id: str
    label: str
    model_path: str
    dictionary_path: str
    keep_q: bool

    def exists(self) -> bool:
        return Path(self.model_path).is_file() and Path(self.dictionary_path).is_file()


@dataclass(frozen=True)
class Catalog:
    models: dict[str, TimingModel]
    default_id: str

    def resolve(self, model_id: str | None = None) -> TimingModel:
        mid = model_id or self.default_id
        if mid not in self.models:
            raise KeyError(
                f"unknown aligner model {mid!r}; available: {sorted(self.models)}")
        return self.models[mid]

    def list(self) -> list[TimingModel]:
        # default first, then the rest alphabetically
        rest = sorted((m for k, m in self.models.items() if k != self.default_id),
                      key=lambda m: m.id)
        return [self.models[self.default_id], *rest]


def _store_root(root: str | Path | None) -> Path | None:
    if root is not None:
        return Path(root)
    env = os.environ.get("MFA_RUNTIME_DIR", "").strip()
    if env:
        return Path(env)
    for cand in _DEFAULT_ROOTS:
        if (Path(cand) / CATALOG_FILENAME).is_file() or (Path(cand) / MODEL_FILENAME).is_file():
            return Path(cand)
    return None


def _fallback_catalog(root: Path | None) -> Catalog:
    """No manifest → a single ``default`` model from the bare store dir or the
    MFA_MODEL_PATH / MFA_DICTIONARY_PATH env vars (pre-catalog deployments)."""
    if root is not None and (root / MODEL_FILENAME).is_file():
        model_path, dict_path = str(root / MODEL_FILENAME), str(root / DICTIONARY_FILENAME)
    else:
        model_path = os.environ.get("MFA_MODEL_PATH", "").strip()
        dict_path = os.environ.get("MFA_DICTIONARY_PATH", "").strip()
    if not model_path or not dict_path:
        raise FileNotFoundError(
            "no aligner-model catalog and no MFA_MODEL_PATH/MFA_DICTIONARY_PATH "
            f"(looked under {root or _DEFAULT_ROOTS})")
    m = TimingModel("default", "Default", model_path, dict_path, keep_q=False)
    return Catalog({"default": m}, "default")


def load_catalog(root: str | Path | None = None) -> Catalog:
    """Load the model catalog from a store root (arg → MFA_RUNTIME_DIR → defaults).
    Falls back to a single ``default`` model when no manifest is present."""
    base = _store_root(root)
    manifest = (base / CATALOG_FILENAME) if base is not None else None
    if manifest is None or not manifest.is_file():
        return _fallback_catalog(base)

    data = json.loads(manifest.read_text(encoding="utf-8"))
    models: dict[str, TimingModel] = {}
    for entry in data.get("models", []):
        sub = base / entry["subdir"]
        models[entry["id"]] = TimingModel(
            id=entry["id"],
            label=entry.get("label", entry["id"]),
            model_path=str(sub / MODEL_FILENAME),
            dictionary_path=str(sub / DICTIONARY_FILENAME),
            keep_q=bool(entry.get("keep_q", False)),
        )
    if not models:
        return _fallback_catalog(base)
    default_id = data.get("default") or next(iter(models))
    if default_id not in models:
        raise ValueError(f"catalog default {default_id!r} is not a listed model")
    return Catalog(models, default_id)


def resolve_model(model_id: str | None = None, root: str | Path | None = None) -> TimingModel:
    """Convenience: load the catalog and resolve one model (default if None)."""
    return load_catalog(root).resolve(model_id)


def default_model_id(root: str | Path | None = None) -> str:
    return load_catalog(root).default_id


def list_models(root: str | Path | None = None) -> list[TimingModel]:
    return load_catalog(root).list()
