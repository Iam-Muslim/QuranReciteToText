"""Deterministic fake matcher for the conformance harness."""

from __future__ import annotations

from typing import ClassVar

from qua_sdk.components.matching.spec import Matcher, MatchingParams
from qua_sdk.schemas import AlignedSegment, Alignment, Emissions, Regions


class FakeMatcher(Matcher):
    """Matches region i to word i+1 of the hinted (or first) chapter."""

    Params: ClassVar[type[MatchingParams]] = MatchingParams

    def match(
        self,
        emissions: Emissions,
        regions: Regions,
        params: MatchingParams,
        *,
        chapter_hint: int | None = None,
        deploy=None,
    ) -> Alignment:
        chapter = chapter_hint if (chapter_hint and not params.autodetect_chapter) else 1
        segments = []
        for i, region in enumerate(regions):
            toks = emissions.tokens[i] if i < len(emissions.tokens) else []
            if not toks:
                segments.append(AlignedSegment(id=i, region=region, error="Low confidence"))
                continue
            segments.append(
                AlignedSegment(
                    id=i,
                    region=region,
                    matched_ref=f"{chapter}:1:{i + 1}",
                    matched_text=f"word{i + 1}",
                    confidence=0.9,
                )
            )
        return Alignment(segments=segments, chapter=chapter, inventory_mode=emissions.inventory_mode)
