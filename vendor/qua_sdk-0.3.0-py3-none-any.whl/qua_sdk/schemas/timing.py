"""Timings: granular timestamps (timing output) with granularity projection.

Entries join to AlignedSegments by ``segment_id``, never by list position.
``Granularity.PHONEME`` is declared but its shape lands with the tajweed task.
"""

from __future__ import annotations

from enum import Enum

from qua_sdk.schemas.base import SdkModel


class Granularity(str, Enum):
    SEGMENT = "segment"
    WORD = "word"
    LETTER = "letter"
    PHONEME = "phoneme"


class WordTiming(SdkModel):
    location: str                    # "2:255:1" (surah:ayah:word)
    start_s: float
    end_s: float
    letters: list[tuple[str, float | None, float | None]] | None = None
    line_idx: int | None = None      # reading-sequence line this occurrence belongs to (repetitions)


class SegmentTiming(SdkModel):
    segment_id: int                  # AlignedSegment.id this belongs to
    words: list[WordTiming] | None   # None = backend failed for this segment
    # repeated locations (wraps) appear once per occurrence, in reading order


class Timings(SdkModel):
    granularity: Granularity = Granularity.WORD
    segments: list[SegmentTiming]
    riwayah: str = "hafs"                # open set

    def __len__(self) -> int:
        return len(self.segments)

    def __iter__(self):
        return iter(self.segments)
