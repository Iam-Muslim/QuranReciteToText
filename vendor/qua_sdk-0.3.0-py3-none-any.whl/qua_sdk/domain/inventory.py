"""Phoneme inventory: a domain object the matcher consumes, never a process global.

Modes mirror today's ASR vocab reality: "full" (72 tokens) vs "simple" (38,
collapsed). Wraps quranic-phonemizer lazily; tests can construct inventories
from explicit token sets without the package installed.
"""

from __future__ import annotations

from functools import lru_cache


class PhonemeInventory:
    def __init__(self, mode: str, tokens: frozenset[str]):
        self.mode = mode
        self.tokens = tokens

    def __contains__(self, token: str) -> bool:
        return token in self.tokens

    def __len__(self) -> int:
        return len(self.tokens)

    @classmethod
    def from_tokens(cls, mode: str, tokens) -> "PhonemeInventory":
        return cls(mode, frozenset(tokens))


@lru_cache(maxsize=4)
def load_inventory(mode: str = "full") -> PhonemeInventory:
    """Derive the inventory from the phonemizer (full corpus pass, cached)."""
    from quranic_phonemizer import Phonemizer  # lazy: heavy data load

    ph = Phonemizer()
    result = ph.phonemize(ref="1:1-114:6", mode=mode)
    tokens = {p for word in result.words for p in word.phonemes}
    return PhonemeInventory.from_tokens(mode, tokens)
