"""Waqf-sakt (ۜ) points: obligatory mid-verse pauses in the Hafs mushaf.

A reciter pauses inside the verse at these points, so an energy-based
segmenter splits one verse across two segments. The matcher heals the split
with an always-on auto-merge (see ``matching.runtimes.runtime``); this module
owns the mushaf facts — which word boundaries are sakt points — and the
predicate over a pair of adjacent matched refs.
"""

from __future__ import annotations

# (surah, ayah, last word before the pause, first word after the pause)
WAQF_SAKT_POINTS: tuple[tuple[int, int, int, int], ...] = (
    (75, 27, 2, 3),  # مَنْ ۜ رَاقٍ
    (83, 14, 2, 3),  # بَلْ ۜ رَانَ
)


def _ref_endpoint(ref: str, *, end: bool) -> tuple[int, int, int] | None:
    """``(surah, ayah, word)`` from the start or end of a matched-ref span."""
    part = ref.split("-")[-1 if end else 0]
    tokens = part.split(":")
    if len(tokens) != 3:
        return None
    try:
        return (int(tokens[0]), int(tokens[1]), int(tokens[2]))
    except ValueError:
        return None


def is_waqf_sakt_split(ref_a: str, ref_b: str) -> bool:
    """True when two adjacent matched refs straddle a sakt point."""
    end_a = _ref_endpoint(ref_a, end=True)
    start_b = _ref_endpoint(ref_b, end=False)
    if end_a is None or start_b is None:
        return False
    return any(
        end_a == (s, a, w_before) and start_b == (s, a, w_after)
        for s, a, w_before, w_after in WAQF_SAKT_POINTS
    )
