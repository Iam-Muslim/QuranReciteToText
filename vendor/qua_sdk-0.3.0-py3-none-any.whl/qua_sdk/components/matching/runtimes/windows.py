"""Per-segment alignment: window a chapter reference and run the wraparound DP.

Port of the aligner's ``align_segment``: estimate the word span from phoneme
count (banker's ``round``), slice a [pointer - lookback, pointer + est + lookahead]
window from the pre-flattened chapter reference, optionally prepend Basmala
phonemes as sentinel rows (so a fused Basmala+verse segment can consume them),
run the DP, then threshold-check and map phoneme indices back to words. The
end-of-chapter test is ``win_start >= num_words`` — NOT ``pointer >= num_words``;
a pointer past the end still aligns while the lookback window reaches real words.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

from qua_sdk.components.matching.runtimes.wraparound import align_wraparound
from qua_sdk.components.matching.runtimes.wraparound_params import WraparoundDpParams
from qua_sdk.domain.chapter_refs import ChapterReference, RefWord
from qua_sdk.domain.sub_costs import SubCostTable

BASMALA_SENTINEL = -1


@dataclass
class AlignmentResult:
    """Result of aligning one segment against a chapter window."""

    start_word_idx: int        # index into ChapterReference.words
    end_word_idx: int          # index into ChapterReference.words (inclusive)
    edit_cost: float           # raw edit distance (non-integer with substitution costs)
    confidence: float          # 1.0 - normalized distance

    j_start: int               # start phoneme index in the R window
    best_j: int                # end phoneme index in the R window (exclusive)

    start_word: RefWord
    end_word: RefWord

    basmala_consumed: bool = False

    # Repetition detection (wraparound DP)
    n_wraps: int = 0
    max_j_reached: int = 0
    wrap_points: list = None        # [(i, j_end, j_start), ...]
    wrap_word_ranges: list = None   # [(jump_to, jump_from, repeat_end) locations, ...]

    @property
    def ref_from(self) -> str:
        return self.start_word.location

    @property
    def ref_to(self) -> str:
        return self.end_word.location

    @property
    def matched_ref(self) -> str:
        return f"{self.ref_from}-{self.ref_to}"


def get_matched_text(chapter_ref: ChapterReference, result: AlignmentResult) -> str:
    """Arabic text for the aligned word span."""
    words = chapter_ref.words[result.start_word_idx : result.end_word_idx + 1]
    return " ".join(w.text for w in words)


def align_segment(
    asr_phonemes: list[str],
    chapter_ref: ChapterReference,
    pointer: int,
    params: WraparoundDpParams,
    sub_table: SubCostTable,
    *,
    basmala_prefix: Optional[Sequence[str]] = None,
    lookback_override: Optional[int] = None,
    lookahead_override: Optional[int] = None,
    max_edit_distance_override: Optional[float] = None,
) -> tuple[Optional[AlignmentResult], dict]:
    """Align one segment's phonemes against the chapter around ``pointer``.

    ``basmala_prefix`` (the active-mode Basmala template) prepends sentinel rows
    so the DP can consume a fused Basmala+verse segment. The overrides widen the
    window / relax the threshold for the retry tier.

    Returns (AlignmentResult or None, trace dict). The trace carries the DP's
    best-candidate stats so failed segments still surface how close they came.
    """
    trace: dict = {}

    P = asr_phonemes
    m = len(P)

    if m == 0:
        return None, trace

    words = chapter_ref.words
    avg_phones = chapter_ref.avg_phones_per_word
    num_words = chapter_ref.num_words

    # === WINDOW SETUP ===
    # 1. Estimate word count from phoneme count (banker's rounding, as legacy)
    est_words = max(1, round(m / avg_phones))

    # 2. Define search window (word indices)
    lb = lookback_override if lookback_override is not None else params.lookback_words
    la = lookahead_override if lookahead_override is not None else params.lookahead_words
    win_start = max(0, pointer - lb)
    win_end = min(num_words, pointer + est_words + la)

    # End of chapter check
    if win_start >= num_words:
        return None, trace

    # 3. Slice pre-flattened phoneme window
    phone_start = chapter_ref.word_phone_offsets[win_start]
    phone_end = chapter_ref.word_phone_offsets[win_end]

    R = chapter_ref.flat_phonemes[phone_start:phone_end]
    R_phone_to_word = chapter_ref.flat_phone_to_word[phone_start:phone_end]

    if basmala_prefix is not None:
        prefix_len = len(basmala_prefix)
        R = list(basmala_prefix) + list(R)
        R_phone_to_word = [BASMALA_SENTINEL] * prefix_len + list(R_phone_to_word)

    n = len(R)
    if n == 0:
        return None, trace

    trace.update({
        "win_start": win_start,
        "win_end": win_end,
        "j_start": None,
        "best_j": None,
        "basmala_consumed": False,
        "norm_dist": None,
        "best_cost": None,
        "n_wraps": 0,
        "max_j_reached": 0,
        "threshold": None,
        "threshold_failed": False,
    })

    # === DP ===
    dp = align_wraparound(
        P, R, R_phone_to_word, sub_table,
        expected_word=pointer,
        prior_weight=params.start_prior_weight,
        cost_sub=params.cost_substitution,
        cost_del=params.cost_deletion,
        cost_ins=params.cost_insertion,
        wrap_penalty=params.wrap_penalty,
        max_wraps=params.max_wraps,
        scoring_mode=params.wrap_scoring_mode,
        wrap_score_cost=params.wrap_score_cost,
        wrap_span_weight=params.wrap_span_weight,
    )
    best_j, j_start, best_cost, norm_dist = dp.best_j, dp.j_start, dp.best_cost, dp.norm_dist
    n_wraps, max_j_reached, wrap_points = dp.n_wraps, dp.max_j_reached, dp.wrap_points

    _finite = float("inf")
    trace["best_cost"] = None if best_cost >= _finite else float(best_cost)
    trace["norm_dist"] = None if norm_dist >= _finite else float(norm_dist)
    trace["n_wraps"] = int(n_wraps)
    trace["max_j_reached"] = int(max_j_reached)
    trace["j_start"] = j_start
    trace["best_j"] = best_j

    # === RESULT BUILD ===
    if best_j is None:
        return None, trace

    # Acceptance threshold
    threshold = (max_edit_distance_override if max_edit_distance_override is not None
                 else params.max_edit_distance)
    trace["threshold"] = float(threshold)
    if norm_dist > threshold:
        trace["threshold_failed"] = True
        return None, trace

    confidence = 1.0 - norm_dist

    # Map phoneme indices to word indices
    start_word_idx = R_phone_to_word[j_start]
    end_word_idx = R_phone_to_word[best_j - 1]

    # When wraps detected, the furthest position reached is the real end word
    if n_wraps > 0 and max_j_reached > best_j:
        end_word_idx = R_phone_to_word[max_j_reached - 1]

    # Prefix handling: alignment starting in the Basmala rows must still cover
    # real verse content — a whole-match-is-Basmala is rejected.
    basmala_consumed = False
    if basmala_prefix is not None and start_word_idx == BASMALA_SENTINEL:
        basmala_consumed = True
        for k in range(j_start, best_j):
            if R_phone_to_word[k] != BASMALA_SENTINEL:
                start_word_idx = R_phone_to_word[k]
                break
        else:
            return None, trace

    result = AlignmentResult(
        start_word_idx=start_word_idx,
        end_word_idx=end_word_idx,
        edit_cost=best_cost,
        confidence=confidence,
        j_start=j_start,
        best_j=best_j,
        start_word=words[start_word_idx],
        end_word=words[end_word_idx],
        basmala_consumed=basmala_consumed,
        n_wraps=n_wraps,
        max_j_reached=max_j_reached,
        wrap_points=wrap_points,
    )

    # Wrap word ranges: (jump_to, jump_from, repeat_end) per wrap, where
    # repeat_end is where the DP finishes after the wrap (next wrap's origin,
    # or the final end for the last one).
    if n_wraps > 0 and wrap_points:
        wrap_word_ranges = []
        for wp_idx, (_i_pos, _j_end, _j_start) in enumerate(wrap_points):
            jump_to = words[R_phone_to_word[_j_start]].location
            jump_from = words[R_phone_to_word[_j_end - 1]].location
            if wp_idx < len(wrap_points) - 1:
                post_end = wrap_points[wp_idx + 1][1]
            else:
                post_end = best_j
            repeat_end = words[R_phone_to_word[post_end - 1]].location
            wrap_word_ranges.append((jump_to, jump_from, repeat_end))
        result.wrap_word_ranges = wrap_word_ranges

    trace["j_start"] = j_start
    trace["best_j"] = best_j
    trace["basmala_consumed"] = basmala_consumed

    return result, trace
