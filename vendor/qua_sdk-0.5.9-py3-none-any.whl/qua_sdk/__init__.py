"""qua_sdk — the Quranic-audio ML substrate.

Layers (downward deps only): domain → schemas → components → tasks/pipelines.
Profiles change results; deploy configs change where/how things run.
Entry point: ``run(task, profile=..., **inputs)``.
"""

from qua_sdk.runner import run

__version__ = "0.5.9"
__all__ = ["run", "__version__"]
