"""Top-level entry: ``run(task, profile=..., **inputs)`` — resolve, validate, execute.

Importing the runner registers built-in components and auto-imports every
module under qua_sdk.tasks / qua_sdk.pipelines, so a new task is new files
only — no edits here. ``task`` accepts "batch_align" (→ @v1) or
"batch_align@v2". The profile and every declared input are isinstance-checked
against the TaskDecl's dotted types — a wrong profile type fails here with a
named error, never by duck-typing into the wrong pipeline.
"""

from __future__ import annotations

import functools
import importlib
import pkgutil
from typing import Any

import qua_sdk.components  # noqa: F401  (registers component runtimes)
import qua_sdk.pipelines
import qua_sdk.tasks
from qua_sdk.errors import CompositionError, ErrorCode
from qua_sdk.registry import resolve

for _pkg in (qua_sdk.tasks, qua_sdk.pipelines):
    for _m in pkgutil.iter_modules(_pkg.__path__):
        importlib.import_module(f"{_pkg.__name__}.{_m.name}")


@functools.lru_cache
def _import_dotted(dotted: str) -> type:
    module, _, attr = dotted.rpartition(".")
    return getattr(importlib.import_module(module), attr)


def _check_declared(kwarg: str, value: Any, dotted: str, code: ErrorCode) -> None:
    expected = _import_dotted(dotted)
    if not isinstance(value, expected):
        raise CompositionError(
            code,
            f"{kwarg}= expects {expected.__name__}, got {type(value).__name__}",
        )


def run(task: str, *, profile, deploy=None, pipeline: str | None = None, **inputs) -> Any:
    """Execute a task: ``run("batch_align", profile=my_profile, audio=Audio.from_source(p))``.

    ``pipeline`` overrides the task's default fulfillment; ``deploy`` selects
    where/how (device, batching, lease shape) without changing result content.
    Kwargs not in the decl's inputs (precomputed stage outputs, hints) pass
    through to the pipeline untouched.
    """
    key = f"task.{task}" if "@" in task else f"task.{task}@v1"
    decl = resolve(key)
    _check_declared("profile", profile, decl.profile_schema, ErrorCode.PROFILE_INVALID)
    for kwarg, dotted in decl.inputs.items():
        if kwarg in inputs:
            _check_declared(kwarg, inputs[kwarg], dotted, ErrorCode.INPUT_INVALID)
    fn = resolve(pipeline or decl.default_pipeline)
    return fn(profile=profile, deploy=deploy, **inputs)
