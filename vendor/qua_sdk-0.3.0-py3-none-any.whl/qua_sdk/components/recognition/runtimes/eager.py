"""W2v2CtcRecognizer: wav2vec2-CTC phoneme recognition (eager torch runtime).

Models cache per ``repo_id@revision`` — Base and Large can coexist, ZeroGPU
leases move the requested one to cuda per call. Aliases resolve through
``models.KNOWN_MODELS`` (params.revision None → the manifest pin; "stable" →
the movable Hub pointer). Region audio is sliced internally from
``Audio.samples``; batch shape/dtype/compile come from the deploy config.
Heavy imports are method-local.
"""

from __future__ import annotations

import os
import threading
import time
from typing import ClassVar

from qua_sdk.components.device import resolve_device_dtype
from qua_sdk.components.recognition.batching import (
    build_batches,
    build_batches_naive,
    ids_to_phoneme_list,
)
from qua_sdk.components.recognition.models import KNOWN_MODELS
from qua_sdk.components.recognition.spec import RecognitionParams, Recognizer
from qua_sdk.errors import ComponentError, ErrorCode, InputError
from qua_sdk.observe import record_metrics
from qua_sdk.schemas import Audio, Emissions, Regions

MODEL_FRAMES_PER_SEC = 50  # both w2v2 base and xls-r downsample 320× (16 kHz → 50 fps)

# defaults when no deploy config is passed (mirror deploy.BatchingConfig)
DEFAULT_BATCHING = {"strategy": "dynamic", "max_batch_seconds": 600,
                    "max_pad_waste": 0.2, "min_batch_size": 8, "naive_batch_size": 32}


def resolve_model(model: str, revision: str | None = None) -> tuple[str, str | None]:
    """Alias or raw repo id → (repo_id, revision). None revision → manifest pin."""
    ref = KNOWN_MODELS.get(model)
    repo_id = ref.repo_id if ref else model
    if revision is None and ref is not None:
        revision = ref.revision
    return repo_id, revision


def _hf_token() -> str | None:
    """HF token: env HF_TOKEN, falling back to the local huggingface_hub login."""
    token = os.environ.get("HF_TOKEN")
    if not token:
        try:
            from huggingface_hub import HfFolder

            token = HfFolder.get_token()
        except Exception:
            token = None
    return token


class W2v2CtcRecognizer(Recognizer):
    """Greedy-CTC phoneme transcription over speech regions."""

    Params: ClassVar[type[RecognitionParams]] = RecognitionParams

    def __init__(self):
        self._lock = threading.Lock()
        self._cache: dict[str, dict] = {}  # "repo_id@revision" -> entry

    def preload(self, model: str, revision: str | None = None) -> float:
        """Load a model on CPU once. Returns load seconds (0.0 when cached)."""
        repo_id, revision = resolve_model(model, revision)
        _, load_s = self._load(repo_id, revision)
        return load_s

    def invalidate(self, model: str | None = None) -> None:
        """Drop cached model(s); None drops all. Next use reloads fresh."""
        with self._lock:
            if model is None:
                self._cache.clear()
                return
            repo_id, _ = resolve_model(model)
            for key in [k for k in self._cache if k.split("@")[0] == repo_id]:
                del self._cache[key]

    def _load(self, repo_id: str, revision: str | None) -> tuple[dict, float]:
        key = f"{repo_id}@{revision}"
        if key in self._cache:
            return self._cache[key], 0.0
        with self._lock:
            if key in self._cache:
                return self._cache[key], 0.0
            t0 = time.perf_counter()
            try:
                import logging

                import torch
                from transformers import AutoModelForCTC, AutoProcessor

                logging.getLogger("transformers").setLevel(logging.WARNING)
                token = _hf_token()
                model = AutoModelForCTC.from_pretrained(
                    repo_id, revision=revision, token=token, attn_implementation="sdpa",
                )
                model.to(torch.device("cpu"), dtype=torch.float32)
                model.eval()
                processor = AutoProcessor.from_pretrained(repo_id, revision=revision, token=token)
            except Exception as e:
                raise ComponentError(
                    ErrorCode.MODEL_LOAD_FAILED,
                    f"failed to load ASR model {repo_id}",
                    stage="recognition", component="recognition.w2v2_ctc",
                    internal_detail=f"revision={revision!r}: {type(e).__name__}: {e}",
                ) from e
            entry = {
                "model": model, "processor": processor,
                "device": torch.device("cpu"), "dtype": torch.float32,
                "compiled": False,
            }
            self._cache[key] = entry
            return entry, time.perf_counter() - t0

    def _ensure_on_device(self, entry: dict, deploy) -> float:
        """Move the entry's model to the deploy device/dtype; compile on cuda."""
        import torch

        device, dtype = resolve_device_dtype(deploy)
        move_s = 0.0
        if (device, dtype) != (entry["device"], entry["dtype"]):
            t0 = time.perf_counter()
            with self._lock:
                if (device, dtype) != (entry["device"], entry["dtype"]):
                    try:
                        entry["model"] = entry["model"].to(device, dtype=dtype)
                        entry["device"], entry["dtype"] = device, dtype
                    except RuntimeError as e:
                        record_metrics(device_move_failed=f"{type(e).__name__}: {e}")
                        return 0.0
            move_s = time.perf_counter() - t0
        wants_compile = deploy is not None and getattr(deploy, "torch_compile", False)
        if wants_compile and device.type == "cuda" and not entry["compiled"]:
            entry["model"] = torch.compile(entry["model"], mode="reduce-overhead")
            entry["compiled"] = True
        return move_s

    def transcribe(
        self, audio: Audio, regions: Regions, params: RecognitionParams, *, deploy=None,
    ) -> Emissions:
        inventory_mode = params.inventory_mode or "full"
        if len(regions) == 0:
            return Emissions(tokens=[], inventory_mode=inventory_mode)
        if audio.samples is None:
            raise InputError(
                ErrorCode.AUDIO_UNREADABLE,
                "W2v2CtcRecognizer needs decoded samples",
                stage="recognition", component="recognition.w2v2_ctc",
            )

        sr = audio.sample_rate
        segment_audios = [
            audio.samples[int(r.start_s * sr):int(r.end_s * sr)] for r in regions
        ]
        durations = [len(a) / sr for a in segment_audios]

        repo_id, revision = resolve_model(params.model, params.revision)
        entry, model_load_s = self._load(repo_id, revision)
        model_move_s = self._ensure_on_device(entry, deploy)

        t_sort = time.perf_counter()
        sorted_indices = sorted(range(len(segment_audios)), key=lambda i: durations[i])
        sorting_s = time.perf_counter() - t_sort

        bc = getattr(deploy, "batching", None)
        cfg = {k: getattr(bc, k, v) for k, v in DEFAULT_BATCHING.items()}
        t_build = time.perf_counter()
        if cfg["strategy"] == "naive":
            batches = build_batches_naive(sorted_indices, cfg["naive_batch_size"])
        else:
            batches = build_batches(
                sorted_indices, durations,
                max_batch_seconds=cfg["max_batch_seconds"],
                max_pad_waste=cfg["max_pad_waste"],
                min_batch_size=cfg["min_batch_size"],
            )
        batch_build_s = time.perf_counter() - t_build

        results, batch_profiling, frame_rate_hz, posteriors = self._run_batches(
            segment_audios, durations, batches, entry,
            keep_posteriors=params.keep_frame_posteriors,
        )

        record_metrics(
            model_id=f"{repo_id}@{revision}" if revision else repo_id,
            batches=batch_profiling,
            sorting_s=round(sorting_s, 3),
            batch_build_s=round(batch_build_s, 3),
            model_load_s=round(model_load_s, 3),
            model_move_s=round(model_move_s, 3),
        )
        return Emissions(tokens=results, inventory_mode=inventory_mode,
                         frame_rate_hz=frame_rate_hz, frame_posteriors=posteriors)

    def _run_batches(self, segment_audios, durations, batches, entry, *, keep_posteriors=False):
        """Forward + greedy CTC decode per batch, with per-batch profiling.

        ``frame_rate_hz`` is measured from the real logits length vs the padded
        input length (not hardcoded). ``keep_posteriors`` retains per-region
        softmax arrays trimmed to each region's true frame count; the default
        path retains nothing (logits freed as before).
        """
        import torch

        model, processor = entry["model"], entry["processor"]
        device, dtype = entry["device"], entry["dtype"]
        tokenizer = processor.tokenizer
        pad_id = tokenizer.pad_token_id if tokenizer.pad_token_id is not None else 0

        results: list[list[str]] = [[] for _ in segment_audios]
        batch_profiling: list[dict] = []
        frame_rate_hz: float | None = None
        posteriors: list | None = [None] * len(segment_audios) if keep_posteriors else None

        # QK^T-bytes estimate per batch: the CPU SDPA math backend materialises
        # (batch, heads, seq, seq) — past L3 size, attention goes DRAM-bound.
        num_heads = getattr(model.config, "num_attention_heads", 0)
        dtype_bytes = torch.tensor([], dtype=dtype).element_size()

        for batch_num_idx, batch_idx in enumerate(batches):
            batch_audios = [segment_audios[i] for i in batch_idx]
            batch_durations = [durations[i] for i in batch_idx]
            t0 = time.perf_counter()

            t_feat = time.perf_counter()
            inputs = processor(
                batch_audios, sampling_rate=16000, return_tensors="pt", padding=True,
            )
            input_values = inputs.input_values.to(device=device, dtype=dtype)
            attention_mask = inputs.get("attention_mask")
            if attention_mask is not None:
                attention_mask = attention_mask.to(device=device)
            feat_time = time.perf_counter() - t_feat

            t_infer = time.perf_counter()
            try:
                with torch.no_grad():
                    outputs = model(input_values, attention_mask=attention_mask)
                    logits = outputs.logits
                if device.type == "cuda":
                    try:
                        torch.cuda.synchronize()
                    except RuntimeError:
                        pass  # GPU may have been deallocated at lease boundary
            except Exception as e:
                raise ComponentError(
                    ErrorCode.INFERENCE_FAILED,
                    "ASR inference failed",
                    stage="recognition", component="recognition.w2v2_ctc",
                    internal_detail=f"batch {batch_num_idx + 1}: {type(e).__name__}: {e}",
                ) from e
            infer_time = time.perf_counter() - t_infer

            t_decode = time.perf_counter()
            predicted_ids = torch.argmax(logits, dim=-1)
            for j in range(predicted_ids.shape[0]):
                ids_list = predicted_ids[j].cpu().tolist()
                results[batch_idx[j]] = ids_to_phoneme_list(ids_list, tokenizer, pad_id)
            decode_time = time.perf_counter() - t_decode

            # measured output stride: real frames out vs padded samples in
            padded_samples = int(input_values.shape[-1])
            if frame_rate_hz is None and padded_samples > 0:
                frame_rate_hz = float(logits.shape[1]) * 16000.0 / padded_samples

            if keep_posteriors:
                probs = torch.softmax(logits.float(), dim=-1).cpu()
                frame_lens = _output_frame_lengths(
                    model, [len(segment_audios[i]) for i in batch_idx], logits.shape[1])
                for j in range(probs.shape[0]):
                    n = min(int(frame_lens[j]), probs.shape[1])
                    posteriors[batch_idx[j]] = probs[j, :n].numpy()
                del probs

            del input_values, attention_mask, outputs, logits, predicted_ids

            max_dur = max(batch_durations)
            seq_len = int(round(max_dur * MODEL_FRAMES_PER_SEC))
            qk_bytes_per_head = len(batch_audios) * seq_len * seq_len * dtype_bytes
            total_seconds = sum(batch_durations)
            batch_profiling.append({
                "batch_num": batch_num_idx + 1,
                "size": len(batch_audios),
                "time": round(time.perf_counter() - t0, 3),
                "feat_time": round(feat_time, 3),
                "infer_time": round(infer_time, 3),
                "decode_time": round(decode_time, 3),
                "min_dur": round(min(batch_durations), 3),
                "max_dur": round(max_dur, 3),
                "total_seconds": round(total_seconds, 3),
                "pad_waste": round(1.0 - total_seconds / (len(batch_durations) * max_dur), 4)
                             if max_dur > 0 else 0.0,
                "seq_len": seq_len,
                "qk_mb_per_head": round(qk_bytes_per_head / (1024 * 1024), 2),
                "qk_mb_all_heads": round(qk_bytes_per_head * num_heads / (1024 * 1024), 2),
            })

        return results, batch_profiling, frame_rate_hz, posteriors


def _output_frame_lengths(model, sample_lengths: list[int], fallback: int) -> list[int]:
    """True output frame count per unpadded input, via the model's own
    feature-extractor stride math; falls back to the padded length."""
    try:
        import torch

        lens = model._get_feat_extract_output_lengths(torch.tensor(sample_lengths))
        return [int(v) for v in lens.tolist()]
    except Exception:
        return [fallback] * len(sample_lengths)
