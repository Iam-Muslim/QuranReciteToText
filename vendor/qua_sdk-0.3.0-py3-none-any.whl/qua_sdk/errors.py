"""QAudioError taxonomy — one base, four layers, structured fields.

Layer mapping: Infra (GPU lease, Space down, quota), Component (model load/inference),
Input (bad audio, unresolvable ref), Composition (schema mismatch between stages,
unknown registry key). Exceptions at boundaries; expected in-stage branches
("VAD found no speech") are valid empty results, not errors.
"""

from __future__ import annotations

from enum import Enum


class ErrorCode(str, Enum):
    # infra
    GPU_QUOTA_EXHAUSTED = "gpu_quota_exhausted"
    REMOTE_UNAVAILABLE = "remote_unavailable"      # e.g. timing Space paused
    REMOTE_TIMEOUT = "remote_timeout"
    CANCELLED = "cancelled"                        # user/watchdog cancellation
    # component
    MODEL_LOAD_FAILED = "model_load_failed"
    INFERENCE_FAILED = "inference_failed"
    # input
    AUDIO_UNREADABLE = "audio_unreadable"
    REF_INVALID = "ref_invalid"
    ANCHOR_NOT_FOUND = "anchor_not_found"          # no n-gram match → can't locate chapter
    # composition
    UNKNOWN_REGISTRY_KEY = "unknown_registry_key"
    MISSING_DEPENDENCY = "missing_dependency"      # runtime needs an uninstalled extra
    SCHEMA_MISMATCH = "schema_mismatch"
    PROFILE_INVALID = "profile_invalid"
    INPUT_INVALID = "input_invalid"                # run() kwarg ≠ the task's declared input type
    PARAMS_MISMATCH = "params_mismatch"            # profile params type ≠ runtime's Params
    COMPONENT_MISMATCH = "component_mismatch"      # resolved object ≠ expected spec protocol


class QAudioError(Exception):
    """Base. ``user_message`` is safe to surface; ``internal_detail`` is for logs."""

    def __init__(
        self,
        code: ErrorCode,
        user_message: str,
        *,
        stage: str | None = None,
        component: str | None = None,
        retryable: bool = False,
        internal_detail: str | None = None,
    ):
        super().__init__(f"[{code.value}] {user_message}")
        self.code = code
        self.user_message = user_message
        self.stage = stage
        self.component = component
        self.retryable = retryable
        self.internal_detail = internal_detail


class InfraError(QAudioError):
    """Environment/runtime failures (GPU lease, remote Space, quota). Usually retryable.

    ``retry_after_s``: quota reset hint. ``retry_with_deploy``: same call can
    succeed under a different deploy config (e.g. quota exhausted → cpu).
    """

    def __init__(self, *args, retry_after_s: float | None = None,
                 retry_with_deploy: str | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.retry_after_s = retry_after_s
        self.retry_with_deploy = retry_with_deploy


class ComponentError(QAudioError):
    """A component failed internally (model load, inference crash)."""


class InputError(QAudioError):
    """Caller-supplied data is unusable (bad audio, invalid ref). Never retryable."""


class CompositionError(QAudioError):
    """Stages/registry/profile wired together incorrectly. A programming error."""
