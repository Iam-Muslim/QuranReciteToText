"""MfaRemoteSpace: word/letter timestamps via the hosted MFA Space.

Speaks the Space's Gradio HTTP surface directly (batch upload → align_batch
submit → SSE result stream) — no gradio dependency. Refs come from
``refs.build_ref`` per matched segment; region audio is sliced from
``Audio.samples``, converted to int16, and shipped as temp WAVs. Results join
back to segments by the echoed ref (the Space returns the ref it was sent);
per-segment failures become ``words=None``, batch-level failures raise.
``requests`` is imported call-local (the ``timing`` extra provides it).
"""

from __future__ import annotations

import json
import os
import tempfile
import wave
from typing import Callable, ClassVar

import numpy as np
from pydantic import ConfigDict, ValidationError

from qua_sdk.components.timing.refs import build_ref, word_line_indices
from qua_sdk.components.timing.runtimes.mfa_params import MfaParams
from qua_sdk.components.timing.spec import TimingBackend
from qua_sdk.errors import ComponentError, ErrorCode, InfraError, InputError
from qua_sdk.schemas import Alignment, Audio, Timings, WordTiming
from qua_sdk.schemas.base import SdkModel
from qua_sdk.schemas.timing import SegmentTiming

DEFAULT_SPACE_URL = "https://hetchyy-quran-phoneme-mfa-dev.hf.space"

_SPACE_PAUSED_MSG = (
    "MFA Space is not running (may be paused or restarting). Please try again in a minute."
)


class MfaLetterRow(SdkModel):
    """One letter row of the Space's align_batch payload. EXTERNAL wire format
    we don't control — ``extra="allow"`` lets unknown fields ride through."""

    model_config = ConfigDict(extra="allow")

    char: str
    start: float | None = None
    end: float | None = None


class MfaWordRow(SdkModel):
    """One word row of the Space's align_batch payload (external wire format,
    ``extra="allow"``). ``location`` is required — a row without it is a
    malformed response, not an empty-string word."""

    model_config = ConfigDict(extra="allow")

    location: str
    start: float | None = None
    end: float | None = None
    letters: list[MfaLetterRow] | None = None


class MfaRemoteSpace(TimingBackend):
    """Forced alignment on the remote MFA Space, one batch per call."""

    Params: ClassVar[type[MfaParams]] = MfaParams

    def __init__(self, space_url: str | None = None, hf_token: str | None = None):
        self.space_url = (space_url or os.environ.get("MFA_SPACE_URL") or DEFAULT_SPACE_URL).rstrip("/")
        self.hf_token = hf_token if hf_token is not None else os.environ.get("HF_TOKEN", "")
        self._index = None  # lazy QuranIndex, only needed for list-ref line attribution

    def timestamps(
        self,
        audio: Audio,
        alignment: Alignment,
        params: MfaParams,
        *,
        emissions=None,  # accepted per the seam contract; MFA re-aligns acoustically
        deploy=None,
        on_started: Callable[[], None] | None = None,
    ) -> Timings:
        plan = [
            (seg, build_ref(seg.matched_ref, seg.matched_text, seg.wrap_word_ranges)
                  if seg.matched_ref and seg.confidence > 0 else None)
            for seg in alignment.segments
        ]
        to_align = [(seg, ref) for seg, ref in plan if ref is not None]
        if not to_align:
            return Timings(
                granularity=params.granularity,
                segments=[SegmentTiming(segment_id=seg.id, words=None) for seg, _ in plan],
                riwayah=alignment.riwayah,
            )

        if audio.samples is None:
            raise InputError(
                ErrorCode.AUDIO_UNREADABLE,
                "MfaRemoteSpace needs decoded samples to slice segment audio",
                stage="timing", component="timing.mfa_remote",
            )

        sr = audio.sample_rate
        refs = [ref for _, ref in to_align]
        wav_paths = []
        try:
            for seg, _ in to_align:
                chunk = audio.samples[int(seg.region.start_s * sr):int(seg.region.end_s * sr)]
                chunk_i16 = np.clip(chunk * 32767, -32768, 32767).astype(np.int16)
                wav_paths.append(_write_temp_wav(chunk_i16, sr))

            event_id, headers = self._upload_and_submit(refs, wav_paths, params)
            results = self._wait_result(event_id, headers, params, on_started)
        finally:
            for p in wav_paths:
                try:
                    os.unlink(p)
                except OSError:
                    pass

        by_segment: dict[int, list[WordTiming] | None] = {}
        used: set[int] = set()
        for seg, ref in to_align:
            result = _find_result(results, ref, used)
            by_segment[seg.id] = self._build_words(result, ref) if result else None

        return Timings(
            granularity=params.granularity,
            segments=[SegmentTiming(segment_id=seg.id, words=by_segment.get(seg.id))
                      for seg, _ in plan],
            riwayah=alignment.riwayah,
        )

    # ------------------------------------------------------------- HTTP layer

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.hf_token}"} if self.hf_token else {}

    def _upload_and_submit(self, refs, audio_paths, params: MfaParams):
        """Upload the WAV batch, submit align_batch. Returns (event_id, headers)."""
        import requests

        headers = self._headers()
        base = self.space_url

        files_payload = []
        open_handles = []
        for path in audio_paths:
            fh = open(path, "rb")
            open_handles.append(fh)
            files_payload.append(("files", (os.path.basename(path), fh, "audio/wav")))
        try:
            resp = _http(lambda: requests.post(
                f"{base}/gradio_api/upload",
                headers=headers, files=files_payload, timeout=params.timeout_s,
            ), requests)
            if "application/json" not in resp.headers.get("content-type", ""):
                raise InfraError(
                    ErrorCode.REMOTE_UNAVAILABLE, _SPACE_PAUSED_MSG,
                    stage="timing", component="timing.mfa_remote", retryable=True,
                )
            uploaded_paths = resp.json()
        finally:
            for fh in open_handles:
                fh.close()

        file_data_list = [
            {"path": p, "meta": {"_type": "gradio.FileData"}} for p in uploaded_paths
        ]

        data = _align_batch_data(refs, file_data_list, params)

        submit_resp = _http(lambda: requests.post(
            f"{base}/gradio_api/call/align_batch",
            headers={**headers, "Content-Type": "application/json"},
            json={"data": data}, timeout=params.timeout_s,
        ), requests)
        if "application/json" not in submit_resp.headers.get("content-type", ""):
            raise InfraError(
                ErrorCode.REMOTE_UNAVAILABLE, _SPACE_PAUSED_MSG,
                stage="timing", component="timing.mfa_remote", retryable=True,
            )
        return submit_resp.json()["event_id"], headers

    def _wait_result(self, event_id, headers, params: MfaParams, on_started):
        """Stream SSE events until the final payload; fire on_started once.

        The Space's align_batch handler yields {"status": "started"} after
        acquiring its serialization lock, then the final result dict.
        """
        import requests

        sse_resp = _http(lambda: requests.get(
            f"{self.space_url}/gradio_api/call/align_batch/{event_id}",
            headers=headers, stream=True, timeout=params.timeout_s,
        ), requests)

        started_fired = False
        final_payload = None
        current_event = None

        try:
            for line in sse_resp.iter_lines(decode_unicode=True):
                if line and line.startswith("event: "):
                    current_event = line[7:]
                    continue
                if not (line and line.startswith("data: ")):
                    continue
                data_str = line[6:]

                if current_event == "error":
                    raise ComponentError(
                        ErrorCode.INFERENCE_FAILED,
                        "MFA align_batch failed on the Space",
                        stage="timing", component="timing.mfa_remote",
                        internal_detail=data_str.strip() or "null SSE error event",
                    )

                try:
                    parsed = json.loads(data_str)
                except ValueError:
                    continue
                unwrapped = parsed[0] if isinstance(parsed, list) and parsed else parsed
                if not isinstance(unwrapped, dict):
                    continue

                status = unwrapped.get("status")
                if status == "started" and not started_fired:
                    started_fired = True
                    if on_started is not None:
                        on_started()
                    continue
                if status in ("ok", "error"):
                    final_payload = unwrapped
                # don't break — let the SSE stream close cleanly
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError,
                requests.exceptions.ChunkedEncodingError) as e:
            raise InfraError(
                ErrorCode.REMOTE_TIMEOUT if isinstance(e, requests.exceptions.Timeout)
                else ErrorCode.REMOTE_UNAVAILABLE,
                "MFA Space connection dropped mid-stream",
                stage="timing", component="timing.mfa_remote", retryable=True,
                internal_detail=f"{type(e).__name__}: {e}",
            ) from e

        if final_payload is None:
            raise ComponentError(
                ErrorCode.INFERENCE_FAILED,
                "no final payload received from the MFA align_batch stream",
                stage="timing", component="timing.mfa_remote",
            )
        if final_payload.get("status") != "ok":
            raise ComponentError(
                ErrorCode.INFERENCE_FAILED,
                "MFA align_batch failed on the Space",
                stage="timing", component="timing.mfa_remote",
                internal_detail=str(final_payload),
            )
        return final_payload["results"]

    # ----------------------------------------------------------- result shape

    def _build_words(self, result: dict, ref) -> list[WordTiming] | None:
        """One result's words[] → WordTimings; line_idx attributed for list refs.

        Rows validate through ``MfaWordRow`` at this trust boundary — a
        malformed row (e.g. missing location) raises instead of silently
        degrading. Rows without start/end (unaligned words) are skipped.
        """
        words_raw = result.get("words") or []
        try:
            rows = [MfaWordRow.model_validate(w) for w in words_raw]
        except ValidationError as e:
            raise ComponentError(
                ErrorCode.INFERENCE_FAILED,
                "MFA Space returned a malformed word row",
                stage="timing", component="timing.mfa_remote",
                internal_detail=str(e),
            ) from e

        lines = None
        if isinstance(ref, list):
            lines = word_line_indices(ref, len(rows), self._quran_index())

        out: list[WordTiming] = []
        for i, row in enumerate(rows):
            if row.start is None or row.end is None:
                continue
            out.append(WordTiming(
                location=row.location,
                start_s=row.start,
                end_s=row.end,
                letters=[(lt.char, lt.start, lt.end)
                         for lt in row.letters] if row.letters else None,
                line_idx=lines[i] if lines is not None else None,
            ))
        return out or None

    def _quran_index(self):
        if self._index is None:
            from qua_sdk.domain import load_quran_index

            self._index = load_quran_index()
        return self._index


def _align_batch_data(refs: list, file_data_list: list, params: MfaParams) -> list:
    """The align_batch positional payload: [refs, files, method, beam,
    retry_beam, shared_cmvn, padding, word_boundary_allocation_json, model_id].

    ``None`` params serialize as empty strings — the Space applies its own
    env-configured defaults (the load-bearing wire contract); an empty
    ``model_id`` cedes to the Space's default model."""
    beam = "" if params.beam is None else str(params.beam)
    retry_beam = "" if params.retry_beam is None else str(params.retry_beam)
    shared_cmvn = "" if params.shared_cmvn is None else str(params.shared_cmvn).lower()
    wb_json = (
        "" if params.word_boundary_allocation is None
        else json.dumps(params.word_boundary_allocation)
    )
    return [refs, file_data_list, "", beam, retry_beam, shared_cmvn, params.padding, wb_json,
            params.model_id or ""]


def _find_result(results: list, ref, used: set[int]) -> dict | None:
    """First UNCONSUMED ok result whose echoed ref matches the one we sent.

    Consumption keeps duplicate refs distinct (two takes of the same Basmala
    must each get their own timings) while staying robust to result reordering.
    """
    for k, result in enumerate(results):
        if k not in used and result.get("ref") == ref and result.get("status") == "ok":
            used.add(k)
            return result
    return None


def _http(call, requests):
    """Run one requests call, mapping transport failures onto InfraError."""
    try:
        resp = call()
        resp.raise_for_status()
        return resp
    except requests.exceptions.Timeout as e:
        raise InfraError(
            ErrorCode.REMOTE_TIMEOUT, "MFA Space request timed out",
            stage="timing", component="timing.mfa_remote", retryable=True,
            internal_detail=str(e),
        ) from e
    except requests.exceptions.ConnectionError as e:
        raise InfraError(
            ErrorCode.REMOTE_UNAVAILABLE, _SPACE_PAUSED_MSG,
            stage="timing", component="timing.mfa_remote", retryable=True,
            internal_detail=str(e),
        ) from e
    except requests.exceptions.HTTPError as e:
        raise InfraError(
            ErrorCode.REMOTE_UNAVAILABLE, _SPACE_PAUSED_MSG,
            stage="timing", component="timing.mfa_remote", retryable=True,
            internal_detail=str(e),
        ) from e


def _write_temp_wav(audio_int16: np.ndarray, sample_rate: int) -> str:
    """Write one mono int16 WAV to a temp file; caller unlinks."""
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    tmp.close()  # reopen by name (Windows can't reopen an open NamedTemporaryFile)
    with wave.open(tmp.name, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(audio_int16.tobytes())
    return tmp.name
