"""Recognition: audio regions → symbol streams (was: phoneme ASR).

Contract: ``Recognizer.transcribe(Audio, Regions, RecognitionParams, deploy=...) -> Emissions``.
Model choice + revision affect results → profile; batching/dtype/compile → deploy.
Model aliases resolve through ``models.KNOWN_MODELS``.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from pydantic import model_validator

from qua_sdk.components.recognition.models import KNOWN_MODELS, ModelRef  # noqa: F401  (re-export)
from qua_sdk.schemas.base import SdkModel


class RecognitionParams(SdkModel):
    """Generic surface: every recognition method picks a model/revision and an
    emitted inventory; ``keep_frame_posteriors`` asks any frame-synchronous
    method to retain per-region frame posteriors on the Emissions."""

    model: str = "Base"             # open set: alias into KNOWN_MODELS or a raw HF repo id
    revision: str | None = None     # None → manifest pin; "stable" → movable pointer
    inventory_mode: str | None = None  # open set (see domain.inventory); None → from the model alias
    keep_frame_posteriors: bool = False  # retain per-region frame posteriors on Emissions

    @model_validator(mode="after")
    def _derive_mode(self):
        ref = KNOWN_MODELS.get(self.model)
        if self.inventory_mode is None:
            object.__setattr__(self, "inventory_mode", ref.inventory_mode if ref else "full")
        elif ref and self.inventory_mode != ref.inventory_mode:
            raise ValueError(
                f"model {self.model!r} emits {ref.inventory_mode!r} tokens, "
                f"profile says {self.inventory_mode!r}"
            )
        return self


@runtime_checkable
class Recognizer(Protocol):
    def transcribe(self, audio, regions, params: RecognitionParams, *, deploy=None): ...
