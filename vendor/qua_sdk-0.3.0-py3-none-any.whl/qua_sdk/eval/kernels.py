"""Metric KERNELS: value over a fixed input. Experiments/datasets live in qua-labs.

These consolidate the implementations duplicated across the training tracks
(levenshtein/PER from train-w2v-asr lib/metrics; boundary-F1 from ts-quality).
"""

from __future__ import annotations


def levenshtein(a: list[str], b: list[str]) -> int:
    """Token-level edit distance."""
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ai in enumerate(a, 1):
        cur = [i]
        for j, bj in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ai != bj)))
        prev = cur
    return prev[-1]


def per(hyps: list[list[str]], refs: list[list[str]]) -> float:
    """Corpus phoneme error rate: total edits / total ref tokens."""
    edits = sum(levenshtein(h, r) for h, r in zip(hyps, refs, strict=True))
    total = sum(len(r) for r in refs)
    return edits / total if total else 0.0


def boundary_f1(
    pred_s: list[float], true_s: list[float], tolerance_s: float = 0.05
) -> tuple[float, float, float]:
    """(precision, recall, f1) of boundary marks; greedy one-to-one within tolerance."""
    matched, used = 0, [False] * len(true_s)
    for p in pred_s:
        best, best_d = None, tolerance_s
        for i, t in enumerate(true_s):
            d = abs(p - t)
            if not used[i] and d <= best_d:
                best, best_d = i, d
        if best is not None:
            used[best] = True
            matched += 1
    precision = matched / len(pred_s) if pred_s else 0.0
    recall = matched / len(true_s) if true_s else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return precision, recall, f1


def timing_mae_ms(pred_s: list[float], true_s: list[float]) -> float:
    """Mean absolute timing error in ms over paired marks."""
    pairs = list(zip(pred_s, true_s, strict=True))
    if not pairs:
        return 0.0
    return sum(abs(p - t) for p, t in pairs) / len(pairs) * 1000.0
