"""Per-character cell + silent-flag + mapping access from the domain layer.

Thin wrappers over the pinned phonemizer's character/silent APIs, mirroring
``chapter_refs.get_phonemizer``'s lazy-singleton pattern so the heavy data load
(and the phonemizer import itself) only happens on first real use. The Timestamps
cell annotator (``components/timing/lib/cells.py``) is the sole consumer today.
"""

from __future__ import annotations

from qua_sdk.domain.chapter_refs import get_phonemizer


def cells_for_ref(ref: str):
    """``CharPhonemeResult`` for a ref — per-character (haraka/tanween) cells."""
    return get_phonemizer().phonemize(ref=ref).character_phoneme_mappings()


def silent_flags_for_ref(ref: str):
    """``[(char, silent, mark), ...]`` per written grapheme for a ref."""
    return get_phonemizer().phonemize(ref=ref).silent_flags()


def mapping_for_ref(ref: str):
    """The phonemizer's ``PhonemizationMapping`` (natural per-word attribution)."""
    return get_phonemizer().phonemize(ref=ref).get_mapping()
