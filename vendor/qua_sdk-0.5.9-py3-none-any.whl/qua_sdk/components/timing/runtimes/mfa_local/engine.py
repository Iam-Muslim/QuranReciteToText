"""KalpyEngine: persistent in-process MFA alignment via the kalpy API.

Loads the acoustic model + lexicon once (eliminating PretrainedAligner's ~9s
per-call setup) and hands out cached per-beam aligners. Two engine-wide
caches/counters thread through every aligner:

- FST graph cache: graph compilation is deterministic in (lexicon,
  transcript) and the Quran has a finite ref set, so hit rate climbs to
  ~100%. Viterbi search MUTATES the FST, so retrievals hand out ``.Copy()``
  — sharing the cached object naively drifts word timings.
- Retry counter: patches kalpy's align functions to count alignments that
  hit retry_beam (the C++ binding's ``retried`` flag), for beam tuning.

kalpy/montreal_forced_aligner import call-local only — this module must
import on machines without the conda MFA stack.
"""

from __future__ import annotations

import logging
import threading
from pathlib import Path

logger = logging.getLogger(__name__)

DEFAULT_BEAM = 10
DEFAULT_RETRY_BEAM = 35


def strip_position_tag(phone: str) -> str:
    """Remove Kaldi position tags (_B, _E, _I, _S) from phone labels."""
    if phone and len(phone) > 2 and phone[-2] == "_" and phone[-1] in "BEIS":
        return phone[:-2]
    return phone


class KalpyEngine:
    """Persistent MFA alignment engine using kalpy directly."""

    def __init__(self, acoustic_model_path, dictionary_path, *, fst_cache: bool = True):
        from kalpy.feat.cmvn import CmvnComputer
        from kalpy.fstext.lexicon import LexiconCompiler
        from montreal_forced_aligner.dictionary.mixins import (
            DEFAULT_BRACKETS,
            DEFAULT_CLITIC_MARKERS,
            DEFAULT_COMPOUND_MARKERS,
            DEFAULT_PUNCTUATION,
            DEFAULT_WORD_BREAK_MARKERS,
        )
        from montreal_forced_aligner.models import AcousticModel
        from montreal_forced_aligner.tokenization.simple import SimpleTokenizer

        # 1. Load acoustic model (has .mfcc_computer, .parameters)
        self.acoustic_model = AcousticModel(str(acoustic_model_path))
        p = self.acoustic_model.parameters

        # keep_q is a property of THE MODEL: if its phone inventory has the
        # qalqala phone Q, the lexicon + recovery must keep Q (else its Q states
        # go unused). The model is the ground truth — a Q model can't be run
        # Q-off (lib/transforms). Derived here, read by MfaLocalAligner.
        self.keep_q = "Q" in {strip_position_tag(str(ph))
                              for ph in p.get("non_silence_phones", ())}

        # psil is the model's dedicated boundary-silence phone (the SILENCE
        # recipe seeds it at verse-start / inter-segment / verse-end). Its
        # presence in the inventory means the model learned to place real
        # pauses on psil, so a whole-verse caller can seed it to recover true
        # boundary silence. A capability (not a mode): the per-segment paths
        # never seed it. Model-derived here (mirror of keep_q), read by
        # MfaLocalAligner.
        self.supports_psil = "psil" in {strip_position_tag(str(ph))
                                        for ph in p.get("non_silence_phones", ())}

        # 2. Build lexicon compiler with model params
        self.lexicon_compiler = LexiconCompiler(
            disambiguation=False,
            silence_probability=p["silence_probability"],
            initial_silence_probability=p["initial_silence_probability"],
            final_silence_correction=p["final_silence_correction"],
            final_non_silence_correction=p["final_non_silence_correction"],
            silence_phone=p["optional_silence_phone"],
            oov_phone=p["oov_phone"],
            position_dependent_phones=p["position_dependent_phones"],
            phones=p["non_silence_phones"],
            ignore_case=True,
        )
        self.lexicon_compiler.load_pronunciations(str(dictionary_path))

        # 3. Build tokenizer (matches align_one defaults)
        self.tokenizer = SimpleTokenizer(
            word_table=self.lexicon_compiler.word_table,
            word_break_markers=DEFAULT_WORD_BREAK_MARKERS,
            punctuation=DEFAULT_PUNCTUATION,
            clitic_markers=DEFAULT_CLITIC_MARKERS,
            compound_markers=DEFAULT_COMPOUND_MARKERS,
            brackets=DEFAULT_BRACKETS,
            ignore_case=True,
        )

        # 4. Reusable aligners, cached by beam params
        self._default_beam = DEFAULT_BEAM
        self._default_retry_beam = DEFAULT_RETRY_BEAM
        self._aligner_cache = {}

        # 5. Shared FST graph cache (keyed on tokenized transcript)
        self._fst_cache = {}
        self._fst_cache_lock = threading.Lock()
        self._fst_cache_hits = 0
        self._fst_cache_misses = 0
        self._fst_cache_enabled = fst_cache

        # 5b. Retry counter
        self._retry_count = 0
        self._total_align_count = 0
        self._retry_lock = threading.Lock()
        self._install_retry_counter()

        self.kalpy_aligner = self._get_aligner(self._default_beam, self._default_retry_beam)

        # 6. CMVN computer (stateless)
        self.cmvn_computer = CmvnComputer()

    def _get_aligner(self, beam: int, retry_beam: int):
        """Get or create a KalpyAligner for given beam parameters."""
        from kalpy.aligner import KalpyAligner

        key = (beam, retry_beam)
        if key not in self._aligner_cache:
            ka = KalpyAligner(
                self.acoustic_model, self.lexicon_compiler,
                beam=beam, retry_beam=retry_beam,
            )
            if self._fst_cache_enabled:
                self._install_graph_cache_on(ka)
            self._aligner_cache[key] = ka
        return self._aligner_cache[key]

    def _install_graph_cache_on(self, kalpy_aligner):
        """Wrap graph_compiler.compile_fst with the shared FST cache.

        Tokenized transcripts are int sequences from Kaldi's word table —
        small and hashable. ``align_utterance(fst, feats)`` mutates the FST
        during Viterbi search, so callers get a fresh ``.Copy()`` on every
        retrieval; the master copy stays pristine in the cache.
        """
        gc = kalpy_aligner.graph_compiler
        if getattr(gc, "_fst_cache_installed", False):
            return
        orig = gc.compile_fst
        fst_cache = self._fst_cache
        lock = self._fst_cache_lock
        engine = self

        def cached_compile_fst(transcript):
            try:
                key = tuple(transcript) if not isinstance(transcript, str) else transcript
            except TypeError:
                return orig(transcript)
            with lock:
                cached = fst_cache.get(key)
                if cached is not None:
                    engine._fst_cache_hits += 1
                    # Fresh copy — caller can mutate without poisoning the cache.
                    return cached.Copy() if hasattr(cached, "Copy") else cached
            fst = orig(transcript)
            # Stash a pristine copy; hand the original to the caller (they own it).
            try:
                pristine = fst.Copy() if hasattr(fst, "Copy") else fst
            except Exception:
                pristine = fst
            with lock:
                fst_cache[key] = pristine
                engine._fst_cache_misses += 1
            return fst

        gc.compile_fst = cached_compile_fst
        gc._fst_cache_installed = True

    def _install_retry_counter(self):
        """Patch kalpy's align functions to count alignments that hit retry_beam.

        kalpy logs ``Retried {utterance_id}`` only at DEBUG and only when
        utterance_id is set (we don't pass it). The C++ binding returns a
        ``retried`` flag in its tuple; wrap the Python-side import to read it.
        """
        try:
            from kalpy.gmm import align as kalpy_align_mod
        except Exception as e:
            logger.warning("retry counter: cannot import kalpy.gmm.align: %s", e)
            return
        if getattr(kalpy_align_mod, "_retry_counter_installed", False):
            return
        engine = self
        for fn_name in ("gmm_align_compiled", "gmm_align_reference_phones"):
            orig = getattr(kalpy_align_mod, fn_name, None)
            if orig is None:
                continue

            def _make_wrapper(orig_fn):
                def counting_align(*args, **kwargs):
                    result = orig_fn(*args, **kwargs)
                    # kalpy returns: (alignment, words, like, per_frame_ll, successful, retried)
                    try:
                        retried = bool(result[5]) if len(result) >= 6 else False
                        successful = bool(result[4]) if len(result) >= 5 else False
                    except Exception:
                        retried, successful = False, False
                    with engine._retry_lock:
                        engine._total_align_count += 1
                        if successful and retried:
                            engine._retry_count += 1
                    return result

                return counting_align

            setattr(kalpy_align_mod, fn_name, _make_wrapper(orig))
        kalpy_align_mod._retry_counter_installed = True

    def reset_retry_counter(self):
        with self._retry_lock:
            self._retry_count = 0
            self._total_align_count = 0

    def get_retry_stats(self):
        with self._retry_lock:
            return self._retry_count, self._total_align_count

    def _build_utterance(self, wav_path, lab_content):
        """Audio + transcript → a KalpyUtterance with MFCCs generated."""
        from kalpy.utterance import Segment, Utterance as KalpyUtterance
        from montreal_forced_aligner.corpus.classes import FileData
        from montreal_forced_aligner.online.alignment import tokenize_utterance_text

        file = FileData.parse_file(Path(wav_path).stem, str(wav_path), None, "", 0)
        seg = Segment(str(wav_path), 0, file.wav_info.duration, 0)
        normalized = tokenize_utterance_text(
            lab_content, self.lexicon_compiler, self.tokenizer,
            language=self.acoustic_model.language,
        )
        utt = KalpyUtterance(seg, normalized)
        utt.generate_mfccs(self.acoustic_model.mfcc_computer)
        return utt

    def align(self, wav_path, lab_content, beam=None, retry_beam=None):
        """Align a single WAV file with its phoneme string.
        Returns list[dict] of phone intervals [{start, end, phone}]."""
        _beam = beam if beam is not None else self._default_beam
        _retry_beam = retry_beam if retry_beam is not None else self._default_retry_beam
        aligner = self._get_aligner(_beam, _retry_beam)

        utt = self._build_utterance(wav_path, lab_content)
        cmvn = self.cmvn_computer.compute_cmvn_from_features([utt.mfccs])
        utt.apply_cmvn(cmvn)

        ctm = aligner.align_utterance(utt)
        return self._ctm_to_intervals(ctm)

    def _resolve_phone(self, symbol_id):
        """Resolve phone integer ID to its name via phone_table, strip position tag."""
        phone_table = self.lexicon_compiler.phone_table
        if phone_table is not None and isinstance(symbol_id, int):
            name = phone_table.find(symbol_id)
            if name:
                return strip_position_tag(name)
        return strip_position_tag(str(symbol_id))

    def _ctm_to_intervals(self, ctm):
        """Convert HierarchicalCtm to phone interval dicts (4dp)."""
        intervals = []
        for word_iv in ctm.word_intervals:
            for phone in word_iv.phones:
                intervals.append({
                    "start": round(float(phone.begin), 4),
                    "end": round(float(phone.end), 4),
                    "phone": self._resolve_phone(phone.symbol),
                })
        return intervals

    def align_batch(self, segments, beam=None, retry_beam=None, shared_cmvn=False):
        """Align N (wav_path, lab_content) pairs serially.

        shared_cmvn=True computes one CMVN over the whole batch (0-row
        utterances are excluded from the stats and yield empty results);
        False computes per-utterance CMVN. Per-utterance alignment failures
        soft-degrade to empty interval lists.
        """
        _beam = beam if beam is not None else self._default_beam
        _retry_beam = retry_beam if retry_beam is not None else self._default_retry_beam
        aligner = self._get_aligner(_beam, _retry_beam)

        utterances = [self._build_utterance(wav, lab) for wav, lab in segments]

        if shared_cmvn:
            valid_feats = [u.mfccs for u in utterances if u.mfccs.NumRows() > 0]
            cmvn = self.cmvn_computer.compute_cmvn_from_features(
                valid_feats if valid_feats else [u.mfccs for u in utterances]
            )
            all_results = []
            for utt in utterances:
                if utt.mfccs.NumRows() == 0:
                    all_results.append([])
                    continue
                utt.apply_cmvn(cmvn)
                try:
                    ctm = aligner.align_utterance(utt)
                    all_results.append(self._ctm_to_intervals(ctm))
                except Exception as e:
                    logger.warning("align_batch: utterance alignment failed: %s", e)
                    all_results.append([])
        else:
            all_results = []
            for utt in utterances:
                if utt.mfccs.NumRows() == 0:
                    all_results.append([])
                    continue
                cmvn = self.cmvn_computer.compute_cmvn_from_features([utt.mfccs])
                utt.apply_cmvn(cmvn)
                try:
                    ctm = aligner.align_utterance(utt)
                    all_results.append(self._ctm_to_intervals(ctm))
                except Exception as e:
                    logger.warning("align_batch: utterance alignment failed: %s", e)
                    all_results.append([])

        return all_results

    def create_thread_aligner(self, beam: int, retry_beam: int):
        """Build a fresh KalpyAligner for a single thread.

        KalpyAligner wraps a Kaldi C++ decoder with per-call internal state,
        so the cached singleton in ``_aligner_cache`` is unsafe to share
        across threads. The acoustic model + lexicon compiler are read-only
        after load, so new aligners are cheap (no model reload). The shared
        FST cache is wired in so threaded batches get cache hits too.
        """
        from kalpy.aligner import KalpyAligner

        ka = KalpyAligner(
            self.acoustic_model, self.lexicon_compiler,
            beam=beam, retry_beam=retry_beam,
        )
        if self._fst_cache_enabled:
            self._install_graph_cache_on(ka)
        return ka

    def align_with(self, aligner, wav_path, lab_content):
        """Align using a caller-provided aligner instance (per-thread use)."""
        utt = self._build_utterance(wav_path, lab_content)
        cmvn = self.cmvn_computer.compute_cmvn_from_features([utt.mfccs])
        utt.apply_cmvn(cmvn)

        ctm = aligner.align_utterance(utt)
        return self._ctm_to_intervals(ctm)
