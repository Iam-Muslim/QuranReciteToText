"""Segmentation: find speech regions/boundaries in audio (was: VAD).

Contract: ``Segmenter.segment(Audio, SegmentationParams, deploy=...) -> Regions``.
The seam (Audio → Regions) is method-agnostic: today's runtime is a w2v2-bert
recitation segmenter, but an energy-based detector, a streaming detector, or a
diarizer are NEW RUNTIME KEYS (+ a SegmentationParams subclass if they need
different knobs) — never a new component or a seam change. Plug points:
detector family (runtime key) · cleaning strategy (a method param).
Empty Regions is a valid result (silence-only audio), not an error. Runtimes
should populate ``Regions.raw`` (pre-cleaning intervals) so re-cleaning with
new params needs no second model pass; ``clean`` re-derives Regions from raw.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from qua_sdk.schemas import Audio, Regions
from qua_sdk.schemas.base import SdkModel


class SegmentationParams(SdkModel):
    """Marker base for method param subclasses.

    No genuinely method-agnostic segmentation knobs exist today — every knob
    (cleaning strategy, silence/speech thresholds, padding) belongs to a
    detection method, so methods subclass (e.g. ``RecitationSegmenterParams``).
    """


@runtime_checkable
class Segmenter(Protocol):
    def segment(self, audio: Audio, params: SegmentationParams, *, deploy=None) -> Regions: ...

    def clean(self, raw: Regions, params: SegmentationParams) -> Regions:
        """Re-clean cached raw intervals (no model pass) — the resegment loop.

        Interval detectors re-derive Regions from ``raw``; a non-interval
        detector reads back whatever it stored in ``Regions.detector_state``.
        """
        ...
