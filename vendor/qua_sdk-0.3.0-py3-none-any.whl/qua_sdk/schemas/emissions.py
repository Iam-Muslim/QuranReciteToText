"""Emissions: per-region symbol streams (recognition output).

Today: CTC-collapsed phoneme tokens per region (e.g. ["b", "ɪ", "s", "m"]).
The inventory mode travels with the data — matching must consume the same
inventory the recognizer emitted ("full" = 72 tokens, "simple" = 38).
``frame_rate_hz`` is the model's measured output frame rate; with
``RecognitionParams.keep_frame_posteriors`` the per-region frames×vocab
posterior arrays ride along too (excluded from serialization) — the inputs a
frame-synchronous timing backend (CTC-seg) needs.
"""

from __future__ import annotations

import numpy as np
from pydantic import ConfigDict, Field

from qua_sdk.schemas.base import SdkModel


class Emissions(SdkModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    tokens: list[list[str]]      # one token list per region, same order as Regions
    inventory_mode: str = "full"  # open set, see domain.inventory
    frame_rate_hz: float | None = None  # model output frames per second of audio
    # per-region numpy arrays (frames×vocab), populated by keep_frame_posteriors
    frame_posteriors: list | None = Field(None, exclude=True, repr=False)

    def __len__(self) -> int:
        return len(self.tokens)

    def __eq__(self, other) -> bool:
        if not isinstance(other, Emissions):
            return False
        if (self.tokens, self.inventory_mode, self.frame_rate_hz) != (
                other.tokens, other.inventory_mode, other.frame_rate_hz):
            return False
        a, b = self.frame_posteriors, other.frame_posteriors
        if a is None or b is None:
            return a is b
        return len(a) == len(b) and all(np.array_equal(x, y) for x, y in zip(a, b))

    __hash__ = object.__hash__
