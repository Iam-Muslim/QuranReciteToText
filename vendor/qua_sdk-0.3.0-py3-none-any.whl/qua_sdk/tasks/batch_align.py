"""Task declaration: batch_align — audio in, aligned (optionally timed) segments out.

One task → many pipeline impls; the decl names the contract, ``run()``
enforces it at the boundary.
"""

from __future__ import annotations

from qua_sdk.registry import register
from qua_sdk.tasks.decl import TaskDecl

register(
    "task.batch_align@v1",
    TaskDecl(
        name="batch_align",
        inputs={"audio": "qua_sdk.schemas.Audio"},
        profile_schema="qua_sdk.profiles.batch_align.BatchAlignProfile",
        output_schema="qua_sdk.schemas.results.BatchAlignResult",
        default_pipeline="pipeline.batch_align.default@v1",
    ),
)
