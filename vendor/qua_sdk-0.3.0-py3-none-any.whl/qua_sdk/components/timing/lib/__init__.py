"""Timing lib: pure ref-preparation + interval-recovery logic.

The alignment-free half of the MFA pipeline, lifted from the MFA Space:
``prepare_ref`` (ref → PreparedRef with lab content), the recovery chain in
``recover_words`` (intervals → word/letter rows), and their building blocks
(transforms, words, letters, word_boundary, specials). Everything here is
runtime-agnostic — no MFA, no audio, no env vars.
"""

from qua_sdk.components.timing.lib.prepare import (
    PreparedRef,
    phonemize_ref,
    prepare_ref,
    prepare_ref_sequence,
)
from qua_sdk.components.timing.lib.recover import flat_entries_for, recover_words
from qua_sdk.components.timing.lib.transforms import (
    keep_q_context,
    keep_q_enabled,
    normalize_phonemes,
    set_keep_q,
    transform_phonemes,
)
from qua_sdk.components.timing.lib.word_boundary import (
    WB_ALLOC_RULES,
    WB_ALLOC_VALUES,
    WB_RULE_DEFAULTS,
    WbChoice,
    apply_word_boundary_allocation,
    detect_cross_word_idgham,
    resolve_word_boundary_allocation,
)
from qua_sdk.components.timing.lib.words import (
    SILENCE_PHONES,
    build_reverse_mapped_intervals,
    build_words_from_mapping,
    is_active_phone,
    nest_phones_in_words,
    pad_intervals,
    serializable_intervals,
)

__all__ = [
    "PreparedRef", "phonemize_ref", "prepare_ref", "prepare_ref_sequence",
    "flat_entries_for", "recover_words",
    "normalize_phonemes", "transform_phonemes",
    "keep_q_context", "keep_q_enabled", "set_keep_q",
    "WB_ALLOC_RULES", "WB_ALLOC_VALUES", "WB_RULE_DEFAULTS", "WbChoice",
    "apply_word_boundary_allocation", "detect_cross_word_idgham", "resolve_word_boundary_allocation",
    "SILENCE_PHONES", "is_active_phone",
    "build_words_from_mapping", "build_reverse_mapped_intervals",
    "pad_intervals", "nest_phones_in_words", "serializable_intervals",
]
