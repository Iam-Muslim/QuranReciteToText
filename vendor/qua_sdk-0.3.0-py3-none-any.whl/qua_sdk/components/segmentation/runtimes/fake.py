"""Deterministic fake segmenter — powers the conformance harness without ML deps."""

from __future__ import annotations

from typing import ClassVar

from qua_sdk.components.segmentation.spec import SegmentationParams, Segmenter
from qua_sdk.errors import ErrorCode, InputError
from qua_sdk.observe import record_metrics
from qua_sdk.schemas import Audio, Region, Regions

SPEECH_S = 0.75
GAP_S = 0.2


class FakeSegmenter(Segmenter):
    """Tiles the audio into fixed regions: ``SPEECH_S`` of speech separated by
    ``GAP_S`` of silence. Pure function of duration — a fake needs no knobs."""

    Params: ClassVar[type[SegmentationParams]] = SegmentationParams

    def segment(self, audio: Audio, params: SegmentationParams, *, deploy=None) -> Regions:
        if audio.samples is None:
            raise InputError(ErrorCode.AUDIO_UNREADABLE, "FakeSegmenter needs decoded samples")
        duration = audio.duration_s or 0.0
        regions, t = [], 0.0
        while t + SPEECH_S <= duration:
            regions.append(Region(start_s=t, end_s=t + SPEECH_S))
            t += SPEECH_S + GAP_S
        record_metrics(regions_found=len(regions))
        return Regions(regions=regions, is_complete=True, raw=list(regions), audio_duration_s=duration)

    def clean(self, raw: Regions, params: SegmentationParams) -> Regions:
        return Regions(regions=list(raw.raw or raw.regions), is_complete=raw.is_complete,
                       raw=raw.raw, audio_duration_s=raw.audio_duration_s)
