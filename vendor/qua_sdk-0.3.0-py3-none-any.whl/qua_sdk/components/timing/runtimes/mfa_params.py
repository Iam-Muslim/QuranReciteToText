"""Method params for the MFA timing backends (remote Space + local runtime).

Import-light by design: profiles import this module directly, so it must not
pull heavy deps (the runtimes keep heavy imports call-local).
"""

from __future__ import annotations

from typing import Literal

from qua_sdk.components.timing.spec import TimingParams


class MfaParams(TimingParams):
    """Real knobs from today's MFA paths: probe runs beam=2, auto-split beam=50.

    The ``None`` defaults are the load-bearing wire contract: a ``None`` field
    sends an empty string, ceding control to the MFA Space's env config
    (``MFA_BEAM`` / ``MFA_RETRY_BEAM`` / ``MFA_FORCE_SHARED_CMVN`` /
    ``MFA_ALLOC_<RULE>``). Set a value to override per-call — explicit values
    win over the Space defaults.
    """

    model_id: str | None = None  # select the acoustic model by catalog id (None = default)
    beam: int | None = None
    retry_beam: int | None = None
    shared_cmvn: bool | None = None  # batch-level CMVN stats instead of per-utterance
    padding: Literal["forward", "symmetric", "none"] = "symmetric"  # gap attribution
    word_boundary_allocation: dict[str, Literal["asis", "first", "second"]] | None = None
