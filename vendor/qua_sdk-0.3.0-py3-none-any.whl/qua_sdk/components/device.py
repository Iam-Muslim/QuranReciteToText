"""Shared deploy → torch (device, dtype) resolution for the eager runtimes.

Deploy configs are duck-typed here (components never import qua_sdk.deploy):
only ``.device`` and ``.dtype`` are read. torch imports stay call-local.
"""

from __future__ import annotations


def resolve_device_dtype(deploy):
    """Target (device, dtype) from a deploy config; None → auto.

    A cuda deploy on a cuda-less host falls back to cpu/float32 — deploy never
    changes result content, only where it runs.
    """
    import torch

    dtypes = {"float16": torch.float16, "bfloat16": torch.bfloat16,
              "bf16": torch.bfloat16, "float32": torch.float32}
    if deploy is None:
        if torch.cuda.is_available():
            return torch.device("cuda"), torch.float16
        return torch.device("cpu"), torch.float32
    device = torch.device(deploy.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        return torch.device("cpu"), torch.float32
    return device, dtypes.get(deploy.dtype, torch.float32)
