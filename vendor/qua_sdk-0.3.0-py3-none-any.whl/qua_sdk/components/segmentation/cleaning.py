"""Interval cleaning: raw detector intervals → final speech regions.

Two strategies, selected by ``RecitationSegmenterParams.cleaning``:

- ``segmenter_native`` defers entirely to recitations_segmenter's
  ``clean_speech_intervals`` (min-silence merge, min-speech filter, one
  symmetric pad).
- ``padded_floor`` runs the same upstream cleaner with zero pad, then applies
  ``_pad_capped`` — the offline extraction pipeline's asymmetric padder that
  respects neighbour boundaries, audio length, and a minimum-daylight floor.

Raw intervals travel in SECONDS at the schema boundary; the upstream cleaner
wants SAMPLES — the conversion (and numpy/torch coercion) is internal. Raw
sample indices survive the /16k float round-trip exactly.
"""

from __future__ import annotations

from typing import Sequence

from qua_sdk.components.segmentation.runtimes.recitation_params import RecitationSegmenterParams
from qua_sdk.schemas.audio import TARGET_SAMPLE_RATE

Interval = tuple[float, float]


def clean_native(
    raw_intervals: Sequence[Interval],
    is_complete: bool,
    params: RecitationSegmenterParams,
) -> list[Interval]:
    """Upstream cleaning with a single symmetric pad (``pad_left_ms``).

    The spec validator guarantees ``pad_left_ms == pad_right_ms`` for this
    strategy. Intervals in/out are seconds.
    """
    cleaned = _clean_upstream(raw_intervals, is_complete, params, pad_duration_ms=params.pad_left_ms)
    return cleaned


def clean_padded_floor(
    raw_intervals: Sequence[Interval],
    is_complete: bool,
    params: RecitationSegmenterParams,
    audio_duration_s: float,
) -> list[Interval]:
    """Upstream cleaning with zero pad, then the capped asymmetric padder."""
    cleaned = _clean_upstream(raw_intervals, is_complete, params, pad_duration_ms=0)
    return _pad_capped(
        cleaned,
        params.pad_left_ms / 1000.0,
        params.pad_right_ms / 1000.0,
        params.min_silence_floor_ms / 1000.0,
        audio_duration_s,
    )


def _clean_upstream(
    raw_intervals: Sequence[Interval],
    is_complete: bool,
    params: RecitationSegmenterParams,
    *,
    pad_duration_ms: int,
) -> list[Interval]:
    """Run recitations_segmenter's cleaner on seconds-intervals (samples inside)."""
    if len(raw_intervals) == 0:
        return []
    import torch
    from recitations_segmenter import clean_speech_intervals

    samples = torch.tensor(
        [[round(s * TARGET_SAMPLE_RATE), round(e * TARGET_SAMPLE_RATE)] for s, e in raw_intervals],
        dtype=torch.long,
    )
    out = clean_speech_intervals(
        samples,
        is_complete,
        min_silence_duration_ms=params.min_silence_ms,
        min_speech_duration_ms=params.min_speech_ms,
        pad_duration_ms=pad_duration_ms,
        return_seconds=True,
    )
    return [(float(s), float(e)) for s, e in out.clean_speech_intervals.tolist()]


def _pad_capped(
    intervals: list[Interval],
    pad_left_s: float,
    pad_right_s: float,
    floor_s: float,
    audio_len_s: float,
) -> list[Interval]:
    """Asymmetrically pad intervals while respecting neighbour boundaries
    and a daylight floor.

    For each *internal* gap, the available budget (``raw_gap - floor_s``)
    is split between the two adjacent segments by the
    ``pad_right_s : pad_left_s`` ratio. End boundaries (start of audio,
    end of audio) get the full requested pad clamped against the audio
    length. This guarantees the post-pad gap between any two adjacent
    segments is exactly ``max(floor_s, raw_gap - pad_left_s - pad_right_s)``
    when ``raw_gap >= floor_s``, or the unchanged ``raw_gap`` otherwise.
    """
    n = len(intervals)
    if n == 0:
        return []

    # Per-seg per-side pad allocations. Endpoints (left of first, right
    # of last) get full requested pad; internal gaps get proportional
    # split after reserving ``floor_s``.
    left_pad = [0.0] * n
    right_pad = [0.0] * n
    left_pad[0] = pad_left_s
    right_pad[-1] = pad_right_s
    want = pad_left_s + pad_right_s

    for i in range(n - 1):
        gap = max(0.0, intervals[i + 1][0] - intervals[i][1])
        budget = max(0.0, gap - floor_s)
        if want == 0.0:
            continue
        if budget >= want:
            right_pad[i] = pad_right_s
            left_pad[i + 1] = pad_left_s
        else:
            right_pad[i] = budget * pad_right_s / want
            left_pad[i + 1] = budget * pad_left_s / want

    out: list[Interval] = []
    for i, (s, e) in enumerate(intervals):
        new_s = max(0.0, s - left_pad[i])
        new_e = min(audio_len_s, e + right_pad[i])
        out.append((new_s, new_e))
    return out
