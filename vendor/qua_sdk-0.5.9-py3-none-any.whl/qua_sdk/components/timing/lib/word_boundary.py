"""Cross-word idgham detection + boundary-phone allocation.

When two words assimilate across a boundary, the merged phone(s) physically
span it; the phonemizer raw-attributes them to the SECOND word. The 8-rule
registry here lets callers reattribute per rule: "first" moves the transformed
boundary phones (geminate pairs atomically) onto word 1, "second"/"asis" keep
the phonemizer's attribution. Only word-level rows change — letters, raw
intervals, and per-word phones are untouched.

Pure module: env-var fallbacks are an INJECTED ``defaults`` dict (the Space
layer reads ``MFA_ALLOC_<RULE>`` and passes them in).
"""

from __future__ import annotations

import json
from functools import lru_cache
from typing import Literal, Mapping

from qua_sdk.components.timing.lib.words import is_active_phone

WbChoice = Literal["asis", "first", "second"]

# Configurable rules. mutajanisayn _kamil and _naqis collapse to one bucket
# because the allocation question is identical (the merged phone(s) sit at
# the boundary).
WB_ALLOC_RULES = (
    "idgham_ghunnah_noon",
    "idgham_bila_ghunnah_noon",
    "idgham_ghunnah_tanween",
    "idgham_bila_ghunnah_tanween",
    "idgham_shafawi",
    "idgham_mutamathilayn",
    "idgham_mutaqaribayn",
    "idgham_mutajanisayn",
)
WB_ALLOC_VALUES = ("asis", "first", "second")

# The 6 Arabic vowels (short + madd). A "first" allocation relocates the merged
# boundary CONSONANT; when the second word's leading phone is one of these, the
# consonant was already assimilated onto the first word and only the orphaned
# vowel remains — it must NOT be moved (see apply_word_boundary_allocation).
_VOWEL_PHONES = frozenset({"a", "i", "u", "aː", "iː", "uː"})

# Per-rule system defaults — applied when neither the API param nor the
# injected defaults set a value; rules omitted here fall through to the
# "first" baseline.
WB_RULE_DEFAULTS: dict[str, WbChoice] = {
    "idgham_ghunnah_noon": "first",
    "idgham_bila_ghunnah_noon": "second",   # نْ + ل/ر — keep merge phone in word 2
    "idgham_ghunnah_tanween": "first",
    "idgham_bila_ghunnah_tanween": "second",  # tanween + ل/ر — geminate to word 2
    "idgham_shafawi": "first",
    "idgham_mutamathilayn": "first",
    "idgham_mutaqaribayn": "second",        # ل + ر — fully-merged geminate to word 2
    "idgham_mutajanisayn": "second",        # د+ت / ت+ط / ذ+ظ / ث+ذ / ت+د / ب+م — geminate to word 2
}

# Phonemizer tajweed rule name → canonical allocation rule. The bridge rule names
# come from the phonemizer's classification (the single owner — see
# ``BRIDGE_RULE_VALUES``); only mutajanisayn collapses (_kamil/_naqis share one
# allocation bucket because the allocation question is identical). Built lazily so
# importing this module never pulls the heavy, optional phonemizer (the SDK's
# "works without the phonemizer" contract, enforced by ci.yml's honesty leg).
@lru_cache(maxsize=1)
def _wb_tajweed_to_rule() -> dict[str, str]:
    from quranic_phonemizer import BRIDGE_RULE_VALUES

    mapping = {
        **{r: r for r in BRIDGE_RULE_VALUES if r != "idgham_mutajanisayn_kamil"},
        "idgham_mutajanisayn_kamil": "idgham_mutajanisayn",
        "idgham_mutajanisayn_naqis": "idgham_mutajanisayn",
    }
    # Drift guards: every phonemizer bridge rule must be handled, and the
    # (ordered, policy-owned) allocation namespace must match the mapped rules.
    assert BRIDGE_RULE_VALUES <= set(mapping), "phonemizer bridge rule unmapped"
    assert set(WB_ALLOC_RULES) == set(mapping.values()), "WB_ALLOC_RULES out of sync"
    return mapping


def detect_cross_word_idgham(tajweed_mapping, words: list) -> list[dict]:
    """Identify cross-word idgham instances among adjacent word pairs.

    A boundary fires when any entry of word_N lists a registry rule in
    ``source_rules`` AND word_N+1's FIRST grapheme entry lists the matching
    rule in ``target_rules``. The source scan walks entries END-TO-FRONT —
    for tanween rules the source sits on the consonant carrying the tanween
    (e.g. د in هُدًى), not the orthographically last entry. Returns
    ``[{rule, first_word_idx, second_word_idx}, ...]`` with 0-based indices
    into ``words``.

    Stopping (waqf) breaks the boundary in the phonemizer's tajweed output
    (the source rule is dropped on a stopping word), so iltiqaa-style cases
    naturally produce no detection.
    """
    if tajweed_mapping is None or not words:
        return []

    tj_words = list(getattr(tajweed_mapping, "words", []) or [])
    if not tj_words:
        return []

    # Map location → index in `words` so TajweedWordMapping locations resolve
    # to phonemizer WordMapping indices (lengths usually match; not relied on).
    loc_to_idx = {}
    for i, w in enumerate(words):
        loc = getattr(w, "location", None)
        if loc is not None and loc not in loc_to_idx:
            loc_to_idx[loc] = i

    def _rule_name(r):
        # source/target rules are TajweedRule enum members; .value is the
        # canonical string. str() fallback keeps string-rule variants working.
        return getattr(r, "value", None) or str(r)

    events = []
    for i in range(len(tj_words) - 1):
        wn = tj_words[i]
        wnp1 = tj_words[i + 1]
        wn_entries = list(getattr(wn, "entries", []) or [])
        wnp1_entries = list(getattr(wnp1, "entries", []) or [])
        if not wn_entries or not wnp1_entries:
            continue

        first_tgt = {_rule_name(r) for r in getattr(wnp1_entries[0], "target_rules", []) or []}
        if not first_tgt:
            continue

        canonical = None
        wb_map = _wb_tajweed_to_rule()
        for entry in reversed(wn_entries):
            for raw in getattr(entry, "source_rules", []) or []:
                name = _rule_name(raw)
                if name in wb_map and name in first_tgt:
                    canonical = wb_map[name]
                    break
            if canonical:
                break
        if canonical is None:
            continue

        first_idx = loc_to_idx.get(getattr(wn, "location", None))
        second_idx = loc_to_idx.get(getattr(wnp1, "location", None))
        if first_idx is None or second_idx is None:
            continue
        if second_idx != first_idx + 1:
            # Word ordering doesn't match (filtered ranges, repeats); skip
            # this boundary to keep the allocation deterministic.
            continue
        events.append({
            "rule": canonical,
            "first_word_idx": first_idx,
            "second_word_idx": second_idx,
        })
    return events


def resolve_word_boundary_allocation(
    payload, defaults: Mapping[str, str] | None = None
) -> dict[str, WbChoice]:
    """Normalize a word_boundary_allocation input to a full {rule: choice} dict.

    ``payload`` may be None/empty, a dict, or a JSON-object string. Unknown
    rule names and invalid choices raise ``ValueError`` so the API surface
    returns a clean error instead of silently ignoring typos.

    Precedence per rule: payload > ``defaults`` (the injected env-var layer;
    invalid values there are ignored) > ``WB_RULE_DEFAULTS`` > "first".
    """
    parsed = None
    if isinstance(payload, dict):
        parsed = payload
    elif isinstance(payload, str):
        s = payload.strip()
        if s:
            try:
                parsed = json.loads(s)
            except json.JSONDecodeError as e:
                raise ValueError(f"word_boundary_allocation: invalid JSON ({e})") from e
            if not isinstance(parsed, dict):
                raise ValueError("word_boundary_allocation must be a JSON object")
    elif payload is not None:
        raise ValueError("word_boundary_allocation must be a dict or JSON string")

    if parsed:
        for rule, choice in parsed.items():
            if rule not in WB_ALLOC_RULES:
                raise ValueError(
                    f"word_boundary_allocation: unknown rule {rule!r}; "
                    f"allowed: {sorted(WB_ALLOC_RULES)}"
                )
            if choice not in WB_ALLOC_VALUES:
                raise ValueError(
                    f"word_boundary_allocation: invalid choice {choice!r} for "
                    f"rule {rule!r}; allowed: {list(WB_ALLOC_VALUES)}"
                )

    resolved: dict[str, WbChoice] = {}
    for rule in WB_ALLOC_RULES:
        if parsed and rule in parsed:
            resolved[rule] = parsed[rule]
            continue
        default_val = (defaults.get(rule, "") if defaults else "").strip().lower()
        if default_val in WB_ALLOC_VALUES:
            resolved[rule] = default_val  # type: ignore[assignment]
        else:
            resolved[rule] = WB_RULE_DEFAULTS.get(rule, "first")
    return resolved


def apply_word_boundary_allocation(
    words_out: list[dict],
    cross_word_merges: list[dict],
    all_words: list,
    mapped_intervals: list[dict],
    allocation: Mapping[str, str],
) -> None:
    """Move boundary phone indices between adjacent words per rule allocation.

    For each merge whose rule resolves to "first", transfer the second word's
    leading transformed phones (count = transformed length of its first
    ``phonemes`` entry — 1 for ``m̃``-style, 2 for geminates, moved atomically)
    onto the first word. Refuses to leave the second word empty (skips the
    move instead). Mutates ``words_out`` in place: ``phone_indices``,
    ``start``, ``end`` on both words; letters/intervals/phones untouched.
    """
    from qua_sdk.components.timing.lib.transforms import normalize_phonemes, transform_phonemes

    if not cross_word_merges or not allocation or not words_out:
        return

    for ev in cross_word_merges:
        rule = ev["rule"]
        choice = allocation.get(rule, "asis")
        if choice != "first":
            continue
        i_first = ev["first_word_idx"]
        i_second = ev["second_word_idx"]
        if i_first < 0 or i_second >= len(words_out):
            continue

        w_first = words_out[i_first]
        w_second = words_out[i_second]
        # Cross-VERSE merger: the merged phone's grapheme lives in the SECOND
        # verse's word, so relocating it onto the first verse's last word strands
        # the cell from its letter across the segment boundary (the per-segment
        # cell-stamp can't reconcile it, and the whole waṣl group drops cells).
        # Keep the phone on its natural word — the bridge renders between the
        # verses and the cell snaps to its own letter. Only intra-verse "first"
        # moves apply; their timing policy is unchanged.
        verse_first = str(w_first.get("location", "")).rsplit(":", 1)[0]
        verse_second = str(w_second.get("location", "")).rsplit(":", 1)[0]
        if verse_first and verse_second and verse_first != verse_second:
            continue
        wm_second = all_words[i_second] if i_second < len(all_words) else None
        if wm_second is None or not getattr(wm_second, "phonemes", None):
            continue
        first_orig_phoneme = wm_second.phonemes[0]
        transformed = transform_phonemes(normalize_phonemes(first_orig_phoneme)).split()
        n_move = len(transformed)
        if n_move <= 0:
            continue
        # The merged boundary consonant was already assimilated onto the first
        # word by the phonemizer (idgham shafawi م+مّ → the m̃ sits on word 1), so
        # the second word's first phoneme group is its orphaned vowel. Moving that
        # vowel mis-attributes it (the damma of مُّلَٰقُوا would jump onto أَنَّهُم) and
        # leaves the shard phones disagreeing with the per-word cell re-derive.
        # There is no boundary consonant to relocate — skip.
        if transformed[0] in _VOWEL_PHONES:
            continue

        second_indices = list(w_second.get("phone_indices", []))
        if len(second_indices) <= n_move:
            # Refuse to leave the second word with zero phones; skip the move
            # rather than corrupting downstream output.
            continue
        moved = second_indices[:n_move]
        remaining = second_indices[n_move:]

        first_indices = list(w_first.get("phone_indices", [])) + moved

        w_first["phone_indices"] = first_indices
        w_second["phone_indices"] = remaining

        def _active(indices):
            return [
                mapped_intervals[pi] for pi in indices
                if pi < len(mapped_intervals) and is_active_phone(mapped_intervals[pi].get("phone"))
            ]

        a_first = _active(first_indices)
        if a_first:
            w_first["start"] = a_first[0]["start"]
            w_first["end"] = a_first[-1]["end"]
        a_second = _active(remaining)
        if a_second:
            w_second["start"] = a_second[0]["start"]
            w_second["end"] = a_second[-1]["end"]
