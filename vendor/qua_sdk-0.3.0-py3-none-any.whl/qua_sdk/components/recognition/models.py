"""Model registry for recognition runtimes: alias → (repo, revision, inventory).

Import-light: pure pydantic data, no torch/transformers.
"""

from __future__ import annotations

from qua_sdk.schemas.base import SdkModel


class ModelRef(SdkModel):
    repo_id: str
    revision: str | None = None   # immutable commit SHA, pinned per SDK release
    inventory_mode: str = "full"


# Today's model registry (aligner config.PHONEME_ASR_MODELS + MODEL_MODES).
# Revisions get pinned to commit SHAs when the real runtimes land.
KNOWN_MODELS: dict[str, ModelRef] = {
    "Base": ModelRef(repo_id="hetchyy/r15_95m"),
    "Base v2": ModelRef(repo_id="hetchyy/quran-asr-base-tadabur"),
    "Medium": ModelRef(repo_id="hetchyy/quran-asr-medium-tadabur"),
    "Large": ModelRef(repo_id="hetchyy/r7"),
    "Large v2": ModelRef(repo_id="hetchyy/quran-asr-large-tadabur"),
    "Simple": ModelRef(repo_id="hetchyy/quran-asr-base-tadabur-simple", inventory_mode="simple"),
}
