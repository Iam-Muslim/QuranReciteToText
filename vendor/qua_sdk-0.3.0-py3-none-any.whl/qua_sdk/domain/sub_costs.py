"""DP substitution costs: how cheap it is to confuse one phoneme for another.

Packaged per inventory mode in ``data/phoneme_sub_costs{,_simple}.json`` —
named sections of ``"a|b": cost`` pairs (``_meta`` skipped). Both orderings
are stored at load so lookups need only a plain tuple.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from importlib import resources
from typing import Mapping

_FILES = {"full": "phoneme_sub_costs.json", "simple": "phoneme_sub_costs_simple.json"}


@dataclass(frozen=True)
class SubCostTable:
    mode: str
    default: float
    pairs: Mapping[tuple[str, str], float]  # both orderings present

    def get(self, p: str, r: str) -> float:
        """0.0 on exact match, pair-specific cost if defined, else the default."""
        if p == r:
            return 0.0
        return self.pairs.get((p, r), self.default)


@lru_cache(maxsize=4)
def load_sub_costs(mode: str = "full", default: float = 1.0) -> SubCostTable:
    if mode not in _FILES:
        raise ValueError(f"unknown phoneme mode {mode!r}, want one of {sorted(_FILES)}")
    raw = json.loads(
        (resources.files("qua_sdk.domain") / "data" / _FILES[mode]).read_text(encoding="utf-8")
    )
    pairs: dict[tuple[str, str], float] = {}
    for section, entries in raw.items():
        if section == "_meta":
            continue
        for pair_str, cost in entries.items():
            a, b = pair_str.split("|")
            pairs[(a, b)] = pairs[(b, a)] = float(cost)
    return SubCostTable(mode=mode, default=default, pairs=pairs)
