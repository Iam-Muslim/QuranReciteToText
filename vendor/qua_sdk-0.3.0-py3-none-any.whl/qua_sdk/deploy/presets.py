"""Deploy configs: WHERE/HOW it runs — never affects RESULT CONTENT.

(It can affect outcome availability: a ZeroGPU lease cap can kill work that a
batch box completes. Content-equality holds for whatever completes.)
The split this enforces (vs today's config.py mixing both): device, dtype,
torch.compile/AOTI, batching shape, lease grouping, worker counts are deploy;
windows/thresholds/model choice are profile.
"""

from __future__ import annotations

from typing import Literal

from qua_sdk.schemas.base import SdkModel


class BatchingConfig(SdkModel):
    strategy: Literal["naive", "dynamic"] = "dynamic"  # dynamic = seconds + pad-waste aware
    max_batch_seconds: int = 600
    max_pad_waste: float = 0.2
    min_batch_size: int = 8
    naive_batch_size: int = 32       # fixed segments per batch when strategy="naive"


class DeployConfig(SdkModel):
    name: str
    # the set components/device.py actually handles (cuda gets the cpu fallback)
    device: Literal["cuda", "cpu"] = "cuda"
    dtype: Literal["float16", "bfloat16", "bf16", "float32"] = "float16"
    torch_compile: bool = True
    aoti: bool = False               # ahead-of-time compile cache (ZeroGPU)
    aoti_min_audio_minutes: int = 15  # AOTI artifacts only cover this duration band;
    aoti_max_audio_minutes: int = 90  # outside it the segmenter falls back to eager
    aoti_hub_repo: str | None = None  # HF repo hosting prebuilt AOTI artifacts
    segmentation_batch_size: int = 8
    batching: BatchingConfig = BatchingConfig()
    zerogpu_max_duration_s: int | None = None
    download_workers: int = 8
    # stages to run inside ONE execution context (a single GPU lease/process).
    # Today's run_vad_and_asr_gpu = [["segmentation", "recognition"]]; the
    # executor mechanism lands with the real runtimes — same results either way.
    lease_groups: list[list[str]] = []


SPACE_ZEROGPU = DeployConfig(
    name="space_zerogpu", device="cuda", dtype="float16",
    torch_compile=True, aoti=True, aoti_hub_repo="hetchyy/quran-aligner-aoti",
    zerogpu_max_duration_s=120,
    lease_groups=[["segmentation", "recognition"]],
)

KATANA_BATCH = DeployConfig(
    name="katana_batch", device="cuda", dtype="float16",
    torch_compile=False,  # batch jobs skip compile overhead
    batching=BatchingConfig(max_batch_seconds=500, min_batch_size=16, max_pad_waste=0.25),
    download_workers=32,
)

CI_CPU = DeployConfig(
    name="ci_cpu", device="cpu", dtype="bfloat16", torch_compile=False,
    batching=BatchingConfig(max_batch_seconds=300),
)
