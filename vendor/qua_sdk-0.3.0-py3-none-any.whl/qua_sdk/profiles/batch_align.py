"""batch_align profile SCHEMA — deployment values are consumer-owned.

The SDK ships the shape (``BatchAlignProfile``), the per-runtime params
classes with their bounds, and lossless ``load()``/dump provenance. Which
VALUES a deployment runs is that consumer's business: the aligner Space and
the offline extraction repo each define their own profile instance — keeping
them here froze stale copies of consumer config. ``TEST`` stays: it binds the
pure-python fakes and powers the conformance harness.

A profile changes RESULT CONTENT: component choice + algorithm knobs. Device,
dtype, torch.compile, batching, lease shape live in deploy configs instead.
Per-stage params are the METHOD subclasses matching the stage's runtime key
(base Params carry only the capability-generic surface).
"""

from __future__ import annotations

import json
from typing import ClassVar

from pydantic import SerializeAsAny

from qua_sdk.components.matching.runtimes.wraparound_params import WraparoundDpParams
from qua_sdk.components.matching.spec import MatchingParams
from qua_sdk.components.recognition.spec import RecognitionParams
from qua_sdk.components.segmentation.runtimes.recitation_params import RecitationSegmenterParams
from qua_sdk.components.segmentation.spec import SegmentationParams
from qua_sdk.components.timing.spec import TimingParams
from qua_sdk.schemas.base import SdkModel


class BatchAlignProfile(SdkModel):
    """A new method for any stage = a new runtime key + (optionally) a Params
    subclass passed in the matching field — SerializeAsAny keeps subclass
    knobs in the provenance dump. Deserialize a dumped profile via ``load``
    (W2): the runtime key in the blob discriminates the params subclass."""

    name: str
    # component selection (registry keys — versioned, swappable)
    segmenter: str = "segmentation.recitation_v2@v1"
    recognizer: str = "recognition.w2v2_ctc@v1"
    matcher: str = "matching.wraparound_dp@v1"
    timing: str | None = None            # None = skip word timestamps
    # per-component knobs (defaults match the default runtime keys above)
    segmentation: SerializeAsAny[SegmentationParams] = RecitationSegmenterParams()
    recognition: SerializeAsAny[RecognitionParams] = RecognitionParams()
    matching: SerializeAsAny[MatchingParams] = WraparoundDpParams()
    timing_params: SerializeAsAny[TimingParams] = TimingParams()

    # params field → runtime-key field whose resolved runtime owns the subclass
    _PARAMS_FIELDS: ClassVar[dict[str, str]] = {
        "segmentation": "segmenter",
        "recognition": "recognizer",
        "matching": "matcher",
        "timing_params": "timing",
    }

    @classmethod
    def load(cls, data: str | dict) -> "BatchAlignProfile":
        """Lossless deserialization: the runtime key in the blob IS the params
        discriminator — each params dict validates through the resolved
        runtime's declared ``Params`` type (``timing=None`` → base TimingParams).
        Naive ``model_validate_json`` raises on subclass dumps; use this."""
        import qua_sdk.components  # noqa: F401  (registers runtime keys)
        from qua_sdk.registry import resolve

        raw = json.loads(data) if isinstance(data, str) else dict(data)
        params_blobs = {f: raw.pop(f) for f in cls._PARAMS_FIELDS if f in raw}
        envelope = cls.model_validate(raw)  # keys/name validated; params defaulted

        updates = {}
        for field, blob in params_blobs.items():
            key = getattr(envelope, cls._PARAMS_FIELDS[field])
            model = resolve(key).Params if key else TimingParams
            updates[field] = model.model_validate(blob)
        return envelope.model_copy(update=updates)


# Pure-python fakes: powers the conformance harness and CI without ML deps.
# Fakes take the BASE params (a fake needs no method knobs).
TEST = BatchAlignProfile(
    name="test",
    segmenter="segmentation.fake@v1",
    recognizer="recognition.fake@v1",
    matcher="matching.fake@v1",
    timing="timing.fake@v1",
    segmentation=SegmentationParams(),
    matching=MatchingParams(),
)
