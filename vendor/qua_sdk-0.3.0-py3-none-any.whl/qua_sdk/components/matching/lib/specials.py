"""Special-segment templates and detectors (Basmala, Isti'adha, transitions).

``SPECIAL_PHONEMES`` lives in ``domain.special_texts`` (shared with timing) and
is re-exported here. Templates are authored in the FULL phoneme inventory; ``templates_for(mode)``
collapses each template WHOLE-LIST via ``collapse_phonemes`` for simple mode —
deliberately different from chapter references, which collapse PER WORD (the
collapse rule is context-sensitive, so the two must stay distinct). Display
text is inventory-independent. Detectors are pure: templates + thresholds in,
``(list[SpecialHit], consumed)`` out — no module-level config or mode state.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Mapping, Optional

from qua_sdk.domain.special_texts import SPECIAL_PHONEMES, SPECIAL_TEXT, TRANSITION_TEXT
from qua_sdk.schemas.base import SdkModel

__all__ = [
    "SPECIAL_PHONEMES", "TRANSITION_PHONEMES", "ALL_SPECIAL_REFS", "COMBINED_TEXT_SEPARATOR",
    "SpecialHit", "SpecialTemplates", "templates_for",
    "levenshtein_distance", "phoneme_edit_distance",
    "detect_transition_segment", "detect_opening_specials", "detect_inter_chapter_specials",
]


class SpecialHit(SdkModel):
    """One detected special segment (Basmala/Isti'adha/transition)."""

    text: str     # display text, shown as matched_text
    score: float  # 1 - normalized edit distance
    ref: str      # name emitted as matched_ref (member of ALL_SPECIAL_REFS)

    def as_tuple(self) -> tuple[str, float, str]:
        """The legacy result-row shape the sequencer's results list carries."""
        return (self.text, self.score, self.ref)

TRANSITION_PHONEMES: dict[str, tuple[str, ...]] = {
    "Amin": ("ʔ", "a:", "m", "i:", "n"),
    "Takbir": ("ʔ", "a", "lˤlˤ", "aˤ:", "h", "u", "ʔ", "a", "k", "b", "a", "rˤ"),
    "Takbir_double": (
        "ʔ", "a", "lˤlˤ", "aˤ:", "h", "u", "ʔ", "a", "k", "b", "a", "rˤ", "ʔ", "a", "lˤlˤ", "aˤ:", "h",
        "u", "ʔ", "a", "k", "b", "a", "rˤ",
    ),
    "Tahmeed": (
        "s", "a", "m", "i", "ʕ", "a", "lˤlˤ", "aˤ:", "h", "u", "l", "i", "m", "a", "n", "ħ", "a", "m",
        "i", "d", "a", "h",
    ),
    "Tahmeed_combined": (
        "s", "a", "m", "i", "ʕ", "a", "lˤlˤ", "aˤ:", "h", "u", "l", "i", "m", "a", "n", "ħ", "a", "m",
        "i", "d", "a", "h", "u", "rˤ", "aˤ", "bb", "a", "n", "a:", "w", "a", "l", "a", "k", "a", "l",
        "ħ", "a", "m", "d",
    ),
    "Tahmeed_response": (
        "rˤ", "aˤ", "bb", "a", "n", "a:", "w", "a", "l", "a", "k", "a", "l", "ħ", "a", "m", "d",
    ),
    "Tasleem": (
        "ʔ", "a", "ss", "a", "l", "a", "m", "u", "ʕ", "a", "l", "a", "j", "k", "u", "m", "w", "a",
        "rˤ", "aˤ", "ħ", "m", "a", "t", "u", "lˤlˤ", "aˤ:", "h",
    ),
    "Sadaqa": ("sˤ", "aˤ", "d", "a", "q", "aˤ", "lˤlˤ", "aˤ:", "h", "u", "l", "ʕ", "a", "ðˤ", "i:", "m"),
}

# Combined opener = Isti'adha + Basmala recited in one segment.
COMBINED_TEXT_SEPARATOR = " \u06dd "  # Arabic end-of-ayah sign

# Variant template keys map to their base/display name; variants only affect
# matching, never the reported name.
_TRANSITION_BASE_NAMES = {
    "Takbir_double": "Takbir",
    "Tahmeed_combined": "Tahmeed",
    "Tahmeed_response": "Tahmeed",
}

# Every name the matcher can emit as a matched_ref special.
ALL_SPECIAL_REFS = frozenset({
    "Basmala", "Isti'adha", "Isti'adha+Basmala",
    "Amin", "Takbir", "Tahmeed", "Tasleem", "Sadaqa",
})


@dataclass(frozen=True)
class SpecialTemplates:
    """Immutable per-mode template bundle consumed by the detectors."""

    mode: str
    special: Mapping[str, tuple[str, ...]]
    transition: Mapping[str, tuple[str, ...]]
    combined: tuple[str, ...]  # Isti'adha + Basmala concatenated


@lru_cache(maxsize=4)
def templates_for(mode: str) -> SpecialTemplates:
    """Templates in *mode*'s inventory (whole-list collapse for simple)."""
    if mode == "full":
        special = dict(SPECIAL_PHONEMES)
        transition = dict(TRANSITION_PHONEMES)
    else:
        from qua_sdk.domain.chapter_refs import collapse_to_simple

        special = {k: tuple(collapse_to_simple(list(v))) for k, v in SPECIAL_PHONEMES.items()}
        transition = {k: tuple(collapse_to_simple(list(v))) for k, v in TRANSITION_PHONEMES.items()}
    return SpecialTemplates(
        mode=mode,
        special=special,
        transition=transition,
        combined=special["Isti'adha"] + special["Basmala"],
    )


def levenshtein_distance(seq1, seq2) -> int:
    """Standard Levenshtein edit distance between two phoneme sequences."""
    m, n = len(seq1), len(seq2)
    if m == 0:
        return n
    if n == 0:
        return m
    prev = list(range(n + 1))
    curr = [0] * (n + 1)
    for i in range(1, m + 1):
        curr[0] = i
        for j in range(1, n + 1):
            if seq1[i - 1] == seq2[j - 1]:
                curr[j] = prev[j - 1]
            else:
                curr[j] = 1 + min(prev[j], curr[j - 1], prev[j - 1])
        prev, curr = curr, prev
    return prev[n]


def phoneme_edit_distance(asr_phonemes, ref_phonemes) -> float:
    """Normalized edit distance (0.0 identical, 1.0 disjoint; empty input = 1.0)."""
    if not asr_phonemes or not ref_phonemes:
        return 1.0
    return levenshtein_distance(asr_phonemes, ref_phonemes) / max(len(asr_phonemes), len(ref_phonemes))


def detect_transition_segment(
    asr_phonemes: list[str],
    templates: SpecialTemplates,
    *,
    max_transition_edit_distance: float,
    allowed: Optional[set] = None,
) -> tuple[Optional[str], float]:
    """Best transition match (lowest edit distance under threshold).

    ``allowed`` restricts detection to a set of base names (e.g. {"Amin"}).
    Returns (base_name, 1 - distance) or (None, 0.0).
    """
    if not asr_phonemes:
        return None, 0.0

    best_name = None
    best_dist = float("inf")
    for key, ref_phonemes in templates.transition.items():
        base_name = _TRANSITION_BASE_NAMES.get(key, key)
        if allowed is not None and base_name not in allowed:
            continue
        dist = phoneme_edit_distance(asr_phonemes, ref_phonemes)
        if dist < best_dist:
            best_dist = dist
            best_name = base_name

    if best_dist <= max_transition_edit_distance and best_name is not None:
        return best_name, 1.0 - best_dist
    return None, 0.0


def detect_opening_specials(
    phoneme_texts: list[list[str]],
    templates: SpecialTemplates,
    *,
    max_special_edit_distance: float,
    max_transition_edit_distance: float,
) -> tuple[list[SpecialHit], int]:
    """Detect recitation-opening specials (Takbir / Isti'adha / Basmala).

    Order: Takbir on segment 0, then on the first non-Takbir segment try
    COMBINED, else Isti'adha (+ Basmala on the next), else Basmala.
    Returns (special hits, first_quran_idx).
    """
    if not phoneme_texts:
        return [], 0

    special_results: list[SpecialHit] = []

    takbir_offset = 0
    seg0_phonemes = phoneme_texts[0] if phoneme_texts[0] else []
    takbir_name, takbir_conf = detect_transition_segment(
        seg0_phonemes, templates,
        max_transition_edit_distance=max_transition_edit_distance, allowed={"Takbir"})
    if takbir_name:
        special_results.append(
            SpecialHit(text=TRANSITION_TEXT["Takbir"], score=takbir_conf, ref="Takbir"))
        takbir_offset = 1
        if len(phoneme_texts) > 1:
            seg0_phonemes = phoneme_texts[1] if phoneme_texts[1] else []
        else:
            return special_results, takbir_offset

    check_idx = takbir_offset

    # 1. Combined Isti'adha+Basmala in one segment
    combined_dist = phoneme_edit_distance(seg0_phonemes, templates.combined)
    if combined_dist <= max_special_edit_distance:
        combined_text = SPECIAL_TEXT["Isti'adha"] + COMBINED_TEXT_SEPARATOR + SPECIAL_TEXT["Basmala"]
        special_results.append(
            SpecialHit(text=combined_text, score=1.0 - combined_dist, ref="Isti'adha+Basmala"))
        return special_results, takbir_offset + 1

    # 2. Isti'adha, then Basmala on the next segment
    istiadha_dist = phoneme_edit_distance(seg0_phonemes, templates.special["Isti'adha"])
    if istiadha_dist <= max_special_edit_distance:
        special_results.append(
            SpecialHit(text=SPECIAL_TEXT["Isti'adha"], score=1.0 - istiadha_dist, ref="Isti'adha"))
        next_idx = check_idx + 1
        if next_idx < len(phoneme_texts) and phoneme_texts[next_idx]:
            basmala_dist = phoneme_edit_distance(phoneme_texts[next_idx], templates.special["Basmala"])
            if basmala_dist <= max_special_edit_distance:
                special_results.append(
                    SpecialHit(text=SPECIAL_TEXT["Basmala"], score=1.0 - basmala_dist, ref="Basmala"))
                return special_results, takbir_offset + 2
        return special_results, takbir_offset + 1

    # 3. Basmala alone
    basmala_dist = phoneme_edit_distance(seg0_phonemes, templates.special["Basmala"])
    if basmala_dist <= max_special_edit_distance:
        special_results.append(
            SpecialHit(text=SPECIAL_TEXT["Basmala"], score=1.0 - basmala_dist, ref="Basmala"))
        return special_results, takbir_offset + 1

    # 4. Nothing beyond Takbir (if any)
    if takbir_offset > 0:
        return special_results, takbir_offset
    return [], 0


def detect_inter_chapter_specials(
    phoneme_texts: list[list[str]],
    templates: SpecialTemplates,
    *,
    max_special_edit_distance: float,
) -> tuple[list[SpecialHit], int]:
    """Detect Isti'adha/Basmala between chapters (same order as the opener scan).

    Returns (special hits, num_consumed segments).
    """
    if not phoneme_texts or not phoneme_texts[0]:
        return [], 0

    seg0_phonemes = phoneme_texts[0]

    combined_dist = phoneme_edit_distance(seg0_phonemes, templates.combined)
    if combined_dist <= max_special_edit_distance:
        combined_text = SPECIAL_TEXT["Isti'adha"] + COMBINED_TEXT_SEPARATOR + SPECIAL_TEXT["Basmala"]
        return [SpecialHit(text=combined_text, score=1.0 - combined_dist, ref="Isti'adha+Basmala")], 1

    istiadha_dist = phoneme_edit_distance(seg0_phonemes, templates.special["Isti'adha"])
    if istiadha_dist <= max_special_edit_distance:
        results = [SpecialHit(text=SPECIAL_TEXT["Isti'adha"], score=1.0 - istiadha_dist, ref="Isti'adha")]
        consumed = 1
        if len(phoneme_texts) >= 2 and phoneme_texts[1]:
            basmala_dist = phoneme_edit_distance(phoneme_texts[1], templates.special["Basmala"])
            if basmala_dist <= max_special_edit_distance:
                results.append(
                    SpecialHit(text=SPECIAL_TEXT["Basmala"], score=1.0 - basmala_dist, ref="Basmala"))
                consumed = 2
        return results, consumed

    basmala_dist = phoneme_edit_distance(seg0_phonemes, templates.special["Basmala"])
    if basmala_dist <= max_special_edit_distance:
        return [SpecialHit(text=SPECIAL_TEXT["Basmala"], score=1.0 - basmala_dist, ref="Basmala")], 1

    return [], 0
