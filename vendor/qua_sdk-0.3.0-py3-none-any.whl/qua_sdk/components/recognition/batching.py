"""Pure batching + CTC-collapse logic for the recognition runtime.

Batch building takes duration-sorted indices and packs them under explicit
constraints (the deploy config supplies the numbers); ``ids_to_phoneme_list``
is greedy CTC decoding over any tokenizer-like object exposing
``convert_ids_to_tokens``. No torch anywhere — fully unit-testable.
"""

from __future__ import annotations

from typing import Sequence

WORD_DELIMITER = "|"


def build_batches_naive(sorted_indices: Sequence[int], batch_size: int) -> list[list[int]]:
    """Fixed-count batching."""
    return [list(sorted_indices[i:i + batch_size])
            for i in range(0, len(sorted_indices), batch_size)]


def build_batches(
    sorted_indices: Sequence[int],
    durations: Sequence[float],
    *,
    max_batch_seconds: float,
    max_pad_waste: float,
    min_batch_size: int,
) -> list[list[int]]:
    """Build dynamic batches from duration-sorted indices.

    Constraints:
        - sum(durations) per batch <= max_batch_seconds
        - pad waste fraction <= max_pad_waste  (1 - sum/[n*max], wasted tensor compute)
        - a batch is never cut below min_batch_size (avoids underutilization)
    """
    batches: list[list[int]] = []
    current: list[int] = []
    current_seconds = 0.0

    for i in sorted_indices:
        dur = durations[i]

        if not current:
            current.append(i)
            current_seconds = dur
            continue

        max_dur = dur                      # candidate is the new longest (sorted ascending)
        new_seconds = current_seconds + dur
        new_size = len(current) + 1
        pad_waste = 1.0 - new_seconds / (new_size * max_dur) if max_dur > 0 else 0.0

        seconds_exceeded = new_seconds > max_batch_seconds
        waste_exceeded = pad_waste > max_pad_waste

        if (seconds_exceeded or waste_exceeded) and len(current) >= min_batch_size:
            batches.append(current)
            current = [i]
            current_seconds = dur
        else:
            current.append(i)
            current_seconds = new_seconds

    if current:
        batches.append(current)

    return batches


def ids_to_phoneme_list(ids: Sequence[int], tokenizer, pad_id: int | None) -> list[str]:
    """Convert token IDs to a phoneme list with CTC collapse.

    1. Drop pad/blank tokens. 2. Collapse consecutive duplicates (pad and the
    word delimiter break adjacency, so "a PAD a" survives as two a's).
    3. Drop the word delimiter.
    """
    toks = tokenizer.convert_ids_to_tokens(ids)
    if not toks:
        return []

    pad_tok = tokenizer.convert_ids_to_tokens([pad_id])[0] if pad_id is not None else "[PAD]"

    collapsed: list[str] = []
    prev = None
    for t in toks:
        if t == pad_tok:
            prev = t
            continue
        if t == WORD_DELIMITER:
            prev = t
            continue
        if t == prev:
            continue
        collapsed.append(t)
        prev = t

    return collapsed
