"""Word-location refs: the "2:255:1" / "2:255:1-2:255:5" grammar used everywhere.

Specials are names, not locations — they parse as RefSpan(special=...).
SPECIAL_NAMES is exactly the set the matcher can emit as a matched_ref
(special_segments' ALL_SPECIAL_REFS).
"""

from __future__ import annotations

from typing import NamedTuple

from qua_sdk.errors import ErrorCode, InputError

SPECIAL_NAMES = frozenset({
    "Basmala", "Isti'adha", "Isti'adha+Basmala",
    "Amin", "Takbir", "Tahmeed", "Tasleem", "Sadaqa",
})


class Location(NamedTuple):
    surah: int
    ayah: int
    word: int

    def __str__(self) -> str:
        return f"{self.surah}:{self.ayah}:{self.word}"


class RefSpan(NamedTuple):
    start: Location | None
    end: Location | None
    special: str | None = None

    def __str__(self) -> str:
        if self.special:
            return self.special
        if self.start == self.end:
            return str(self.start)
        return f"{self.start}-{self.end}"


def parse_location(text: str) -> Location:
    parts = text.split(":")
    if len(parts) != 3:
        raise InputError(ErrorCode.REF_INVALID, f"bad location {text!r}, want s:a:w")
    try:
        s, a, w = (int(p) for p in parts)
    except ValueError:
        raise InputError(ErrorCode.REF_INVALID, f"non-numeric location {text!r}") from None
    if not (1 <= s <= 114 and a >= 1 and w >= 1):
        raise InputError(ErrorCode.REF_INVALID, f"out-of-range location {text!r}")
    return Location(s, a, w)


def parse_span(text: str) -> RefSpan:
    if text in SPECIAL_NAMES:
        return RefSpan(None, None, special=text)
    if "-" in text:
        a, b = text.split("-", 1)
        return RefSpan(parse_location(a), parse_location(b))
    loc = parse_location(text)
    return RefSpan(loc, loc)
