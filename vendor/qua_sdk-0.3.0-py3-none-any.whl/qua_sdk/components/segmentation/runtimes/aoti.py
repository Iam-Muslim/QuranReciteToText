"""AOTInductor compile + Hub cache for the segmentation runtime (ZeroGPU).

Artifacts cover one dynamic-shape band (``deploy.aoti_min/max_audio_minutes``)
and are keyed by that band into ``deploy.aoti_hub_repo`` — one Space compile
serves every later boot. Flow: ``try_load_from_hub`` first; on miss,
``export_and_compile`` (inside a GPU lease, model on cuda) then
``apply_compiled`` back in the main process. ``import spaces`` (the HF ZeroGPU
SDK) and torch only happen inside functions.
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass, field
from typing import Any

SAMPLES_PER_MINUTE = 16_000 * 60
MODEL_FRAME_DIM = 1  # sequence axis of the captured 2D+ tensors


@dataclass
class AotiState:
    """Per-runtime AOTI bookkeeping (mirrors the legacy module cache)."""

    exported: Any = None
    compiled: Any = None
    applied: bool = False
    tested: bool = False
    results: dict = field(default_factory=dict)


def hub_filename(deploy) -> str:
    """Hub artifact name, keyed by the dynamic-shape duration band."""
    return f"vad_aoti_{deploy.aoti_min_audio_minutes}min_{deploy.aoti_max_audio_minutes}min.pt2"


def try_load_from_hub(runtime, deploy) -> bool:
    """Load a pre-compiled artifact from the Hub and apply it. False on any miss."""
    if not deploy or not deploy.aoti_hub_repo:
        return False
    token = os.environ.get("HF_TOKEN")
    if not token:
        return False
    model = runtime._model
    if model is None:
        return False

    filename = hub_filename(deploy)
    try:
        from huggingface_hub import HfApi, hf_hub_download

        api = HfApi(token=token)
        if filename not in api.list_repo_files(deploy.aoti_hub_repo, token=token):
            return False
        compiled_graph_file = hf_hub_download(deploy.aoti_hub_repo, filename, token=token)

        from spaces.zero.torch.aoti import (
            ZeroGPUCompiledModel,
            ZeroGPUWeights,
            drain_module_parameters,
        )

        state_dict = model.state_dict()
        weights = ZeroGPUWeights({name: weight for name, weight in state_dict.items()})
        compiled = ZeroGPUCompiledModel(compiled_graph_file, weights)
        setattr(model, "forward", compiled)
        drain_module_parameters(model)

        runtime.aoti.compiled = compiled
        runtime.aoti.applied = True
        return True
    except Exception:
        return False


def export_and_compile(runtime, deploy) -> dict:
    """torch.export + spaces.aoti_compile with the band's dynamic shapes.

    Must run with the model on cuda (inside a GPU lease). Captures the exact
    call signature segment_recitations feeds the model, exports with a dynamic
    sequence dim spanning the deploy's duration band, compiles, and pushes the
    artifact to the Hub. Returns a results dict; apply happens separately via
    ``apply_compiled`` (outside the lease).
    """
    import time

    results = {
        "export_success": False, "export_time": 0.0,
        "compile_success": False, "compile_time": 0.0,
        "hub_loaded": False, "hub_uploaded": False, "error": None,
    }
    state = runtime.aoti
    if state.tested:
        return {"skipped": True, **results}
    state.tested = True

    model, processor = runtime._model, runtime._processor
    if model is None:
        results["error"] = "model not loaded"
        return results
    if runtime._device is None or runtime._device.type != "cuda":
        results["error"] = f"model not on cuda (device={runtime._device})"
        return results

    try:
        import spaces
        import torch
    except ImportError as e:
        results["error"] = f"{e.name} not available"
        return results

    if try_load_from_hub(runtime, deploy):
        results["hub_loaded"] = True
        results["compile_success"] = True
        return results

    min_samples = int(deploy.aoti_min_audio_minutes * SAMPLES_PER_MINUTE)
    # Capture at min duration to save memory; audio must be on CPU —
    # segment_recitations moves it to the device internally.
    test_audio = torch.randn(min_samples, device="cpu")
    try:
        from recitations_segmenter import segment_recitations

        with spaces.aoti_capture(model) as call:
            segment_recitations(
                [test_audio], model, processor,
                device=runtime._device, dtype=runtime._dtype, batch_size=1,
            )
    except Exception as e:
        results["error"] = f"aoti_capture failed: {type(e).__name__}: {e}"
        return results

    try:
        from torch.export import Dim, export

        captured_frames = None
        for val in list(call.kwargs.values()) + list(call.args):
            if isinstance(val, torch.Tensor) and val.dim() >= 2:
                captured_frames = val.shape[MODEL_FRAME_DIM]
                break
        if captured_frames is None:
            raise ValueError("no 2D+ tensor found in captured args/kwargs")

        frames_per_minute = captured_frames / deploy.aoti_min_audio_minutes
        dynamic_t = Dim(
            "T", min=captured_frames,
            max=int(deploy.aoti_max_audio_minutes * frames_per_minute),
        )
        dyn_args = [
            {MODEL_FRAME_DIM: dynamic_t} if isinstance(a, torch.Tensor) and a.dim() >= 2 else None
            for a in call.args
        ]
        dyn_kwargs = {
            k: ({MODEL_FRAME_DIM: dynamic_t} if isinstance(v, torch.Tensor) and v.dim() >= 2 else None)
            for k, v in call.kwargs.items()
        }

        t0 = time.perf_counter()
        exported = export(
            model, args=call.args, kwargs=call.kwargs,
            dynamic_shapes=(dyn_args, dyn_kwargs) if dyn_args else dyn_kwargs,
            strict=False,
        )
        results["export_time"] = time.perf_counter() - t0
        results["export_success"] = True
        state.exported = exported
    except Exception as e:
        results["error"] = f"torch.export failed: {type(e).__name__}: {e}"
        return results

    try:
        t0 = time.perf_counter()
        compiled = spaces.aoti_compile(exported)
        results["compile_time"] = time.perf_counter() - t0
        results["compile_success"] = True
        state.compiled = compiled
        results["compiled"] = compiled
        if _push_to_hub(compiled, deploy):
            results["hub_uploaded"] = True
    except Exception as e:
        results["error"] = f"aoti_compile failed: {type(e).__name__}: {e}"

    state.results = {k: v for k, v in results.items() if k != "compiled"}
    return results


def apply_compiled(runtime, compiled) -> bool:
    """Swap the model's forward for the compiled graph (main process, no lease)."""
    if compiled is None or runtime._model is None:
        return False
    try:
        import spaces

        spaces.aoti_apply(compiled, runtime._model)
        runtime.aoti.compiled = compiled
        runtime.aoti.applied = True
        return True
    except Exception:
        return False


def _push_to_hub(compiled, deploy) -> bool:
    """Upload the compiled archive for future boots. Best-effort."""
    if not deploy or not deploy.aoti_hub_repo:
        return False
    token = os.environ.get("HF_TOKEN")
    if not token:
        return False
    archive = getattr(compiled, "archive_file", None)
    if archive is None:
        return False
    filename = hub_filename(deploy)
    try:
        from huggingface_hub import HfApi, create_repo

        api = HfApi(token=token)
        try:
            create_repo(deploy.aoti_hub_repo, exist_ok=True, token=token)
        except Exception:
            pass
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = os.path.join(tmpdir, filename)
            with open(output_path, "wb") as f:
                f.write(archive.getvalue())
            api.upload_file(
                repo_id=deploy.aoti_hub_repo,
                path_or_fileobj=output_path,
                path_in_repo=filename,
                commit_message=(
                    f"Add compiled VAD model ({deploy.aoti_min_audio_minutes}-"
                    f"{deploy.aoti_max_audio_minutes} min)"
                ),
                token=token,
            )
        return True
    except Exception:
        return False
