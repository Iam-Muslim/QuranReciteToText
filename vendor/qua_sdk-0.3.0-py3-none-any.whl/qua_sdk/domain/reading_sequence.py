"""Reading-order reconstruction from wraparound-DP repetition data."""

from __future__ import annotations


def compute_reading_sequence(ref_from: str, ref_to: str,
                             wrap_word_ranges: list) -> list:
    """Return reading-order [[ref_from, ref_to], ...] from wrap data.

    Given the overall matched range and the wrap points, reconstructs the
    full recitation sequence showing how the text was actually read
    (including repeated sections).

    Supports 3-element tuples (jump_to, jump_from, repeat_end) and
    2-element tuples (jump_to, jump_from).

    Example: ref "2:255:1" to "2:255:10", wrap [("2:255:3", "2:255:5", "2:255:8")]
    → [["2:255:1", "2:255:5"], ["2:255:3", "2:255:8"]]
    (read words 1-5 forward, then repeated 3-8)
    """
    if wrap_word_ranges and len(wrap_word_ranges[0]) >= 3:
        # 3-element format: (jump_to, jump_from, repeat_end)
        # Forward section: ref_from to first wrap's jump_from
        sections = [[ref_from, wrap_word_ranges[0][1]]]
        # Each wrap's actual repeated content
        for wr in wrap_word_ranges:
            sections.append([wr[0], wr[2]])
        return sections

    # 2-element format: (jump_to, jump_from)
    sections = [[ref_from, wrap_word_ranges[0][1]]]
    for i in range(len(wrap_word_ranges) - 1):
        sections.append([wrap_word_ranges[i][0], wrap_word_ranges[i + 1][1]])
    sections.append([wrap_word_ranges[-1][0], ref_to])
    return sections
