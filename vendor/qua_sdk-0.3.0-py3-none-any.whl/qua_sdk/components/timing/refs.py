"""MFA ref construction: aligned segments → the ref grammar the MFA Space accepts.

Port of the aligner's ``_build_mfa_ref``: span refs ("2:255:1-2:255:5"),
special names ("Basmala"), fused prefixes ("Isti'adha+<span>" when the matched
text starts with the Isti'adha/Basmala text — the unsplit fused-segment case),
and reading-sequence list refs for repetition segments (one sub-ref per
recitation pass, reconstructed from ``wrap_word_ranges``). The word-count
cursor helpers join the Space's flat ``words[]`` response back to list-ref
lines. Pure — the quran index is a parameter, never loaded here.
"""

from __future__ import annotations

from qua_sdk.domain import SPECIAL_NAMES, SPECIAL_TEXT, compute_reading_sequence

# The two names the legacy prefix guard recognises — a fused matched_text
# behind any OTHER ref (including span refs) gets the special-name prefix.
_PREFIX_GUARD = frozenset({"basmala", "isti'adha"})


def build_ref(
    matched_ref: str | None,
    matched_text: str,
    wrap_word_ranges: list | None,
) -> str | list[str] | None:
    """The ref to send to the MFA Space for one segment. None = skip.

    Repetition segments (wrap data on a span ref) become ``list[str]`` — a
    reading sequence the Space phonemizes per line and echoes back as a list
    ref. Degenerate sequences (< 2 valid sub-refs) fall back to the union span.
    """
    if not matched_ref:
        return None

    if matched_ref in SPECIAL_NAMES:
        ref_from = ref_to = matched_ref
        rep_ranges = None
    else:
        if "-" in matched_ref:
            ref_from, ref_to = matched_ref.split("-", 1)
        else:
            ref_from = ref_to = matched_ref
        rep_ranges = (
            compute_reading_sequence(ref_from, ref_to, wrap_word_ranges)
            if wrap_word_ranges and "-" in matched_ref else None
        )

    if rep_ranges:
        seq: list[str] = []
        for pair in rep_ranges:
            if not pair or len(pair) < 2:
                continue
            sub_from, sub_to = pair[0], pair[1]
            if not sub_from:
                continue
            seq.append(sub_from if sub_from == sub_to else f"{sub_from}-{sub_to}")
        if len(seq) >= 2:
            return seq
        # degenerate — fall through to the union ref

    mfa_ref = ref_from if ref_from == ref_to else f"{ref_from}-{ref_to}"

    if ref_from.strip().lower() not in _PREFIX_GUARD:
        if matched_text.startswith(SPECIAL_TEXT["Isti'adha"]):
            mfa_ref = f"Isti'adha+{mfa_ref}"
        elif matched_text.startswith(SPECIAL_TEXT["Basmala"]):
            mfa_ref = f"Basmala+{mfa_ref}"

    return mfa_ref


def sub_ref_word_count(sub_ref: str, quran_index) -> int:
    """Number of Quran words a single sub-ref covers (0 = unresolvable)."""
    idx = quran_index.ref_to_indices(sub_ref)
    if idx is None:
        return 0
    g0, g1 = idx
    return g1 - g0 + 1


def word_line_indices(ref: list[str], num_words: int, quran_index) -> list[int]:
    """Line index per response word for a list ref.

    The Space concatenates sub-ref lab content, so its flat ``words[]`` maps
    onto lines by word count: each sub-ref consumes ``sub_ref_word_count``
    words. A budget of 0 (unresolvable sub-ref) advances one word per line so
    keying never starves.
    """
    line_idx = 0
    consumed = 0
    budget = sub_ref_word_count(ref[0], quran_index) if ref else 0
    out: list[int] = []
    for _ in range(num_words):
        while line_idx < len(ref) - 1 and (budget <= 0 or consumed >= budget):
            line_idx += 1
            consumed = 0
            budget = sub_ref_word_count(ref[line_idx], quran_index)
        out.append(line_idx)
        consumed += 1
    return out
