"""Phoneme transforms: phonemizer output → the MFA acoustic model's inventory.

The fixed two-step chain applied to every phoneme before it reaches a .lab
file: ``normalize_phonemes`` (ASCII colon → IPA length marker) then
``transform_phonemes`` (drop qalqala ``Q``, strip emphatics from r/a/l,
split geminates into two identical halves). The same chain is reapplied
per-word during recovery to count how many MFA phones each word consumed.

Qalqala (``Q``) is **model-driven**: a model trained with the qalqala policy
keeps ``Q`` as its own phone, so its lexicon + alignment + recovery must all
keep ``Q`` (else the Q states go unused and boundaries degrade); a plain model
drops it. Which it is comes from the loaded model's phone inventory, threaded in
as a ``keep_q`` flag and published via the :data:`_keep_q` ContextVar around the
align+recover boundary (so it is consistent and survives the worker pool). The
legacy ``QUA_KEEP_Q=1`` env var remains a fallback override when no context is set.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from contextvars import ContextVar

# None → fall back to the QUA_KEEP_Q env var (back-compat / training-lab override).
_keep_q: ContextVar[bool | None] = ContextVar("qua_keep_q", default=None)


def keep_q_enabled() -> bool:
    """Resolve the effective keep-Q decision: context first, then env."""
    ctx = _keep_q.get()
    if ctx is not None:
        return ctx
    return os.environ.get("QUA_KEEP_Q") == "1"


def set_keep_q(value: bool) -> None:
    """Set keep-Q for the current context (process/thread). Used at worker-init
    where there is no enclosing block to reset."""
    _keep_q.set(value)


@contextmanager
def keep_q_context(value: bool):
    """Scope keep-Q to an align+recover block; restores the prior value on exit.
    The correct way to wrap a single model's alignment so concurrent alignments
    with different models (the timing-Space multi-model cache) don't bleed."""
    token = _keep_q.set(value)
    try:
        yield
    finally:
        _keep_q.reset(token)


def normalize_phonemes(text: str) -> str:
    """ASCII colon → IPA length marker ``ː`` (U+02D0): ``a:`` → ``aː``."""
    return text.replace(":", "ː")


def transform_phonemes(text: str) -> str:
    """Token-by-token: drop ``Q``, strip ``rˤ/aˤ/lˤ`` emphatics, split geminates.

    A geminate is any even-length token whose halves are identical AFTER the
    emphatic strip (``ll`` → ``l l``, ``rˤrˤ`` → ``rr`` → ``r r``). ``Q`` is
    kept iff :func:`keep_q_enabled` (model-driven, see module docstring).
    """
    keep_q = keep_q_enabled()
    tokens = text.split()
    result = []
    for tok in tokens:
        if tok == "Q":
            if keep_q:
                result.append(tok)
            continue
        tok = tok.replace("rˤ", "r").replace("aˤ", "a").replace("lˤ", "l")
        n = len(tok)
        if n >= 2 and n % 2 == 0 and tok[: n // 2] == tok[n // 2 :]:
            result.append(tok[: n // 2])
            result.append(tok[n // 2 :])
        else:
            result.append(tok)
    return " ".join(result)
