"""Timing lib: pure ref-preparation + interval-recovery logic.

The alignment-free half of the MFA pipeline, lifted from the MFA Space:
``prepare_ref`` (ref → PreparedRef with lab content), the recovery chain in
``recover_words`` (intervals → word/letter rows), and their building blocks
(transforms, words, letters, word_boundary, specials). Everything here is
runtime-agnostic — no MFA, no audio, no env vars.
"""

from qua_sdk.components.timing.lib.cells import (
    annotate_segment_words,
    annotate_v2_doc,
    detect_segment_bridges,
)
from qua_sdk.components.timing.lib.prepare import (
    PSIL_TOKEN,
    PreparedChunk,
    PreparedRef,
    PreparedVerse,
    merge_refs,
    phonemize_ref,
    prepare_ref,
    prepare_ref_sequence,
    prepare_verse,
)
from qua_sdk.components.timing.lib.recover import flat_entries_for, recover_verse, recover_words
from qua_sdk.components.timing.lib.transforms import (
    keep_q_context,
    keep_q_enabled,
    normalize_phonemes,
    set_keep_q,
    transform_phonemes,
)
from qua_sdk.components.timing.lib.word_boundary import (
    WB_ALLOC_RULES,
    WB_ALLOC_VALUES,
    WB_RULE_DEFAULTS,
    WbChoice,
    apply_word_boundary_allocation,
    detect_cross_word_idgham,
    resolve_word_boundary_allocation,
)
from qua_sdk.components.timing.lib.words import (
    SILENCE_PHONES,
    build_reverse_mapped_intervals,
    build_words_from_mapping,
    is_active_phone,
    nest_phones_in_words,
    pad_intervals,
    serializable_intervals,
)

__all__ = [
    "BRIDGE_RULES", "annotate_segment_words", "annotate_v2_doc", "detect_segment_bridges",
    "PSIL_TOKEN", "PreparedRef", "PreparedVerse", "PreparedChunk", "merge_refs",
    "phonemize_ref", "prepare_ref", "prepare_ref_sequence", "prepare_verse",
    "flat_entries_for", "recover_words", "recover_verse",
    "normalize_phonemes", "transform_phonemes",
    "keep_q_context", "keep_q_enabled", "set_keep_q",
    "WB_ALLOC_RULES", "WB_ALLOC_VALUES", "WB_RULE_DEFAULTS", "WbChoice",
    "apply_word_boundary_allocation", "detect_cross_word_idgham", "resolve_word_boundary_allocation",
    "SILENCE_PHONES", "is_active_phone",
    "build_words_from_mapping", "build_reverse_mapped_intervals",
    "pad_intervals", "nest_phones_in_words", "serializable_intervals",
]


def __getattr__(name: str):
    """Lazily re-export the phonemizer-owned ``BRIDGE_RULES`` from cells without
    importing the phonemizer at lib import (PEP 562; mirrors ``cells.py``)."""
    if name == "BRIDGE_RULES":
        from qua_sdk.components.timing.lib.cells import BRIDGE_RULES as _bridge_rules

        return _bridge_rules
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
