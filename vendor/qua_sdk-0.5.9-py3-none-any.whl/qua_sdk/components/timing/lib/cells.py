"""Cross-word tajweed bridge tagging + per-character cell stamping for shards.

This is the shard-coordinate projector: it maps the phonemizer's cross-word
merger classification + per-character cells onto an aligner's stored shard. The
domain facts — which rules bridge, where each merger sits, the render-only marker
set, the nasalised/geminate phoneme shapes — are owned and exported by the
phonemizer (``tajweed_classification`` / ``phonemes``) and imported here, not
re-declared. What stays here is purely shard-shaped: the indexable-unit coordinate
space, the per-run ``share_group`` offsetting, the "first word holds through the
ghunnah" merger retiming, and every safety guard. The phonemizer is reached
through the SDK ``domain`` wrappers (``cells_for_ref`` / ``silent_flags_for_ref``
/ ``mapping_for_ref``) for the per-ref data, and directly for the pure
classification/predicate functions.

A *bridge* is a cross-word tajweed merger phoneme (idgham) — a nasalised
``m̃ ñ j̃ w̃`` or a geminated consonant (``ll rˤrˤ tt ww …``) that fuses the end
of one word into the start of the next. The Timestamps tab renders it as a tile
between two word blocks.

``annotate_segment_words`` does, in place on a segment's shard word list:

- **Re-attribution** — re-slices the shard's flat phones into words by the
  phonemizer's natural per-word counts. The aligner's word-boundary allocation
  can park a phone on the wrong word (idgham shafawi: مِّن's kasra lands on
  شهداءكم's tail after the merged meem); this restores canonical attribution so
  the FE stays a pure renderer.
- **Tagging** — stamps each merger phone with its rule (slot 5 of the tuple).

It does NOT classify by phoneme shape (a geminate merger is byte-identical to a
within-word shaddah geminate — ``ٱلرَّحْمَٰن → rˤrˤ`` looks exactly like an idgham
``rˤrˤ``). ``detect_cross_word_mergers`` asks the phonemizer where the cross-word
rules fire and this module uses the **flat phoneme index** of each merger.

Indexing runs over *indexable* phones only — the phonemizer's letter-derived
phoneme sequence, excluding the render-only markers an aligner may additionally
store in a shard (the qalqala echo ``Q``, ``is_render_only``). Such a marker
carries no grapheme and never appears in the phonemizer's flat sequence, so the
shard's phones are grouped into units (one indexable phone plus any markers
trailing it) and a bridge index lands on the unit's anchor. This keeps the
detector and the shard in one coordinate space no matter which render-only markers
a given model emits, and the markers ride along with their anchor through
re-attribution untouched.
"""

from __future__ import annotations

import logging

from qua_sdk.domain.char_cells import (
    cells_for_ref,
    mapping_for_ref,
    silent_flags_for_ref,
)

log = logging.getLogger(__name__)

# The cross-word merger classification + detection are owned by the phonemizer
# (its ``tajweed_classification`` registry, keyed to the ``TajweedRule`` enum).
# The SDK consumes them; ``BRIDGE_RULES`` / ``_MERGER_ON_PREV`` are re-exported
# aliases kept for the timing-lib public API and the tests. The phonemizer is a
# heavy, optional dependency, so it is imported lazily (call-local + the module
# ``__getattr__`` below): importing this module — and the whole timing lib —
# must never pull it in (the SDK's "works without the phonemizer" contract,
# enforced by ci.yml's honesty leg).


def __getattr__(name: str) -> frozenset[str]:
    """Lazily resolve the phonemizer-owned re-exports (PEP 562) so importing this
    module stays phonemizer-free. Cached into globals on first access."""
    if name in ("BRIDGE_RULES", "_MERGER_ON_PREV"):
        from quranic_phonemizer import BRIDGE_RULE_VALUES, MERGER_ON_PREV_VALUES

        resolved = {
            "BRIDGE_RULES": BRIDGE_RULE_VALUES,
            "_MERGER_ON_PREV": MERGER_ON_PREV_VALUES,
        }
        globals().update(resolved)
        return resolved[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

# The bridge rule string occupies index 5 of a compact phone tuple
# ``[phone, start_ms, end_ms, geminate_start, geminate_end, bridge_rule]``;
# slots 3/4 (geminate flags, unused in the segment-array shard) are padded so
# the FE reader's fixed positions are preserved.
_BRIDGE_SLOT = 5

def _is_indexable(phone: str) -> bool:
    """A phone that participates in the phonemizer's flat phoneme index: a
    non-empty phone that is not a render-only marker (the qalqala echo ``Q``).
    The phonemizer owns the render-only set, derived from its YAML."""
    from quranic_phonemizer import is_render_only

    return bool(phone) and not is_render_only(phone)


def _looks_like_merger(phone: str) -> bool:
    """A nasalised or geminated phone — the shape every cross-word merger takes.

    A defensive guard at tag time so a future index drift can never silently
    stamp a vowel; the authoritative signal is the rule's flat index. The
    nasalised / geminate predicates are the phonemizer's (single owners)."""
    from quranic_phonemizer import is_geminate, is_nasalised

    return bool(phone) and (is_nasalised(phone) or is_geminate(phone))


def _scan_mapping(mapping) -> tuple[list[tuple[int, str]], list[int]]:
    """Return ``(bridges, counts)`` for a phonemizer ``get_mapping()`` result.

    ``counts[i]`` is word ``i``'s indexable phoneme count — non-indexable phones
    (empty strings, the qalqala ``Q`` marker) are excluded, so the counts re-slice
    the shard's indexable units (see ``_apply_to_words``) exactly.
    ``bridges`` is ``[(flat_phoneme_index, rule), ...]``: shafawi's merger is the
    previous word's last phoneme (``…m̃ |``), every other rule's is the current
    word's first (``| m̃ / | ll …``).

    Uses the phonemizer's natural per-word attribution (``get_mapping``) — NOT
    ``letter_phoneme_mappings()``, which reassigns merger phonemes across word
    boundaries. The flat sequence is allocation-invariant and reproduces the
    shard byte-for-byte. Boundary detection is the phonemizer's single
    ``detect_cross_word_mergers``; this only maps each merger's word + side onto
    the shard's indexable-unit span.
    """
    from quranic_phonemizer import detect_cross_word_mergers

    words = mapping.words
    counts: list[int] = []
    spans: list[tuple[int, int] | None] = []
    acc = 0
    for w in words:
        n = sum(1 for p in w.phonemes if _is_indexable(p))
        counts.append(n)
        spans.append((acc, acc + n - 1) if n else None)
        acc += n

    bridges: list[tuple[int, str]] = []
    for m in detect_cross_word_mergers(mapping):
        on_prev = m.side == "prev"
        span = spans[m.prev_word_index] if on_prev else spans[m.curr_word_index]
        if span is None:
            continue
        bridges.append((span[1] if on_prev else span[0], m.rule))

    return bridges, counts


def detect_segment_bridges(seg_ref: str) -> list[tuple[int, str]]:
    """Return ``[(flat_phoneme_index, rule), ...]`` for one segment ref."""
    return _scan_mapping(mapping_for_ref(seg_ref))[0]


def _scan_segment(
    seg_ref: str, n_words: int,
    wasl_prev_ref: str | None, wasl_cont_ref: str | None,
) -> tuple[list[tuple[int, str]], list[int]]:
    """``(bridges, counts)`` for a segment's words, phonemized in waṣl-CONTINUATION
    form when an adjacent ref is supplied — so the per-word counts match a shard
    aligned across the join (its stored phones reflect the continuation, not the
    isolated waqf form). Without waṣl context this is the plain segment scan.

    Re-attribution needs this: a waṣl-continued segment's shard carries the
    continuation tanwīn/merger, so the bare waqf seg-ref scan diverges by a phone
    and the count guard drops the run (e.g. a repeated verse waṣl'd into the next).
    The cross-verse merger realized on the appended continuation word is sliced off
    (the FE synthesizes that junction tile); only the segment's own words' bridges +
    counts are returned, re-based to its first indexable unit.
    """
    if not (wasl_prev_ref or wasl_cont_ref):
        return _scan_mapping(mapping_for_ref(seg_ref))
    ref, skip = _extend_ref(seg_ref, wasl_prev_ref, wasl_cont_ref)
    ext_bridges, ext_counts = _scan_mapping(mapping_for_ref(ref))
    if len(ext_counts) < skip + n_words:
        return _scan_mapping(mapping_for_ref(seg_ref))  # shape off — don't mis-slice
    off = sum(ext_counts[:skip])
    counts = ext_counts[skip:skip + n_words]
    hi = off + sum(counts)
    bridges = [(fi - off, rule) for fi, rule in ext_bridges if off <= fi < hi]
    return bridges, counts


def annotate_segment_words(
    verse_key: str, words: list,
    wasl_prev_ref: str | None = None, wasl_cont_ref: str | None = None,
) -> int:
    """Tag bridges + canonicalise phone attribution on one segment, in place.

    ``wasl_prev_ref`` / ``wasl_cont_ref`` (single-word refs of the waṣl-adjacent
    verse) extend the cell-stamp phonemization across the join so a continued
    segment's boundary cells are derived in continuation — not waqf — form,
    matching the stored waṣl phones (otherwise the per-run waqf re-derive diverges
    by one phone and the whole boundary run renders without a letter row).

    ``words`` is a segment's word list as written to the shard — each word is
    ``[widx, start_ms, end_ms, [[char,s,e]...], [[phone,s,e]...]]`` in ascending,
    contiguous word order. ``verse_key`` is the segment's home verse (``"2:48"``).

    Three effects, all anchored to the phonemizer (the single source of truth):

    1. **Re-attribution** — the shard's flat phones are re-sliced into words by
       the phonemizer's natural per-word counts. The aligner's word-boundary
       allocation can park a phone on the wrong word (idgham shafawi: مِّن's kasra
       lands on شهداءكم after the merged meem); this restores each phone to its
       word so the FE stays a pure renderer. Word start/end are recomputed.
    2. **Tagging** — the merger phone grows to length 6 with its rule at slot 5
       (``[phone, start, end, None, None, rule]``; slots 3/4 are the FE reader's
       geminate flags).
    3. **Silent flags + marks** — each letter grows a 4th slot ``silent`` (bool)
       and its silence combining mark (SILENT_ALWAYS / SILENT_AT_CONTINUATION) is
       folded onto its char, from the phonemizer's ``silent_flags()``, so the
       highlight skips silent graphemes and shows the mark. Stamped over
       gap-bounded runs (any timing gap is a stop), so a silah drops at waqf and
       every occurrence is stamped — independent of the bridge guard below.

    Returns the number of phones tagged. Skips (returns 0, no mutation) for
    repeats / out-of-order words, or if the phonemizer shape doesn't match the
    shard (indexable-unit count or word count) — a safety guard that never
    corrupts; a drop with bridges in hand is logged, never silent.
    """
    if not words:
        return 0
    # Effect 3 runs first, independent of the bridge guard below, over gap-bounded
    # runs — so repeats/partials are never NO-SLOT and a silah at a stop drops.
    _stamp_silent_flags(verse_key, words)
    widxs = [wd[0] for wd in words]
    if widxs != list(range(widxs[0], widxs[0] + len(widxs))):
        return 0
    lo, hi = widxs[0], widxs[-1]
    seg_ref = f"{verse_key}:{lo}" if lo == hi else f"{verse_key}:{lo}-{verse_key}:{hi}"
    bridges, counts = _scan_segment(seg_ref, len(words), wasl_prev_ref, wasl_cont_ref)
    tagged = _apply_to_words(words, bridges, counts)
    if bridges and not tagged:
        # The shape guard tripped with bridges in hand — render-only markers are
        # handled, so this is genuine phonemizer/shard drift. Surface it; a silent
        # drop here is exactly how the qalqala-``Q`` regression hid for so long.
        log.warning(
            "bridge drift: %s detected %d bridge(s) but applied 0 (phonemizer "
            "shape != shard shape)", seg_ref, len(bridges)
        )
    # Effect 4 — per-character (haraka/tanween) cells (schema v5). Runs after
    # re-attribution so each word's indexable phones match the phonemizer's
    # per-word counts; stamps over gap-bounded runs so stop-sensitive cells
    # (dropped tanween, madd-iwad, iltiqaa) resolve correctly at waqf — or in
    # continuation form across a waṣl join when the adjacent refs are supplied.
    _stamp_cells(verse_key, words, wasl_prev_ref=wasl_prev_ref, wasl_cont_ref=wasl_cont_ref)
    return tagged


def _next_verse_key(verse_key: str) -> str | None:
    """``"1:3"`` → ``"1:4"``; None if unparseable. A cross-verse waṣl always
    continues into the immediately-following verse, so adjacency is verse+1."""
    try:
        surah, ayah = verse_key.split(":")
        return f"{surah}:{int(ayah) + 1}"
    except ValueError:
        return None


def _extend_ref(base: str, prev_ref: str | None, cont_ref: str | None) -> tuple[str, int]:
    """Extend a run ref into its waṣl-adjacent word(s) so the boundary phonemizes
    in continuation form (matching the stored waṣl phones). ``prev_ref`` / ``cont_ref``
    are single-word refs of the adjacent verse (``"1:3:2"`` / ``"1:4:1"``). Returns
    ``(ref, skip)`` where ``skip`` is the leading words to drop from the phonemizer
    output (the prepended ``prev_ref`` word; the trailing ``cont_ref`` word is just
    not kept by the caller's ``[skip:skip+len(run)]`` slice)."""
    if not prev_ref and not cont_ref:
        return base, 0
    start = (prev_ref or base).split("-", 1)[0]
    end = (cont_ref or base).rsplit("-", 1)[-1]
    return f"{start}-{end}", (1 if prev_ref else 0)


def _gap_runs(words: list) -> list:
    """Split ``words`` into maximal runs contiguous in BOTH widx and time. A run
    breaks at any widx discontinuity (repeat / out-of-order) or any timing gap —
    and a gap is a stop (the shard is contiguous except at a waqf), so each run is
    one gap-bounded recitation unit whose last word stops."""
    runs: list = []
    run: list = []
    for wd in words:
        if run and (wd[0] != run[-1][0] + 1 or wd[1] != run[-1][2]):
            runs.append(run)
            run = []
        run.append(wd)
    if run:
        runs.append(run)
    return runs


def _stamp_silent_flags(verse_key: str, words: list) -> None:
    """Stamp each letter's 4th ``silent`` bool and fold its silence mark onto its
    char, in place, from the phonemizer's ``silent_flags()``.

    Walks gap-bounded runs (see ``_gap_runs``) and phonemizes each on its own ref,
    so the run's last word is naturally stopping — a silah drops at waqf — and
    every occurrence is stamped even when the bridge guard bails (repeats /
    out-of-order). Per-run no-op on any char-misalignment so a phonemizer/shard
    mismatch can never corrupt a letter.
    """
    for run in _gap_runs(words):
        lo, hi = run[0][0], run[-1][0]
        ref = f"{verse_key}:{lo}" if lo == hi else f"{verse_key}:{lo}-{verse_key}:{hi}"
        flags = silent_flags_for_ref(ref)
        letters = [lt for wd in run for lt in wd[3]]
        if [c for c, _s, _m in flags] != [lt[0] for lt in letters]:
            continue
        for lt, (_c, silent, mark) in zip(letters, flags, strict=True):
            if len(lt) <= 3:
                lt.append(silent)
            else:
                lt[3] = silent
            if mark:
                lt[0] = lt[0] + mark


def _stamp_cells(
    verse_key: str, words: list,
    wasl_prev_ref: str | None = None, wasl_cont_ref: str | None = None,
) -> int:
    """Stamp each word's 6th slot ``cells`` (schema v5) from the phonemizer's
    ``character_phoneme_mappings()``, in place. Returns the number of words stamped.

    Walks gap-bounded runs (see ``_gap_runs``) and phonemizes each on its own ref,
    so stop-sensitive cells (dropped tanween / madd-iwad / iltiqaa) resolve at the
    run's natural waqf. When the segment is **waṣl**-connected, ``wasl_cont_ref``
    (next verse's first word) extends the LAST run forward and ``wasl_prev_ref``
    (prev verse's last word) extends the FIRST run backward, so the boundary word
    phonemizes in *continuation* form — matching the stored waṣl phones, instead of
    a per-run waqf re-derive that diverges by one phone and drops the whole run's
    cells. ALL cell roles are written — base consonants, haraka,
    tanween, madd, implicit — so a consumer can render the full per-character
    breakdown from the shard alone. Cell ``phoneme_indices`` are re-expressed in
    the shard's **indexable-phone** coordinate space (the qalqala ``Q`` excluded —
    same as ``_is_indexable``/bridges), so they line up with the word's phones
    whether or not a model stores render-only markers.

    Each cell row is ``[chars, role, status, phoneme_indices, source_letter_index,
    tag, share_group]`` plus an OPTIONAL 8th slot ``phoneme_rule_tags`` — a list
    parallel to the remapped ``phoneme_indices`` carrying the phonemizer's
    per-phoneme tajweed rule (the muqaṭṭaʿāt case: a bare letter sounding out a
    multi-rule name). It rides the same indexable remap as the indices (a dropped
    render-only phoneme drops its tag too), and is appended only when at least one
    entry is non-null, so v7 readers tolerating a missing slot keep working.

    Per-run no-op (no partial write) on any word-count or per-word indexable-count
    mismatch, so a phonemizer/shard divergence can never write a dangling index.

    ``share_group`` ids are offset per run so they stay unique across a segment
    (each run is phonemized independently and numbers its groups from 0); a
    consumer renders one segment/verse at a time, so segment-unique is enough.
    """
    stamped = 0
    gid_base = 0
    runs = _gap_runs(words)
    for ri, run in enumerate(runs):
        lo, hi = run[0][0], run[-1][0]
        base = f"{verse_key}:{lo}" if lo == hi else f"{verse_key}:{lo}-{verse_key}:{hi}"
        # The waṣl boundary lives at the segment edge: extend the LAST run forward
        # (cont) and the FIRST run backward (prev) into the adjacent verse so the
        # junction word phonemizes continuously; ``skip`` drops the prepended word.
        ref, skip = _extend_ref(
            base, wasl_prev_ref if ri == 0 else None,
            wasl_cont_ref if ri == len(runs) - 1 else None,
        )
        cpm = cells_for_ref(ref)
        cwords = cpm.words[skip:skip + len(run)]
        wmaps = cpm.mapping.words[skip:skip + len(run)]
        if len(cwords) != len(run):
            # Word-count drift between the phonemizer and the shard — the run
            # renders without per-letter cells (FE "snap"). Never silent: a quiet
            # drop here is exactly how the qalqala-``Q`` regression hid (see the
            # bridge-drift warning in ``annotate_segment_words``).
            log.warning(
                "cell drift: %s dropped cells — phonemizer has %d word(s), shard "
                "has %d; run renders without per-letter cells",
                ref, len(cwords), len(run),
            )
            continue
        staged: list[tuple[list, list]] = []
        ok = True
        mismatch: tuple[int, int, int] | None = None
        for cw, wm, wd in zip(cwords, wmaps, run):
            # map raw word.phonemes index -> word-local indexable index (skip Q)
            idx_map: dict[int, int] = {}
            k = 0
            for i, p in enumerate(wm.phonemes):
                if _is_indexable(p):
                    idx_map[i] = k
                    k += 1
            stored_k = sum(1 for ph in wd[4] if _is_indexable(ph[0]))
            if stored_k != k:
                mismatch = (wd[0], stored_k, k)
                ok = False
                break
            rows: list = []
            for c in cw.cells:
                si: list[int] = []
                # per-phoneme rule tags ride parallel to ``si`` — an entry is
                # carried only when its phoneme survives the indexable remap (the
                # render-only ``Q`` is dropped, taking its tag with it) and isn't a
                # dup. ``phoneme_rule_tags`` is set only on muqaṭṭaʿāt cells; an
                # empty list (the common case) leaves slot 7 absent so the FE
                # falls back to the single ``tag``.
                prt_src = c.phoneme_rule_tags or []
                prt: list = []
                for k, i in enumerate(c.phoneme_indices):
                    j = idx_map.get(i)
                    if j is not None and j not in si:
                        si.append(j)
                        prt.append(prt_src[k] if k < len(prt_src) else None)
                row = [c.chars, c.role, c.status, si,
                       c.source_letter_index, c.tag, c.share_group]
                # slot 7 = phoneme_rule_tags, slot 8 = secondary_tags (heaviness
                # stacked on the primary ``tag``). Both optional; when only the
                # secondary is present, slot 7 is padded ``None`` so slot 8 stays
                # position-stable for a positional reader.
                has_prt = any(t is not None for t in prt)
                sec = list(c.secondary_tags or [])
                if has_prt or sec:
                    row.append(prt if has_prt else None)
                if sec:
                    row.append(sec)
                rows.append(row)
            staged.append((wd, rows))
        if not ok:
            # Per-word indexable-phone-count drift: the phonemizer's count for a
            # word ≠ the shard's stored count, so the whole run's cells are
            # dropped (the FE falls back to a synthetic base and snaps every phone
            # onto the first letter). Surface it — a silent drop reads as "no
            # cells here" instead of "this shard's phones disagree with the
            # phonemizer". Cause is a shard phonemized in a different waqf/ibtidāʾ
            # context than the per-run stamper (run boundary), a cross-word
            # re-attribution, or a phonemizer change since the shard was aligned.
            if mismatch is not None:
                log.warning(
                    "cell drift: %s dropped cells — word %d stored %d indexable "
                    "phone(s) but phonemizer produced %d; run renders without "
                    "per-letter cells",
                    ref, mismatch[0], mismatch[1], mismatch[2],
                )
            continue
        # Offset this run's share_group ids so they're unique across the segment.
        groups = sorted({r[6] for _wd, rows in staged for r in rows if r[6] is not None})
        remap = {g: gid_base + i for i, g in enumerate(groups)}
        gid_base += len(groups)
        for wd, rows in staged:
            for r in rows:
                if r[6] is not None:
                    r[6] = remap[r[6]]
            while len(wd) <= 5:
                wd.append(None)
            wd[5] = rows
            stamped += 1
    return stamped


def _retime(word: list) -> None:
    """Set a word's start/end (slots 1/2) from its first/last phone."""
    phones = word[4]
    if phones:
        word[1] = phones[0][1]
        word[2] = phones[-1][2]


def _segment_units(words: list) -> list[list[list]]:
    """Group a segment's phones into indexable units across word order.

    Each unit is ``[anchor, *render_only_markers]`` — one indexable phone followed
    by any render-only markers (``Q``) that trail it. The unit sequence is the
    phonemizer's coordinate space (``counts`` index it), while every phone object
    is preserved in order so re-slicing the units back into words keeps the
    markers attached to their anchor. A leading marker with no anchor yet (never
    expected) seeds its own unit so nothing is dropped."""
    units: list[list[list]] = []
    for wd in words:
        for ph in wd[4]:
            if not ph[0]:
                continue
            if _is_indexable(ph[0]) or not units:
                units.append([ph])
            else:
                units[-1].append(ph)
    return units


def _apply_to_words(words: list, bridges: list[tuple[int, str]], counts: list[int]) -> int:
    """Re-slice ``words``' phones to ``counts`` and stamp ``bridges``, in place.

    ``counts`` is the phonemizer's per-word indexable-phone count; ``bridges`` is
    ``[(unit_index, rule), ...]``. Both index the segment's indexable *units* (an
    indexable phone plus any render-only markers trailing it — see
    ``_segment_units``), so a stored qalqala ``Q`` rides along instead of skewing
    the index. No-op + return 0 when the shapes don't line up with the shard
    (guards against corrupting on genuine phonemizer drift).

    The merger's *duration* is always owned by the FIRST word of the boundary so
    word highlighting / clips stay on it through the ghunnah: shafawi already
    lands on the prev word's tail, and for the head-merger rules (idgham
    ghunnah/bila-ghunnah …) the curr word's start is pushed past the merger and
    the prev word's end is extended to the merger's end. Phone attribution is
    untouched — the merger phone keeps its tag and renders in the bridge tile."""
    if len(counts) != len(words):
        return 0
    units = _segment_units(words)
    if sum(counts) != len(units):
        return 0

    tagged = 0
    for fidx, rule in bridges:
        if 0 <= fidx < len(units) and _looks_like_merger(units[fidx][0][0]):
            ph = units[fidx][0]
            while len(ph) <= _BRIDGE_SLOT:
                ph.append(None)
            ph[_BRIDGE_SLOT] = rule
            tagged += 1

    off = 0
    head_to_word: dict[int, int] = {}
    for wi, c in enumerate(counts):
        head_to_word[off] = wi
        words[wi][4] = [ph for unit in units[off : off + c] for ph in unit]
        off += c
        _retime(words[wi])

    from quranic_phonemizer import MERGER_ON_PREV_VALUES as _MERGER_ON_PREV

    for fidx, rule in bridges:
        if rule in _MERGER_ON_PREV:
            continue  # merger is the prev word's tail → first word already owns it
        if not (0 <= fidx < len(units)) or not _looks_like_merger(units[fidx][0][0]):
            continue
        w = head_to_word.get(fidx)  # head-merger rules land the merger at a word head
        if not w:  # None (not a head) or 0 (no prev word) → leave as-is
            continue
        cur = words[w][4]
        if len(cur) < 2:
            continue  # fully-dissolving word: nothing left to own its own span
        words[w - 1][2] = units[fidx][0][2]  # first word holds through the ghunnah
        words[w][1] = cur[1][1]  # second word starts at its next phone
    return tagged


def _cross_segment_merger_retime(prev_words: list, curr_words: list) -> None:
    """Cross-SEGMENT analogue of the head-merger retime in ``_apply_to_words``.

    A cross-verse (or split-verse) waṣl head-merger — idgham ghunnah/bila-ghunnah —
    lands the nasalised/geminate phone on THIS segment's first word (its own
    grapheme's word, where the cell stamps), but the merger's DURATION belongs to
    the previous word (the nūn/tanwīn word), exactly as the intra-segment retime
    gives it to ``words[w-1]``. ``_apply_to_words`` can't reach it: the bridge lands
    on word 0 (``w==0``, no in-segment predecessor) and the previous word lives in
    another segment's list. Reach across here — extend the previous segment's last
    word's end through the merger and start this word past it, so word highlighting
    holds through the ghunnah. Phone objects, letters, and cells are untouched (the
    merger stays on its letter; only the two boundary words' start/end move).

    Prev-side mergers (shafawi ``m̃`` on the previous word's tail) already sit on the
    previous word, so they are skipped.
    """
    if not prev_words or not curr_words:
        return
    phones = curr_words[0][4] if len(curr_words[0]) > 4 else []
    if not phones:
        return
    head = phones[0]
    rule = head[_BRIDGE_SLOT] if len(head) > _BRIDGE_SLOT else None
    if not rule:
        return
    from quranic_phonemizer import MERGER_ON_PREV_VALUES as _MOP

    if rule in _MOP:
        return
    prev_words[-1][2] = head[2]      # previous word holds through the ghunnah
    if len(phones) >= 2:
        curr_words[0][1] = phones[1][1]  # this word starts past the merger


def annotate_ordered_segments(seq: list[tuple[str, list, bool]]) -> int:
    """Bridge-tag + waṣl-aware cell-stamp segments already in RECITATION order.

    ``seq`` is ``[(verse_key, words, wasl), ...]`` in the order recited, where
    ``wasl`` marks a segment that continues into the next without a stop. Each
    waṣl boundary is linked to its adjacent word (``wasl_prev_ref`` /
    ``wasl_cont_ref``) so the boundary cells derive in continuation form and don't
    drop. Shared by ``annotate_v2_doc`` (v2 occurrences) and the shard cell
    re-stamp (ordered shard segments) so both thread waṣl identically.
    """
    total = 0
    for i, (verse_key, words, wasl) in enumerate(seq):
        prev_ref = cont_ref = None
        # continuation TARGET: the previous segment waṣl-continued into this one —
        # the next verse (cross-verse waṣl) OR the same verse (a split verse recited
        # without a stop, so the join is mid-verse).
        if i > 0 and seq[i - 1][2]:
            pvk, pwords, _ = seq[i - 1]
            if pwords and (pvk == verse_key or _next_verse_key(pvk) == verse_key):
                prev_ref = f"{pvk}:{pwords[-1][0]}"
        # continues FORWARD: waṣl into the next consecutive verse OR the next part of
        # the same split verse.
        if wasl and i + 1 < len(seq):
            nvk, nwords, _ = seq[i + 1]
            if nwords and (nvk == verse_key or _next_verse_key(verse_key) == nvk):
                cont_ref = f"{nvk}:{nwords[0][0]}"
        total += annotate_segment_words(
            verse_key, words, wasl_prev_ref=prev_ref, wasl_cont_ref=cont_ref,
        )
        # A waṣl head-merger at this segment's first word holds its ghunnah duration
        # on the previous segment's last word (cross-segment retime _apply_to_words
        # can't do from word 0).
        if prev_ref and i > 0 and seq[i - 1][1]:
            _cross_segment_merger_retime(seq[i - 1][1], words)
    return total


def annotate_v2_doc(v2_doc: dict) -> int:
    """Stamp bridge tags across every occurrence of a raw v2 document, in place.

    ``v2_doc`` is the ``build_raw_v2`` shape (``{output_key: [occurrence, ...]}``
    plus ``_meta``). Each occurrence's ``words_by_verse`` carries one verse's
    words; an occurrence's ``wasl`` flag (v10) marks it as continuing into the next
    verse without a stop. Returns the total number of phones tagged.

    Occurrences are flattened and sorted into RECITATION order (chapter, then the
    first word's start time) before linking — v2_doc groups occurrences by
    output_key, so a repeated/retaken verse would otherwise sit next to its own
    other take instead of the verse it waṣl-continues into, and the join wouldn't
    link. Sorted, a waṣl-continued segment hands the cell-stamper the adjacent
    verse's boundary word and the join phonemizes continuously.
    """
    rows: list[tuple[int, int, str, list, bool]] = []
    for key, occs in v2_doc.items():
        if key == "_meta" or not isinstance(occs, list):
            continue
        for occ in occs:
            wasl = bool(occ.get("wasl"))
            for verse_key, words in (occ.get("words_by_verse") or {}).items():
                if not words:
                    continue
                try:
                    ch = int(verse_key.split(":")[0])
                except (ValueError, IndexError):
                    ch = 0
                rows.append((ch, words[0][1], verse_key, words, wasl))
    rows.sort(key=lambda r: (r[0], r[1]))  # recitation order: chapter, first-word start
    seq = [(vk, w, wasl) for _ch, _t, vk, w, wasl in rows]
    return annotate_ordered_segments(seq)
