"""Capability components (L2). Each = spec (pure contract) + runtimes.

Fake runtimes register eagerly (pure python, power the conformance harness).
Real runtimes register lazily — torch/transformers load only when resolved.
"""

from qua_sdk.registry import register, register_lazy

from qua_sdk.components.segmentation.runtimes.fake import FakeSegmenter
from qua_sdk.components.recognition.runtimes.fake import FakeRecognizer
from qua_sdk.components.matching.runtimes.fake import FakeMatcher
from qua_sdk.components.timing.runtimes.fake import FakeTiming

register("segmentation.fake@v1", FakeSegmenter())
register("recognition.fake@v1", FakeRecognizer())
register("matching.fake@v1", FakeMatcher())
register("timing.fake@v1", FakeTiming())

# Real runtimes register lazily (heavy deps load on first resolve); keys stay
# stable across the aligner migration. ``extra`` names the pip extra that
# provides each runtime's heavy deps (matching's deps are core, no extra).
register_lazy("segmentation.recitation_v2@v1",
              "qua_sdk.components.segmentation.runtimes.eager:RecitationSegmenter", extra="vad")
register_lazy("recognition.w2v2_ctc@v1",
              "qua_sdk.components.recognition.runtimes.eager:W2v2CtcRecognizer", extra="asr")
register_lazy("matching.wraparound_dp@v1",
              "qua_sdk.components.matching.runtimes.runtime:WraparoundDpMatcher")
register_lazy("timing.mfa_remote@v1",
              "qua_sdk.components.timing.runtimes.remote_space:MfaRemoteSpace", extra="timing")
register_lazy("timing.mfa_local@v1",
              "qua_sdk.components.timing.runtimes.mfa_local:MfaLocalAligner", extra="mfa")
