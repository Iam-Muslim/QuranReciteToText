"""Recovery: raw MFA phone intervals + PreparedRef → word (and letter) rows.

The order inside ``recover_words`` is load-bearing for parity: words from raw
intervals → reverse-map (geminate merge, original names) → gap padding (in
place) → word-boundary allocation → padded-boundary refit → letters. Letter
failure is soft: the item degrades to word-only rows (no ``letters`` key,
2dp start/end) instead of erroring.
"""

from __future__ import annotations

import logging
import time

from qua_sdk.components.timing.lib.specials import SPECIAL_FLAT_MAPPINGS, SPECIAL_KEYS, SPECIAL_PHONEMES
from qua_sdk.components.timing.lib.letters import build_letter_timestamps, group_letters_by_word
from qua_sdk.components.timing.lib.prepare import PSIL_TOKEN, PreparedRef, PreparedVerse
from qua_sdk.components.timing.lib.word_boundary import (
    apply_word_boundary_allocation,
    resolve_word_boundary_allocation,
)
from qua_sdk.components.timing.lib.words import (
    build_reverse_mapped_intervals,
    build_words_from_mapping,
    is_active_phone,
    nest_phones_in_words,
    pad_intervals,
)

logger = logging.getLogger(__name__)


def flat_entries_for(prep: PreparedRef) -> tuple[list[tuple[str, list[str]]], list[str]]:
    """Assemble (flat_entries, phoneme_sequence) for letter recovery.

    Special prefixes contribute their authored flat mappings with the LAST
    entry's chars given a trailing space (word boundary into what follows);
    the verse portion appends the phonemizer's letter-phoneme mapping. The
    authored mapping lists are copied before mutation.
    """
    from quranic_phonemizer.letter_phoneme_mapping import build_letter_phoneme_mapping

    if prep.is_special_only and not prep.special_prefixes:
        special_key = SPECIAL_KEYS.get(prep.ref.strip().lower())
        flat_entries = SPECIAL_FLAT_MAPPINGS[special_key]
        phoneme_sequence = list(SPECIAL_PHONEMES[special_key])
    elif prep.is_special_only and prep.special_prefixes:
        flat_entries = []
        phoneme_sequence = []
        for sp_name in prep.special_prefixes:
            entries = list(SPECIAL_FLAT_MAPPINGS[sp_name])
            if entries:
                last_chars, last_phonemes = entries[-1]
                entries[-1] = (last_chars + " ", last_phonemes)
            flat_entries.extend(entries)
            phoneme_sequence.extend(SPECIAL_PHONEMES[sp_name])
    elif prep.special_prefixes:
        flat_entries = []
        phoneme_sequence = []
        for sp_name in prep.special_prefixes:
            entries = list(SPECIAL_FLAT_MAPPINGS[sp_name])
            if entries:
                last_chars, last_phonemes = entries[-1]
                entries[-1] = (last_chars + " ", last_phonemes)
            flat_entries.extend(entries)
            phoneme_sequence.extend(SPECIAL_PHONEMES[sp_name])
        flat_entries.extend(build_letter_phoneme_mapping(prep.verse_mapping, words=prep.verse_words))
        for w in prep.verse_words:
            phoneme_sequence.extend(w.phonemes)
    else:
        flat_entries = build_letter_phoneme_mapping(prep.verse_mapping, words=prep.all_words)
        phoneme_sequence = []
        for w in prep.all_words:
            phoneme_sequence.extend(w.phonemes)
    return flat_entries, phoneme_sequence


def recover_words(
    intervals: list[dict],
    prep: PreparedRef,
    include_letters: bool = False,
    padding: str = "forward",
    word_boundary_allocation: dict | None = None,
) -> tuple[list[dict], dict, list[dict]]:
    """Map MFA phone intervals back to words (and optionally letters).

    Returns ``(words, timing, mapped_intervals)`` — mapped_intervals has
    geminates merged, original phoneme names restored, and padding applied.
    ``timing`` carries stage seconds plus the detected ``cross_word_merges``
    and the ``wb_allocation_applied`` dict (the batch surface echoes both).

    padding: "forward" | "symmetric" | "none".
    word_boundary_allocation: resolved per-rule {rule: choice} dict; ``None``
    resolves to the system rule defaults (env-var layering is the caller's
    job — inject via ``resolve_word_boundary_allocation`` upstream).
    """
    timing: dict = {"flat_map": 0.0, "words": 0.0, "letters": 0.0}

    t0 = time.time()
    words_out = build_words_from_mapping(intervals, prep.all_words)
    timing["words"] = time.time() - t0

    # Reverse-map: merge split geminates, restore original phoneme names
    mapped_intervals = build_reverse_mapped_intervals(intervals, words_out) if words_out else intervals

    # Pad gaps at the phoneme level — letters and per-word phones inherit this
    pad_intervals(mapped_intervals, strategy=padding)

    # Reallocate cross-word boundary phones per rule before the boundary
    # refit below picks up the updated phone_indices.
    if word_boundary_allocation is None:
        word_boundary_allocation = resolve_word_boundary_allocation(None)
    detected_merges = prep.cross_word_merges or []
    timing["cross_word_merges"] = detected_merges  # surfaced for API debug
    timing["wb_allocation_applied"] = dict(word_boundary_allocation) if word_boundary_allocation else {}
    if word_boundary_allocation:
        logger.debug("wb_alloc: %d cross-word events for ref=%s (alloc=%s)",
                     len(detected_merges), prep.ref, word_boundary_allocation)
        apply_word_boundary_allocation(
            words_out,
            detected_merges,
            prep.all_words,
            mapped_intervals,
            word_boundary_allocation,
        )

    # Update word boundaries to match padded phone ranges
    if padding != "none":
        for w in words_out:
            active = [
                mapped_intervals[pi] for pi in w.get("phone_indices", [])
                if pi < len(mapped_intervals) and is_active_phone(mapped_intervals[pi].get("phone"))
            ]
            if active:
                w["start"] = active[0]["start"]
                w["end"] = active[-1]["end"]

    if include_letters:
        try:
            t0 = time.time()
            flat_entries, phoneme_sequence = flat_entries_for(prep)
            timing["flat_map"] = time.time() - t0

            t0 = time.time()
            letter_groups = build_letter_timestamps(mapped_intervals, flat_entries, phoneme_sequence)
            words_with_letters = group_letters_by_word(letter_groups, words_out)
            timing["letters"] = time.time() - t0

            return words_with_letters, timing, mapped_intervals

        except Exception as e:
            logger.warning("Failed to build letter timestamps for %s: %s", prep.ref, e)

    result = [
        {
            "location": w["location"],
            "text": w["text"],
            "start": round(w["start"], 2),
            "end": round(w["end"], 2),
            "phone_indices": w.get("phone_indices", []),
        }
        for w in words_out
    ]
    return result, timing, mapped_intervals


def _combined_prepared(prepared_verse: PreparedVerse) -> PreparedRef:
    """A word-only PreparedRef over all the item's chunk words (no letters) —
    the count-partition fallback when psil markers don't line up."""
    all_words = [w for ch in prepared_verse.chunks for w in ch.prepared.all_words]
    return PreparedRef(
        ref=list(prepared_verse.segment_refs), all_words=all_words,
        lab_content=prepared_verse.lab_content, verse_mapping=None,
    )


def recover_verse(
    intervals: list[dict],
    prepared_verse: PreparedVerse,
    *,
    include_letters: bool = True,
    padding: str = "forward",
    word_boundary_allocation: dict | None = None,
) -> list[dict]:
    """Split ONE whole-verse alignment back into per-segment word/letter rows.

    With psil seeding the aligned intervals carry a ``psil`` phone at the
    verse-start, every inter-segment boundary, and verse-end. This cuts the
    interval stream at those markers and runs the existing per-segment
    ``recover_words`` on each slice — so each segment's rows + letters come out
    exactly as the per-segment path would, except the boundary phones no longer
    absorb the pause (it now sits on psil, recoverable as the gap between
    adjacent words). Times stay in the verse-local frame of ``intervals``.

    Returns ``[{"ref": str, "words": [...]}, ...]`` in segment order. The interval
    stream is cut at the psil markers into one slice per CHUNK; each chunk's
    recovered words (a waṣl chunk spans >1 segment, phonemized continuously) are
    split back to per-segment rows by word count. If the psil markers don't match
    ``len(chunks)+1`` (a dropped/extra marker, or ``seed_psil`` off) it degrades
    to a single word-only recovery partitioned by each segment's word count.
    """
    chunks = prepared_verse.chunks
    nC = len(chunks)
    psil_idx = [i for i, iv in enumerate(intervals) if iv.get("phone") == PSIL_TOKEN]

    def _split_chunk(words: list, chunk) -> list[dict]:
        rows, cursor = [], 0
        for ref, cnt in zip(chunk.seg_refs, chunk.seg_word_counts):
            rows.append({"ref": ref, "words": words[cursor:cursor + cnt]})
            cursor += cnt
        return rows

    if prepared_verse.seed_psil and len(psil_idx) == nC + 1:
        out = []
        for k in range(nC):
            sl = intervals[psil_idx[k] + 1: psil_idx[k + 1]]
            words, _, mapped = recover_words(
                sl, chunks[k].prepared, include_letters=include_letters,
                padding=padding, word_boundary_allocation=word_boundary_allocation,
            )
            nest_phones_in_words(words, mapped)  # phones tier, parity with run_batch
            out.extend(_split_chunk(words, chunks[k]))
        return out

    logger.warning(
        "recover_verse: %d psil markers != %d (chunks+1) for %s — count-partition fallback",
        len(psil_idx), nC + 1, prepared_verse.segment_refs,
    )
    words, _, mapped = recover_words(
        intervals, _combined_prepared(prepared_verse), include_letters=False,
        padding=padding, word_boundary_allocation=word_boundary_allocation,
    )
    nest_phones_in_words(words, mapped)
    out, cursor = [], 0
    for ch in chunks:
        for ref, cnt in zip(ch.seg_refs, ch.seg_word_counts):
            out.append({"ref": ref, "words": words[cursor:cursor + cnt]})
            cursor += cnt
    return out
