"""SdkModel: the shared pydantic base — unknown/typo'd fields always raise.

Every pydantic model in the SDK (schemas, params, profiles, deploy, task
decls) inherits this. ``extra="forbid"`` makes provenance loud: a field a
model doesn't know is an error, never silently ignored — the trap this kills
is a subclass dump "validating" against its base with the method knobs
dropped. Subclasses may extend ``model_config`` (pydantic merges it).
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class SdkModel(BaseModel):
    model_config = ConfigDict(extra="forbid")
