"""Matching: best-path correspondence over a graph (was: "DP").

Contract: ``Matcher.match(Emissions, Regions, MatchingParams, chapter_hint=...,
deploy=...) -> Alignment``. Anchoring is a CAPABILITY of this component, not a
pipeline stage — the matcher anchors to a chapter from emissions (n-gram
voting) and may re-anchor mid-sequence on consecutive failures or chapter
transitions. ``chapter_hint`` is per-call input (extraction knows its surah);
the anchor knobs live here because they change results. Specials detection
(Basmala/Isti'adha/transitions) is also internal — output segments may merge
or split relative to input regions; ids are the join key.

Plug points: inventory (domain), search strategy (runtime key). Today's impl
is windowed wraparound edit-distance (loopback = self-loops); skip-ahead /
streaming are new runtime keys (+ a MatchingParams subclass for their knobs),
not new components.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from pydantic import field_validator

from qua_sdk.schemas import Alignment, Emissions, Regions
from qua_sdk.schemas.base import SdkModel


class AnchorParams(SdkModel):
    """N-gram chapter-anchor voting (aligner phoneme_anchor.py)."""

    segments: int = 5                # vote from the first N Quran segments
    ngram_size: int = 5              # must match a built anchor index size
    rarity_weighting: bool = True
    run_trim_ratio: float = 0.2
    top_candidates: int = 20


class SpecialsParams(SdkModel):
    """Special-segment detection thresholds + output filter.

    ``filter`` names special refs (members of ``lib.specials.ALL_SPECIAL_REFS``)
    to exclude from the renderable output: matching still detects them, but the
    rows come back ``filtered=True`` so consumers can hide them (Space) or
    delete them with an audit trail (offline extraction)."""

    max_special_edit_distance: float = 0.35
    max_transition_edit_distance: float = 0.45
    filter: tuple[str, ...] = ()

    @field_validator("filter")
    @classmethod
    def _known_special_refs(cls, v: tuple[str, ...]) -> tuple[str, ...]:
        from qua_sdk.components.matching.lib.specials import ALL_SPECIAL_REFS

        unknown = set(v) - ALL_SPECIAL_REFS
        if unknown:
            raise ValueError(f"unknown special refs in filter: {sorted(unknown)}")
        return v


class MatchingParams(SdkModel):
    """Capability-generic surface: anchoring, specials detection, and the
    dangling-final penalty are matcher CAPABILITIES every method shares.
    Method knobs (windows, thresholds, costs, wraps) live in method
    subclasses (e.g. ``WraparoundDpParams``)."""

    autodetect_chapter: bool = True  # False = trust chapter_hint, anchor only as fallback
    anchor: AnchorParams = AnchorParams()
    specials: SpecialsParams = SpecialsParams()
    penalize_non_verse_final: bool = False  # Space UI: -0.25 score on dangling last segment


@runtime_checkable
class Matcher(Protocol):
    def match(
        self,
        emissions: Emissions,
        regions: Regions,
        params: MatchingParams,
        *,
        chapter_hint: int | None = None,
        deploy=None,
    ) -> Alignment: ...
