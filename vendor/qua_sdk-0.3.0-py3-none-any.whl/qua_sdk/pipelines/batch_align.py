"""The default batch_align pipeline: segment → recognize → match → (timing).

A pipeline FULFILLS a task by composing components resolved from the profile's
registry keys; it never hardcodes an implementation. Stages can be skipped by
passing precomputed inputs — the Space's cached loops map directly:
resegment = ``regions=segmenter.clean(cached_raw, new_params)``;
retranscribe = ``regions=cached_regions`` with a new model in the profile.
"""

from __future__ import annotations

from qua_sdk.components.matching.spec import Matcher
from qua_sdk.components.recognition.spec import Recognizer
from qua_sdk.components.segmentation.spec import Segmenter
from qua_sdk.components.timing.spec import TimingBackend
from qua_sdk.errors import CompositionError, ErrorCode
from qua_sdk.observe import run_stage
from qua_sdk.profiles.batch_align import BatchAlignProfile
from qua_sdk.registry import register, resolve
from qua_sdk.schemas import Audio, Emissions, Regions
from qua_sdk.schemas.results import BatchAlignResult, StageMeta


@register("pipeline.batch_align.default@v1")
def batch_align(
    *,
    audio: Audio,
    profile: BatchAlignProfile,
    deploy=None,
    regions: Regions | None = None,
    emissions: Emissions | None = None,
    chapter_hint: int | None = None,
) -> BatchAlignResult:
    if not isinstance(profile, BatchAlignProfile):
        raise CompositionError(ErrorCode.PROFILE_INVALID, "batch_align needs a BatchAlignProfile")

    stages: dict[str, StageMeta] = {}

    def resolved(key: str, params_obj, proto: type):
        """Resolve a runtime, check it satisfies the stage's spec protocol, and
        guard the profile's params against its declared Params type (after
        resolve(): lazy runtimes materialize there)."""
        runtime = resolve(key, expect=proto)
        expected = getattr(runtime, "Params", None)
        if expected is not None and not isinstance(params_obj, expected):
            raise CompositionError(
                ErrorCode.PARAMS_MISMATCH,
                f"profile params are {type(params_obj).__name__}, runtime {key!r} expects "
                f"{expected.__name__} — construct the method params or load the profile via "
                f"BatchAlignProfile.load()",
            )
        return runtime

    if regions is None:
        regions = run_stage(stages, "segmentation", profile.segmenter,
                            lambda: resolved(profile.segmenter, profile.segmentation, Segmenter)
                            .segment(audio, profile.segmentation, deploy=deploy))
    if emissions is None:
        emissions = run_stage(stages, "recognition", profile.recognizer,
                              lambda: resolved(profile.recognizer, profile.recognition, Recognizer)
                              .transcribe(audio, regions, profile.recognition, deploy=deploy))
    if emissions.inventory_mode != (profile.recognition.inventory_mode or emissions.inventory_mode):
        raise CompositionError(
            ErrorCode.SCHEMA_MISMATCH,
            f"emissions carry {emissions.inventory_mode!r} tokens, "
            f"profile expects {profile.recognition.inventory_mode!r}",
        )

    alignment = run_stage(stages, "matching", profile.matcher,
                          lambda: resolved(profile.matcher, profile.matching, Matcher)
                          .match(emissions, regions, profile.matching,
                                 chapter_hint=chapter_hint, deploy=deploy))

    timings = None
    if profile.timing:
        timings = run_stage(stages, "timing", profile.timing,
                            lambda: resolved(profile.timing, profile.timing_params, TimingBackend)
                            .timestamps(audio, alignment, profile.timing_params,
                                        emissions=emissions, deploy=deploy))
        seg_ids = {s.id for s in alignment.segments}
        if {t.segment_id for t in timings.segments} - seg_ids:
            raise CompositionError(ErrorCode.SCHEMA_MISMATCH, "timings reference unknown segment ids")

    return BatchAlignResult(
        regions=regions, alignment=alignment, timings=timings,
        profile_name=profile.name, stages=stages,
    )
