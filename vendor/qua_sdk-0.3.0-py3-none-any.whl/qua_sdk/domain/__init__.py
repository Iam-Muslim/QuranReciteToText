"""Domain layer (L0): the one source of truth for words, scripts, and sounds.

Wraps the first-party quranic-phonemizer (lazily — fake-runtime CI must not
need it). Owns ref parsing, the phoneme inventory, substitution costs, chapter
phoneme references, the anchor n-gram index, the quran word index, reading-
sequence reconstruction, and the disk cache the built artifacts live in.
"""

from qua_sdk.domain.anchor_index import PhonemeNgramIndex, build_ngram_index, load_ngram_index
from qua_sdk.domain.cache import load_or_build
from qua_sdk.domain.chapter_refs import (
    ChapterReference,
    RefWord,
    build_all_chapter_references,
    build_chapter_reference,
    get_phonemizer,
    load_chapter_refs,
)
from qua_sdk.domain.inventory import PhonemeInventory
from qua_sdk.domain.quran_index import QuranIndex, WordInfo, load_quran_index
from qua_sdk.domain.reading_sequence import compute_reading_sequence
from qua_sdk.domain.refs import SPECIAL_NAMES, Location, RefSpan, parse_location, parse_span
from qua_sdk.domain.special_texts import SPECIAL_PHONEMES, SPECIAL_TEXT, TRANSITION_TEXT
from qua_sdk.domain.sub_costs import SubCostTable, load_sub_costs

__all__ = [
    "SPECIAL_NAMES", "Location", "RefSpan", "parse_location", "parse_span",
    "SPECIAL_PHONEMES", "SPECIAL_TEXT", "TRANSITION_TEXT",
    "PhonemeInventory",
    "SubCostTable", "load_sub_costs",
    "RefWord", "ChapterReference", "get_phonemizer",
    "build_chapter_reference", "build_all_chapter_references", "load_chapter_refs",
    "PhonemeNgramIndex", "build_ngram_index", "load_ngram_index",
    "QuranIndex", "WordInfo", "load_quran_index",
    "compute_reading_sequence",
    "load_or_build",
]
